/**
 * The venue: where an order or a swap is executed. Futures are a venue adapter on a network —
 * each network names its own perps venue in `venues()`, and a screen finds it by the `perps` flag, never by name.
 * Rate limits, backoff, reconnects and the nonce queue live here once; a screen does not know them.
 */
import type { VenueCapabilities } from "./capabilities.ts";
import type { Amount, AssetId, Intent, NetworkId, Refusal, VenueId } from "./intent.ts";
import type { Timing } from "./network.ts";
import type { Fees, LegRef, TxRef } from "./receipt.ts";
import type { SignerAdapter } from "./signer.ts";

export interface Market {
  readonly id: string;
  /** As the person reads it: "SOL-PERP", "ETH/USDC". */
  readonly symbol: string;
  readonly kind: "spot" | "perp";
  readonly base: AssetId;
  readonly quote: AssetId;
  /** Price step, decimal string. */
  readonly tick: string;
  /** Size step, decimal string. */
  readonly lot: string;
  readonly min_notional: Amount | null;
  /** Perps only. */
  readonly max_leverage?: number | undefined;
}

export interface MarketLimits {
  readonly tick: string;
  readonly lot: string;
  readonly min_notional: Amount | null;
  readonly max_leverage?: number | undefined;
}

/** A price for a swap intent. It ages: preflight refuses it past its freshness. */
export interface Quote {
  readonly intent_id: string;
  readonly out_expected: Amount;
  readonly out_min: Amount;
  readonly fees: Fees;
  /** The route as the person reads it in «Що це». */
  readonly route: string;
  /** ms, when the venue answered. */
  readonly at: number;
  /** ms */
  readonly expires_at: number;
}

/** [price, size] as decimal strings. */
export type BookLevel = readonly [string, string];

export interface BookSnapshot {
  readonly market: string;
  readonly bids: readonly BookLevel[];
  readonly asks: readonly BookLevel[];
  /** ms, the venue's time of the snapshot. */
  readonly at: number;
}

export interface Trade {
  readonly market: string;
  readonly price: string;
  readonly size: string;
  readonly side: "buy" | "sell";
  /** ms */
  readonly at: number;
}

export interface Candle {
  /** ms, the open of the bar. */
  readonly t: number;
  readonly o: string;
  readonly h: string;
  readonly l: string;
  readonly c: string;
  readonly v: string;
}

/** One leg's answer: its ids at the venue and its state. */
export interface LegAck extends LegRef {
  readonly state: "resting" | "partial" | "filled" | "cancelled" | "rejected" | "unknown";
}

/**
 * The venue's answer to place, modify or cancel. `unknown` is a timeout with no answer — never shown as an error,
 * the reconciliation settles it. `legs` has leg 0 (the intent's own order) and every leg of `Intent.legs`,
 * once the venue gave them ids.
 */
export interface OrderAck {
  readonly intent_id: string;
  readonly state: "resting" | "partial" | "filled" | "cancelled" | "rejected" | "unknown";
  readonly legs: readonly LegAck[];
  readonly reason?: Refusal | undefined;
}

export interface Order {
  readonly order_id: string;
  readonly client_id?: string | undefined;
  /** The intent that placed it; absent for an order placed outside Ryntra (the reconciliation shows those too). */
  readonly intent_id?: string | undefined;
  readonly leg: number;
  /** What the order is for: the screen marks the stop loss and the take profit. */
  readonly role: "order" | "take_profit" | "stop_loss";
  readonly trigger?: string | undefined;
  readonly reduce_only?: boolean | undefined;
  readonly market: string;
  readonly side: "buy" | "sell";
  readonly price: string;
  /** Unsigned decimal in the market's base asset; the side says which way. */
  readonly size: string;
  readonly filled: string;
  readonly state: "resting" | "partial";
}

export interface Fill {
  readonly fill_id: string;
  readonly order_id: string;
  readonly client_id?: string | undefined;
  readonly intent_id?: string | undefined;
  readonly leg: number;
  readonly market: string;
  readonly side: "buy" | "sell";
  readonly price: string;
  /** Unsigned decimal in the market's base asset; the side says which way. */
  readonly size: string;
  readonly role: "maker" | "taker";
  readonly fees: Fees;
  readonly tx: TxRef;
  /** ms */
  readonly at: number;
}

export interface Position {
  readonly market: string;
  /** Signed decimal string: positive is long. */
  readonly size: string;
  readonly entry: string;
  readonly liquidation: string | null;
  readonly margin: Amount;
  readonly leverage: number;
}

/** One line of the fee schedule; Review shows the whole schedule — venue and builder — before the signature. */
export interface FeeRow {
  readonly who: "venue" | "builder" | "ryntra";
  readonly applies_to: "taker" | "maker" | "post_only" | "swap" | "all";
  /** Basis points, may be fractional; negative is a rebate. */
  readonly bps: number;
}

export interface VenueHealth {
  readonly state: "ok" | "degraded" | "down";
  /** ms, how old the newest data from the venue is. */
  readonly age_ms: number | null;
  /** Shown on the greyed function when the state is not ok. */
  readonly reason?: string | undefined;
}

export interface OrderOptions {
  readonly signal?: AbortSignal;
}

export interface VenueAdapter {
  readonly id: VenueId;
  /** As the person reads it in Review: «Купити 0.5 SOL-PERP на …». */
  readonly label: string;
  /** The network adapter this venue belongs to; equals that adapter's `id`. */
  readonly network: NetworkId;
  /** The venue's own deadline for an answer to an order (each venue has its own). */
  readonly timing: Timing;
  /** How many legs it takes in one action under one signature: 1 when it takes none beyond the order itself. */
  readonly maxLegs: number;
  capabilities(): VenueCapabilities;
  markets(): Promise<readonly Market[]>;
  limits(market: string): Promise<MarketLimits>;
  /** The schedule for this account, where the venue has fee tiers; the base schedule without one. */
  feeSchedule(account?: string): Promise<readonly FeeRow[]>;
  health(): Promise<VenueHealth>;

  /** Swaps. */
  quote(intent: Intent): Promise<Quote>;

  /** Snapshots; the live streams come through the data channel (`DataAdapter`), not from here. */
  book(market: string): Promise<BookSnapshot>;
  trades(market: string): Promise<readonly Trade[]>;
  candles(market: string, resolution: string, from: number, to: number): Promise<readonly Candle[]>;

  /**
   * Orders. The venue builds the order (with its legs), asks the signer it is given — once — and submits.
   * Idempotent by `intent_id`: the same intent placed twice, at once or after an `unknown`, is the same order.
   * With no answer by `signal` or `timing` the ack is `unknown` — never a rejection. `modify` and `cancel` name the
   * order they act on by its intent in `params.target`, and one leg of it by `params.target_leg`; a modify keeps the
   * leg's `client_id` (a venue that cancels and replaces may give a new `order_id`). An intent the signer refuses, or
   * one with a parameter outside `PARAM_VALUES`, is a fault of the caller (Review checks first): the promise rejects
   * and nothing is signed or sent.
   */
  place(intent: Intent, signer: SignerAdapter, options?: OrderOptions): Promise<OrderAck>;
  modify(intent: Intent, signer: SignerAdapter, options?: OrderOptions): Promise<OrderAck>;
  cancel(intent: Intent, signer: SignerAdapter, options?: OrderOptions): Promise<OrderAck>;
  openOrders(account: string): Promise<readonly Order[]>;
  /** ms */
  fills(account: string, since: number): Promise<readonly Fill[]>;
  positions(account: string): Promise<readonly Position[]>;
}
