/**
 * The network adapter: the only place that knows a network. It builds, sends or
 * follows, it never signs. Its sections: capabilities, wallet, spot and perps (its venues), deposit,
 * receipts, identity.
 */
import type { Capabilities } from "./capabilities.ts";
import type { Amount, AssetId, Intent, NetworkId, Refusal, SignerKind, VenueId } from "./intent.ts";
import type { ActualAmounts, Fees, TxRef } from "./receipt.ts";
import type { SentPayload, SignedPayload, SignerAdapter, UnsignedPayload } from "./signer.ts";
import type { VenueAdapter } from "./venue.ts";

/** A wallet the person can connect on this network. */
export interface WalletOption {
  readonly id: string;
  readonly label: string;
  readonly installed: boolean;
}

export interface Connection {
  readonly address: string;
  /** The wallet as a signer; the adapter never sees its key. */
  readonly signer: SignerAdapter;
}

export interface Balance {
  readonly asset: AssetId;
  readonly amount: Amount;
  /** Set when the balance sits on a venue (collateral), not in the wallet. */
  readonly venue?: VenueId | undefined;
}

export type Simulation =
  | { readonly ok: true; readonly fees: Fees }
  | { readonly ok: false; readonly reason: Refusal };

/**
 * The answer to `send` or `track`. `sent` — on its way; `unknown` — no answer by the deadline, the id is known and the
 * reconciliation follows it; `rejected` — refused before it went out (a preflight), with the network's words.
 * `duplicate_of` — a second transaction of the same intent and step really went out (a wallet sent twice): it is
 * reported with its own id, never folded into the first. Never thrown: a refusal and a silence are answers.
 */
export type SendResult =
  | { readonly state: "sent"; readonly tx_id: string; readonly duplicate_of?: string | undefined }
  | { readonly state: "unknown"; readonly tx_id: string }
  | { readonly state: "rejected"; readonly reason: Refusal; readonly tx_id?: string | undefined };

/**
 * The transaction as the network reports it. `unknown` means no answer in time — never an error; the
 * reconciliation turns it into a final state.
 */
export interface TxStatus {
  readonly state: "sent" | "acked" | "filled" | "rejected" | "expired" | "unknown";
  readonly reason?: Refusal | undefined;
}

/** What the receipt needs from the network after the fact. */
export interface ParsedTx {
  readonly tx: TxRef;
  readonly state: "filled" | "rejected" | "expired";
  readonly amounts_actual: ActualAmounts;
  readonly fees: Fees;
  readonly reason?: Refusal | undefined;
}

export type NetworkEvent =
  | { readonly kind: "balance"; readonly asset: AssetId; readonly at: number }
  | { readonly kind: "tx"; readonly tx_id: string; readonly state: TxStatus["state"]; readonly at: number };

/**
 * A way to fund a venue, explicit end to end: where the collateral comes from, what arrives, on which
 * venue and in which margin account, and by what bridge — `bridge: null` is a deposit on the same network, not the
 * absence of a deposit. The network the money arrives on lists the route. A deposit is an intent with
 * `action: "deposit"`: on the same network this adapter builds it; across a bridge the source network's adapter builds
 * and its wallet signs the outgoing step, and this adapter follows the arrival.
 */
export interface DepositRoute {
  readonly id: string;
  /** Where the collateral leaves from. */
  readonly source: { readonly network: NetworkId; readonly asset: AssetId };
  /** The venue the money arrives on — a venue of this network. */
  readonly venue: VenueId;
  /** What arrives on the venue. */
  readonly asset: AssetId;
  /** The margin account it lands in, as the venue names it. */
  readonly account: string;
  /** The bridge it crosses, as the person reads it; null when it does not leave the network. */
  readonly bridge: string | null;
  readonly minimum: Amount;
  /** How it travels, as the person reads it in «Що це». */
  readonly label: string;
  /** The signer that sends it. */
  readonly signer: SignerKind;
}

/**
 * Sign-in by a signed message with a nonce from the backend; no email, no password. `verify`
 * checks that the signature covers exactly this payload for this address; the caller checks the payload is the
 * message it issued (its nonce and domain).
 */
export interface IdentityAdapter {
  /** The message standard, as the backend names it. */
  readonly scheme: string;
  message(request: { address: string; nonce: string; domain: string; issued_at: number }): UnsignedPayload;
  verify(signed: SignedPayload, address: string): Promise<boolean>;
}

/** A live subscription: `ready` resolves once events will be delivered; `stop` ends them. */
export interface Subscription {
  readonly ready: Promise<void>;
  stop(): void;
}

/** The deadline after which a sent transaction without an answer is `unknown`. */
export interface Timing {
  /** ms */
  readonly unknown_after_ms: number;
}

export interface NetworkAdapter {
  readonly id: NetworkId;
  /** The network as the person reads it; the screen prints it, never a literal of its own. */
  readonly label: string;
  readonly timing: Timing;
  capabilities(): Capabilities;

  /** Wallet. */
  wallets(): Promise<readonly WalletOption[]>;
  connect(walletId: string): Promise<Connection>;
  balances(address: string): Promise<readonly Balance[]>;

  /** Spot and perps: the venues of this network. Each venue's `network` equals this adapter's `id`. */
  venues(): readonly VenueAdapter[];

  /** Deposit: where money can be put to work on this network. */
  depositRoutes(): Promise<readonly DepositRoute[]>;

  /**
   * Build and check. `build` returns the transactions that can be built now, from step `from` (0 by default), in
   * order; a step that needs an earlier one final (a mint after a burn) comes from a later call with the earlier
   * steps' `previous` parse; an empty list means the intent has no more steps. Building the same step again may give
   * new bytes (a fresh blockhash or nonce) — `send` still makes it one transaction per step.
   */
  build(intent: Intent, options?: { readonly from?: number; readonly previous?: readonly ParsedTx[] }): Promise<readonly UnsignedPayload[]>;
  simulate(tx: UnsignedPayload): Promise<Simulation>;
  feeEstimate(intent: Intent): Promise<Fees>;

  /**
   * Put on chain. `send` takes what a `sign` signer signed and is idempotent by intent and step: sent twice — even
   * rebuilt and signed again — it is one transaction. `track` follows what a `sign-and-send` wallet sent itself: the
   * same transaction twice is one; a second transaction the wallet really sent for the same intent and step is
   * reported with its own id and `duplicate_of`, never folded into the first. Both answer `unknown` by `signal`.
   */
  send(signed: SignedPayload, options?: { readonly signal?: AbortSignal }): Promise<SendResult>;
  track(sent: SentPayload, options?: { readonly signal?: AbortSignal }): Promise<SendResult>;
  /**
   * The transaction of this intent and step on chain, if one went out — by what the network can search (a memo
   * with the intent's hash, the account's nonce). For a wallet that went silent, and after a reload: the engine keeps
   * (intent, step) → tx id itself, and asks here when it has none. Null when none is found by `signal`.
   */
  find(payload: UnsignedPayload, options?: { readonly signal?: AbortSignal }): Promise<string | null>;
  /**
   * Resolves `unknown` when the network does not answer by `signal` or `timing` — it never rejects on silence. While a
   * step is `unknown`, nothing is sent again for it: a repeat of `send` answers with the same id, so money never goes out twice.
   */
  status(txId: string, options?: { readonly signal?: AbortSignal }): Promise<TxStatus>;
  /** Events come on any later tick, from `ready` on. */
  subscribe(address: string, listener: (event: NetworkEvent) => void): Subscription;

  /** Receipts: the facts after the fact — null while the transaction is not final — and the public link to them. */
  parse(txId: string, options?: { readonly signal?: AbortSignal }): Promise<ParsedTx | null>;
  explorerUrl(txId: string): string;

  /** Identity. */
  readonly identity: IdentityAdapter;
}
