/**
 * The capability flags. A screen asks `capabilities()` instead of asking which network it is on;
 * a flag that is not "on" shows the function grey with a caption, it never hides it.
 */
export const CAPABILITIES = [
  "swap",
  "limit",
  "clob",
  "perps",
  "launch",
  "liquidity",
  "deposit_cctp",
  "withdraw",
  "bridge",
  "trading_key",
  "automation_browser",
  "automation_server",
  "receipt_anchor",
  "predictions",
] as const;

export type Capability = (typeof CAPABILITIES)[number];

/**
 * Flags a venue can carry: the trading ones. The rest belong to the network (deposits, bridge, keys, automation,
 * anchors). For a venue flag the network is "on" exactly when one of its venues is "on".
 */
export const VENUE_CAPABILITIES = ["swap", "limit", "clob", "perps", "launch", "liquidity"] as const satisfies readonly Capability[];

export type VenueCapability = (typeof VENUE_CAPABILITIES)[number];

/**
 * - `on` — works now, the screen shows it active.
 * - `later` — planned; `until` is the release caption the screen prints as is ("after 1.14").
 * - `off` — not here; the screen shows it grey and names where it is "on" from the other adapters' labels.
 */
export type CapabilityState =
  | { readonly status: "on" }
  | { readonly status: "later"; readonly until: string }
  | { readonly status: "off" };

/** Complete by type: every flag has a state, none is left out. */
export type Capabilities = { readonly [K in Capability]: CapabilityState };

export type VenueCapabilities = { readonly [K in VenueCapability]: CapabilityState };
