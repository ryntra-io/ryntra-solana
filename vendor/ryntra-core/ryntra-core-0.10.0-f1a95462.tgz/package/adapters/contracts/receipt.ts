/**
 * The receipt: one Flight Log schema for every network. The engine writes it; the adapters supply
 * what only they know — the transaction reference, the actual amounts and fees, the final state, the venue's ids.
 */
import type { Amount, FinalState, IntentAction, IntentAmounts, IntentParams, IntentRule, NetworkId, VenueId } from "./intent.ts";

export const RECEIPT_SCHEMA = "ryntra.flight-log/1";

/** Fees by who takes them; the screen shows each line separately, never "included". */
export interface Fees {
  readonly venue?: Amount | undefined;
  readonly builder?: Amount | undefined;
  readonly ryntra?: Amount | undefined;
  readonly gas?: Amount | undefined;
}

/** What actually moved: what left the wallet and what arrived. */
export interface ActualAmounts {
  readonly in?: Amount | undefined;
  readonly out?: Amount | undefined;
}

/**
 * Where it happened. `id` is what the explorer link and the reconciliation use; `facts` holds the rest the way the
 * network names it (a slot and block time, a block and log index, an order id and a fill id).
 */
export interface TxRef {
  readonly id: string;
  readonly facts: Readonly<Record<string, string | number>>;
}

/** The venue's ids of one leg: its client order id and, once it has one, its own order id. */
export interface LegRef {
  readonly leg: number;
  readonly client_id: string;
  readonly order_id?: string | undefined;
}

/** Where the receipt is fixed outside our server; null where the venue itself is the source. */
export interface Anchor {
  readonly kind: string;
  readonly ref: string;
}

export interface FxRate {
  /** USD per one unit of the asset, decimal string. */
  readonly usd: string;
  readonly source: string;
  /** ms */
  readonly at: number;
}

export interface Receipt {
  readonly schema: typeof RECEIPT_SCHEMA;
  readonly intent_id: string;
  readonly operation_id: string;
  readonly action: IntentAction;
  readonly venue: VenueId;
  readonly network: NetworkId;
  readonly rule?: IntentRule;
  readonly params: IntentParams;
  readonly amounts: {
    readonly expected: IntentAmounts;
    readonly actual: ActualAmounts;
    /** Expected against actual, in bps; absent when there is nothing to compare. */
    readonly diff_bps?: number;
  };
  readonly fees: Fees;
  readonly tx: TxRef;
  /** The venue's ids for every leg, next to `intent_id`. */
  readonly legs?: readonly LegRef[];
  readonly fx: FxRate;
  readonly anchor: Anchor | null;
  readonly signer: string;
  readonly signature: string;
  /** A receipt for each part of a partial fill, a final state otherwise. */
  readonly state: FinalState | "partial";
  /** ms */
  readonly reconciled_at?: number;
}
