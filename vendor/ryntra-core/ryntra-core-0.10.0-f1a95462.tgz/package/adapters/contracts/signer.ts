/**
 * The signer. Ryntra holds no private key: every adapter is handed a signer, never a key
 * or a seed. The engine calls it on the move from `review` to `signed`.
 *
 * Two ways to put a transaction on chain: sign it and give it to the
 * network adapter to send, or — where the wallet may only sign and send in one step (most browser EVM wallets; on the
 * phone, Mobile Wallet Adapter signs and sends by default) — let the wallet send it and give the network adapter its
 * id to follow. Either way the adapter holds no key and signs nothing.
 */
import type { Amount, Intent, NetworkId, Refusal, SignerKind } from "./intent.ts";

/**
 * What goes to the signer. `tx` is a network transaction, `action` a venue's signed message (an order),
 * `message` a sign-in text. `bytes` is the exact thing to sign, base64; `encoding` names its format for the signer.
 * `step_id` orders the transactions of one intent (a withdrawal can be two): the idempotency key is intent and step.
 */
export interface UnsignedPayload {
  /** Null for a sign-in message, which belongs to no intent. */
  readonly intent_id: string | null;
  readonly step_id: number;
  readonly network: NetworkId;
  readonly kind: "tx" | "action" | "message";
  readonly encoding: string;
  readonly bytes: string;
}

export interface SignedPayload {
  readonly payload: UnsignedPayload;
  readonly signer_id: string;
  readonly signature: string;
  /** The signed thing as the signer returned it, base64; a wallet may change a transaction before it signs. */
  readonly bytes?: string | undefined;
}

/** A transaction the wallet signed and sent itself; the network adapter follows it by `tx_id`. */
export interface SentPayload {
  readonly payload: UnsignedPayload;
  readonly signer_id: string;
  readonly tx_id: string;
}

/**
 * The wallet's answer to sign-and-send. `sent` — the wallet returned the id of what it sent: the intent goes to
 * submitted without a separate `signed`; `declined` — the person said no in the wallet; `rejected` — the
 * network refused it before it went out, with its words; `unknown` — no answer by the caller's signal: whether it went
 * out is for `NetworkAdapter.find` and the reconciliation to say, never for a second send. Never thrown.
 */
export type WalletSend =
  | { readonly state: "sent"; readonly sent: SentPayload }
  | { readonly state: "declined"; readonly reason: Refusal }
  | { readonly state: "rejected"; readonly reason: Refusal }
  | { readonly state: "unknown" };

/** A refusal comes with its text for Review. */
export type SignDecision = { readonly ok: true } | { readonly ok: false; readonly reason: Refusal };

export interface SignerLimits {
  /** The most one intent may spend, if the signer has such a ceiling. */
  readonly per_intent?: Amount | undefined;
  /** What is left of the signer's budget, if it has one. */
  readonly remaining?: Amount | undefined;
}

interface SignerBase {
  readonly id: string;
  readonly kind: SignerKind;
  /** «Хто підписує» in Review: the wallet or key as the person knows it. */
  readonly label: string;
  canSign(intent: Intent): SignDecision;
  /** Messages and venue actions always; transactions only for a `sign` signer. */
  sign(payload: UnsignedPayload): Promise<SignedPayload>;
  /** ms; null when the signer does not expire (a wallet). A trading key always expires. */
  readonly expiresAt: number | null;
  readonly limits: SignerLimits | null;
  /**
   * The main wallet that authorized this key (the main wallet authorizes the trading key, the builder fee,
   * deposits and withdrawals; the key trades within what it was allowed). Null for the main wallet itself. Granting
   * and revoking a key are intents (`approve_agent`) signed by the main wallet.
   */
  readonly authorizedBy: string | null;
}

/** Signs a transaction and returns it for `NetworkAdapter.send`. */
export interface SigningSigner extends SignerBase {
  readonly txMode: "sign";
}

/** Signs and sends a transaction in one step; `NetworkAdapter.track` follows it. The engine calls it once per intent and step. */
export interface SendingSigner extends SignerBase {
  readonly txMode: "sign-and-send";
  signAndSend(payload: UnsignedPayload, options?: { readonly signal?: AbortSignal }): Promise<WalletSend>;
}

export type SignerAdapter = SigningSigner | SendingSigner;
