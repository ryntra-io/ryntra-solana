/**
 * The data adapter: one connection per browser to each source, the age of every number known
 * in milliseconds. No button with money works on stale data — the age is in every message for that reason.
 *
 * The second half of this file is the market data every chart reads: who the numbers come from and what we may do
 * with them, how fresh they are by the gateway's clock, gaps, corrections, trades in the chain's own order and the
 * one-second bar — the unit every longer bar is rolled up from.
 */
import type { PriceBasis } from "./chart.ts";
import type { AssetId } from "./intent.ts";

export interface DataMessage<T> {
  readonly channel: string;
  /** ms, the source's time of the data. */
  readonly at: number;
  /** ms, how old the data was when it reached the screen. */
  readonly age_ms: number;
  readonly data: T;
  /** Market data carries its state, its source and the gateway's clock; older channels may not have it yet — and a message without it is read as `stale`. */
  readonly status?: DataStatus;
}

export interface DataAdapter {
  subscribe<T>(channel: string, params: Readonly<Record<string, string>>, listener: (message: DataMessage<T>) => void): () => void;
  snapshot<T>(channel: string, params: Readonly<Record<string, string>>): Promise<DataMessage<T>>;
  /** ms since the newest message on the channel; null before the first one. */
  age(channel: string, params: Readonly<Record<string, string>>): number | null;
}

/**
 * What a source's terms let us do with its numbers: show them as they are; show only what we compute from them
 * (bars built from its trades, an aggregate of several pools) and never its raw figures; or keep them inside the
 * team and off every screen a customer sees.
 */
export const DISPLAY_RIGHTS = ["display", "derived_only", "internal_only"] as const;

export type DisplayRight = (typeof DISPLAY_RIGHTS)[number];

export interface DataSource {
  readonly id: string;
  /** As the person reads it under the chart. */
  readonly label: string;
  readonly rights: DisplayRight;
  /** The words the source asks to be shown beside its numbers; null when it asks for none. */
  readonly attribution: string | null;
}

/**
 * The state of the numbers on a screen. `live` — fresh from a live source; `delayed` — the source itself is behind
 * by a declared delay; `stale` — the stream stopped or is older than its limit; `demo` — not a market at all;
 * `gap` — there is no data for the time shown. Only `live` lets a money button open a position.
 */
export const DATA_STATES = ["live", "delayed", "stale", "demo", "gap"] as const;

export type DataState = (typeof DATA_STATES)[number];

/**
 * Whether the market itself trades now: a stock outside its hours is `closed`, not stale; a venue's pause is
 * `halted`; a settled prediction is `resolved`.
 */
export const MARKET_STATES = ["open", "closed", "halted", "resolved"] as const;

export type MarketState = (typeof MARKET_STATES)[number];

/**
 * The state, the source and the age of a set of numbers. Where they are built from more than one source (a price in
 * a coin and its USD rate), `source` names the most restrictive of them, and its rights hold for all.
 */
export interface DataStatus {
  readonly state: DataState;
  readonly market: MarketState;
  readonly source: DataSource;
  /** ms, the source's time of the newest number. */
  readonly at: number;
  /** ms, the gateway's clock when it had that number. */
  readonly gateway_at: number;
  /**
   * ms, the age by the gateway's clock when it sent the numbers: at least `gateway_at − at`. A screen ages it further
   * with its own measured offset to the gateway, never by the person's wall clock alone: a laptop is often seconds off.
   */
  readonly age_ms: number;
  /** ms, the delay the source declares; set for `delayed` only. */
  readonly delay_ms: number | null;
  /** True when we computed these numbers from the source's raw data, false when they are the source's own figures. */
  readonly derived: boolean;
}

/**
 * Why there is no data: the source had none, it was down, our connection broke, or the time is older than we keep.
 * A gap is drawn as a gap with its reason — never filled with invented bars. A second with no trades in a live stream
 * is not a gap: it simply has no bar.
 */
export const GAP_REASONS = ["no_data", "outage", "reconnect", "retention"] as const;

export type GapReason = (typeof GAP_REASONS)[number];

export interface DataGap {
  /** ms, inclusive. */
  readonly from: number;
  /** ms, exclusive. */
  readonly to: number;
  readonly reason: GapReason;
}

/**
 * Why bars already shown changed: a trade came late, a trade was corrected, the chain rolled it back, history was
 * filled in, or a split or a dividend changed the multiplier (adjusted bars are rebuilt; a mark tells the event).
 */
export const CORRECTION_REASONS = ["late_trade", "corrected_trade", "rolled_back", "backfill", "corporate_action"] as const;

export type CorrectionReason = (typeof CORRECTION_REASONS)[number];

/**
 * "A bar was corrected": the one-second bars of [from, to) were rebuilt, and with them every longer bar that covers
 * them. Bars already on a screen change only through this event — never silently.
 */
export interface BarCorrection {
  readonly instrument: string;
  /** ms, inclusive, on a whole second. */
  readonly from: number;
  /** ms, exclusive, on a whole second. */
  readonly to: number;
  readonly reason: CorrectionReason;
  /** ms, the gateway's clock when the correction was made. */
  readonly at: number;
}

/** How settled a trade is on its own chain or venue; a `pending` trade can still be rolled back. */
export const CONFIRMATIONS = ["pending", "confirmed", "final"] as const;

export type Confirmation = (typeof CONFIRMATIONS)[number];

/** Trades that are marked, never removed: the raw trade stays, filtering it out is the person's choice. */
export const TRADE_FLAGS = ["mev", "wash"] as const;

export type TradeFlag = (typeof TRADE_FLAGS)[number];

/** One trade as the market data carries it. Prices and sizes are decimal strings. */
export interface MarketTrade {
  readonly instrument: string;
  /** Unique within the instrument. */
  readonly id: string;
  readonly price: string;
  /** Unsigned, in the instrument's base asset. */
  readonly size: string;
  /** The taker's side; null where the source does not say. */
  readonly side: "buy" | "sell" | null;
  /** ms, the source's time of the trade. */
  readonly at: number;
  /**
   * The chain's or the venue's own order, compared element by element: block or slot, then the transaction's place in
   * it, then the trade's place in the transaction — or the venue's time and place in its stream. Never the order of
   * arrival: bars are built in this order, so any arrival order gives the same bars.
   */
  readonly order: readonly number[];
  readonly confirmation: Confirmation;
  readonly flags: readonly TradeFlag[];
  /** The trade's price in other units at the trade's own second (a price in a chain's coin also in USD, by that second's rate). */
  readonly priced_in?: Readonly<Record<AssetId, string>>;
}

/**
 * The unit. One-second bars are built from trades (kept for as long as raw trades are kept); trades go on the wire
 * too, for bars by count, volume and range. Five seconds, a minute, a day: each bar stored or sent is an exact
 * roll-up of one-second bars, so every resolution agrees with every other and with the server.
 */
export const WIRE_RESOLUTION = "1s";

/**
 * A one-second bar in one basis: from trades, open is the first trade of the second by `MarketTrade.order`, close the
 * last, high and low the extremes, volume the sum; from a price feed (mark, oracle, index, mid), the first, last,
 * highest and lowest update of the second, with no volume and no trades. A second with nothing in it has no bar.
 */
export interface SecondBar {
  readonly instrument: string;
  readonly basis: PriceBasis;
  /** ms, on a whole second. */
  readonly t: number;
  readonly o: string;
  readonly h: string;
  readonly l: string;
  readonly c: string;
  /** In the base asset; null where the source gives prices without size. */
  readonly v: string | null;
  /** Null for a price feed. */
  readonly trades: number | null;
}
