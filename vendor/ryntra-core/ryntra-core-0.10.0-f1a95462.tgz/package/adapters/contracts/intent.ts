/**
 * The intent: one object for every money action, and its states. The adapters read it;
 * the state machine itself is the engine's, not this package's today.
 */

/** A network as the adapter names it. The contracts never list networks: a new one is a new adapter, not a new type. */
export type NetworkId = string;
/** A venue as its adapter names it. */
export type VenueId = string;
/** An asset as its network names it (a mint, a contract address, a symbol on an exchange). */
export type AssetId = string;

/** An amount in base units: a decimal string, so no float ever carries money. */
export interface Amount {
  readonly units: string;
  readonly asset: AssetId;
  readonly decimals: number;
}

export const INTENT_ACTIONS = [
  "swap",
  "limit",
  "cancel",
  "perp_order",
  "perp_modify",
  "perp_cancel",
  "launch",
  "claim_fees",
  "ladder_step",
  "autopilot_step",
  "deposit",
  "withdraw",
  "bridge",
  "approve_builder",
  "approve_agent",
] as const;

export type IntentAction = (typeof INTENT_ACTIONS)[number];

export const INTENT_SOURCES = ["ui", "hotkey", "bot", "autopilot", "agent", "ladder"] as const;

export type IntentSource = (typeof INTENT_SOURCES)[number];

/** Who is expected to sign (`SignerAdapter.kind`). One signer per intent. */
export const SIGNER_KINDS = ["wallet", "trading-key", "api-wallet", "executor"] as const;

export type SignerKind = (typeof SIGNER_KINDS)[number];

export const INTENT_STATES = [
  "draft",
  "preflight",
  "review",
  "signed",
  "sent",
  "acked",
  "resting",
  "partial",
  "filled",
  "rejected",
  "cancelled",
  "unknown",
  "expired",
  "reconciled",
] as const;

export type IntentState = (typeof INTENT_STATES)[number];

/** The states that end an intent. */
export const FINAL_STATES = ["filled", "rejected", "cancelled", "expired", "reconciled"] as const satisfies readonly IntentState[];

export type FinalState = (typeof FINAL_STATES)[number];

/**
 * Amounts are fixed in the intent before Review and are not recomputed between Review and the signature.
 * An action that moves no money (a cancel, an approval) carries none. For an order, `in` is its size in base units of
 * the market's base asset (a buy or a sell of 0.5 SOL-PERP is 0.5 SOL), spot and perps alike.
 */
export interface IntentAmounts {
  readonly in?: Amount;
  readonly out_expected?: Amount;
  readonly out_min?: Amount;
  readonly fee_venue?: Amount;
  readonly fee_builder?: Amount;
  readonly fee_ryntra?: Amount;
  readonly gas?: Amount;
}

export interface IntentRule {
  readonly rule_id: string;
  /** Human words, shown in Review and the receipt unchanged. */
  readonly reason: string;
  readonly version: string;
}

export type ParamValue = string | number | boolean;

/**
 * The parameter names every adapter reads the same way (`params`: pair, side, order type, TIF,
 * reduce-only, leverage, slippage, route). Values are words and prices, never sums: sums live in `amounts`.
 * `target` names the intent a modify or a cancel acts on; `target_leg` narrows it to one leg (a take profit or a stop
 * loss alone). `trigger` is the price that wakes a take profit or a stop loss; it then executes as its `type`. A modify
 * carries the new `price` and/or the new `trigger` of the leg it targets.
 */
export const PARAM_KEYS = ["market", "side", "type", "price", "trigger", "tif", "reduce_only", "leverage", "slippage_bps", "route", "target", "target_leg"] as const;

/** The words the closed parameters take; an adapter refuses anything else rather than guess. */
export const PARAM_VALUES = {
  side: ["buy", "sell"],
  type: ["market", "limit"],
  tif: ["gtc", "ioc", "post_only"],
} as const;

export type ParamKey = (typeof PARAM_KEYS)[number];

export type IntentParams = Readonly<Partial<Record<ParamKey, ParamValue>>>;

/**
 * A leg sent in the same action and under the same signature as the intent's own order, with its own id at the
 * venue; the receipt keeps the intent id and every leg id. The rest is this contract's shape: the intent's own
 * order is leg 0, these are legs 1, 2, …; a leg is a take profit or a stop loss only (arbitrary multi-leg strategies
 * come later, with the engine); it trades the intent's market and, without `amounts`, the intent's size.
 */
export interface IntentLeg {
  readonly leg: number;
  readonly role: "take_profit" | "stop_loss";
  readonly params: IntentParams;
  readonly amounts?: IntentAmounts;
}

export interface Intent {
  /** UUID v7; with the step, the idempotency key everywhere. A venue's own order id may differ — the receipt keeps both. */
  readonly intent_id: string;
  readonly profile_id: string;
  readonly network: NetworkId;
  readonly venue: VenueId;
  readonly action: IntentAction;
  readonly params: IntentParams;
  readonly amounts: IntentAmounts;
  /** Legs 1… sent with the intent's own order in one action, one signature. */
  readonly legs?: readonly IntentLeg[];
  readonly source: IntentSource;
  readonly rule?: IntentRule;
  readonly signer: SignerKind;
  /** ms */
  readonly created_at: number;
  /** ms; an intent with a price ages with the price. */
  readonly expires_at?: number;
  /** Ties separate intents of one strategy: two intents, two signatures. */
  readonly group_id?: string;
}

/** A refusal from a network, a venue or a signer: the original words, verbatim; the screen adds the translation. */
export interface Refusal {
  readonly original: string;
  readonly code?: string | undefined;
}
