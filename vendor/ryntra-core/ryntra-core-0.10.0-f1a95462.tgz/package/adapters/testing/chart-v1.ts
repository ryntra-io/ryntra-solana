/**
 * Version 1 of the chart contract read as version 2: an old datafeed becomes a `ChartSource`, so it passes the same
 * suite while a product moves over. What version 1 never said — the state and the source of its numbers, where its
 * history starts, the instrument's steps, session and bases — the caller states once in `ChartV1Description`. An old
 * datafeed carries no age, so its numbers are never `live`. The overlay is not bridged: its lines had no side and no
 * size, so the product builds `OrderLine`s from its own orders and `ChartLevel`s from its levels (see `CHART_V1_MAP`).
 */
import { CHART_CONTRACT, TIME_SPANS } from "../contracts/chart.ts";
import type { Bar, ChartAdapterV1, ChartSource, HistoryPage, HistoryRequest, Instrument, LiveEvent, MarksPage, Resolution, TimeResolution } from "../contracts/chart.ts";
import type { DataSource, DataState, DataStatus, MarketState } from "../contracts/data.ts";
import type { Candle } from "../contracts/venue.ts";

export interface ChartV1Description {
  /** Everything an old symbol did not carry. */
  readonly instrument: Omit<Instrument, "id" | "symbol" | "tick" | "min_resolution" | "resolutions">;
  readonly source: DataSource;
  /** What the caller knows of these numbers; an old datafeed cannot say they are live. */
  readonly state: Exclude<DataState, "live">;
  /** ms, the delay the source declares; for `delayed` only. */
  readonly delay_ms: number | null;
  readonly market: MarketState;
  /** ms, where the market's history starts: older pages are asked for until then, however quiet the market was. */
  readonly earliest: number;
  /** The gateway's clock, ms; it must move forward, as a clock does. */
  readonly now: () => number;
}

/** The old resolution words (`1S`, `5`, `60`, `1D`, `1W`, `1M`) as version 2's; null for one version 2 does not take. */
export function resolutionFromV1(word: string): TimeResolution | null {
  const m = /^(\d*)([SDWM]?)$/.exec(word.trim());
  if (!m || word.trim() === "") return null;
  const n = m[1] === "" ? 1 : Number(m[1]);
  const pick = (unit: TimeResolution["unit"], span: number): TimeResolution => ({ kind: "time", unit, span });
  const r =
    m[2] === "S" ? pick("second", n) : m[2] === "D" ? pick("day", n) : m[2] === "W" ? pick("week", n) : m[2] === "M" ? pick("month", n) : n % 60 === 0 ? pick("hour", n / 60) : pick("minute", n);
  const spans: readonly string[] = TIME_SPANS[r.unit];
  return spans.includes(String(r.span)) ? r : null;
}

function resolutionToV1(r: Resolution): string {
  if (r.kind !== "time") throw new Error("version 1 had bars by time only");
  return { second: `${r.span}S`, minute: `${r.span}`, hour: `${r.span * 60}`, day: `${r.span}D`, week: `${r.span}W`, month: `${r.span}M` }[r.unit];
}

/** 10^decimals as a step: 100 → "0.01". The old scale had to be a power of ten to name a step at all. */
export function tickFromPricescale(pricescale: number): string {
  const decimals = Math.log10(pricescale);
  if (!Number.isInteger(decimals) || decimals < 0) throw new Error(`pricescale ${pricescale} is not a power of ten`);
  return decimals === 0 ? "1" : `0.${"0".repeat(decimals - 1)}1`;
}

const LENGTH: Readonly<Record<string, number>> = { second: 1_000, minute: 60_000, hour: 3_600_000, day: 86_400_000, week: 604_800_000, month: 2_678_400_000 };

const lengthOf = (r: Resolution) => (r.kind === "time" ? LENGTH[r.unit]! * r.span : 1_000);

const toBar = (c: Candle): Bar => ({ t: c.t, o: c.o, h: c.h, l: c.l, c: c.c, v: c.v, turnover: null, trades: null });

/** An old adapter's datafeed for one market, as a version 2 source. */
export function chartSourceFromV1(adapter: ChartAdapterV1, market: string, describe: ChartV1Description): ChartSource {
  const feed = adapter.datafeed(market);
  /** `at` is the newest bar's open: an old datafeed does not say when its newest number came. */
  const status = (at: number): DataStatus => {
    const now = describe.now();
    return {
      state: describe.state,
      market: describe.market,
      source: describe.source,
      at,
      gateway_at: now,
      age_ms: Math.max(0, now - at),
      delay_ms: describe.state === "delayed" ? describe.delay_ms : null,
      derived: false,
    };
  };
  let symbol: Promise<Instrument> | null = null;
  const instrument = () =>
    (symbol ??= feed.resolveSymbol(market).then((s) => {
      const resolutions = s.resolutions.map(resolutionFromV1).filter((r): r is TimeResolution => r !== null);
      const min = resolutions[0];
      if (!min) throw new Error(`${market}: none of its resolutions is one version 2 takes`);
      return { ...describe.instrument, id: s.market, symbol: s.symbol, tick: tickFromPricescale(s.pricescale), min_resolution: min, resolutions };
    }));
  /** The newest bar a page has shown, per resolution: a live bar older than it is a correction, never a bar. */
  const shown = new Map<string, number>();

  return {
    contract: CHART_CONTRACT,
    instrument: () => instrument(),
    async history(request: HistoryRequest): Promise<HistoryPage> {
      const i = await instrument();
      const length = lengthOf(request.resolution);
      const word = resolutionToV1(request.resolution);
      const now = describe.now();
      const window = request.limit * length;
      let bars: Bar[] = [];
      let more: HistoryPage["more"];
      if (request.load === "backward") {
        const from = request.timestamp! + 1;
        const inside = (await feed.getBars(market, word, from, now + 1)).filter((c) => c.t >= from && c.t <= now).sort((a, b) => a.t - b.t);
        bars = inside.slice(0, request.limit).map(toBar);
        more = { forward: true, backward: inside.length > request.limit };
      } else {
        // A quiet stretch longer than a page leaves a window empty; the bridge steps back, each window twice the last,
        // until it finds bars or the start of history — years of quiet cost tens of calls, not thousands.
        let to = request.load === "init" ? now + 1 : request.timestamp!;
        let span = window;
        while (bars.length === 0 && to > describe.earliest) {
          const from = Math.max(describe.earliest, to - span);
          bars = (await feed.getBars(market, word, from, to)).filter((c) => c.t >= from && c.t < to).sort((a, b) => a.t - b.t).slice(-request.limit).map(toBar);
          to = from;
          span *= 2;
        }
        more = { forward: bars.length > 0 && (bars[0]!.t > describe.earliest), backward: false };
      }
      const key = JSON.stringify(request.resolution);
      const newest = bars.at(-1)?.t;
      if (newest !== undefined) shown.set(key, Math.max(shown.get(key) ?? newest, newest));
      return { bars, more, gaps: [], display_step: i.tick, multiplier_version: i.multiplier_version, status: status(newest ?? now) };
    },
    subscribe(request, listener) {
      const key = JSON.stringify(request.resolution);
      const length = lengthOf(request.resolution);
      let newest: number | null = shown.get(key) ?? null;
      let last: { t: number; at: number } | null = null;
      let held: Bar | null = null;
      let timer: ReturnType<typeof setTimeout> | null = null;
      let open = true;
      const emit = (bar: Bar) => {
        last = { t: bar.t, at: describe.now() };
        listener({ type: "bar", bar, status: status(bar.t) } satisfies LiveEvent);
      };
      const flush = () => {
        if (timer) clearTimeout(timer);
        timer = null;
        if (open && held) emit(held);
        held = null;
      };
      const stop = feed.subscribeBars(market, resolutionToV1(request.resolution), (candle) => {
        if (!open) return;
        const bar = toBar(candle);
        // Version 1 could send an older bar; the engine would drop it without a word, so it becomes a correction.
        if (newest !== null && bar.t < newest) {
          const from = bar.t - (bar.t % 1_000);
          listener({ type: "corrected", correction: { instrument: market, from, to: from + length, reason: "late_trade", at: describe.now() } });
          return;
        }
        // The last state of a bar always goes out before the next bar opens: its closing update, exempt from the limit.
        if (held && held.t !== bar.t) flush();
        newest = bar.t;
        // One bar at most once a second: a newer update of the same bar waits for the rest of the second.
        if (last && last.t === bar.t && describe.now() - last.at < 1_000) {
          held = bar;
          timer ??= setTimeout(flush, 1_000 - (describe.now() - last.at));
          return;
        }
        held = null;
        if (timer) clearTimeout(timer);
        timer = null;
        emit(bar);
      });
      return () => {
        open = false;
        if (timer) clearTimeout(timer);
        stop();
      };
    },
    series: async () => [],
    seriesHistory: async (request) => {
      throw new Error(`version 1 had no series (${request.series})`);
    },
    async marks(_instrument, from, to): Promise<MarksPage> {
      const marks = (await feed.getMarks(market, from, to)).filter((m) => m.t >= from && m.t < to);
      return { marks: marks.map((m) => ({ id: m.id, kind: "trade", t: m.t, price: m.price, side: m.side, label: m.label, own: true })), status: status(marks.at(-1)?.t ?? describe.now()) };
    },
    book: async () => null,
  };
}
