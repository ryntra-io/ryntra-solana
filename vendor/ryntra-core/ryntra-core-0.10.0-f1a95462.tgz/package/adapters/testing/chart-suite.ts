/**
 * The contract suite every chart source passes: the instrument is described whole; pages come in the engine's own
 * order and words; every bar longer than the instrument's smallest is an exact roll-up of the smallest; a gap has no
 * bar inside it; the live bar replaces or opens, never goes back; every page says its state, its source and its age
 * by the gateway's clock, and a source's rights decide what reaches a screen. It knows no network and no engine.
 *
 * The checks are plain functions that return what is wrong, so a test can also show a broken source failing.
 */
import assert from "node:assert/strict";
import { describe, it } from "node:test";

import {
  ADJUSTMENTS,
  CHART_CONTRACT,
  INSTRUMENT_KINDS,
  MARK_KINDS,
  MEASURES,
  OUTCOMES,
  PRICE_KINDS,
  SCALES,
  SERIES_UNITS,
  TIME_SPANS,
  TIME_UNITS,
  WEEKDAYS,
} from "../contracts/chart.ts";
import type {
  Bar,
  ChartSource,
  DomBook,
  HistoryPage,
  HistoryRequest,
  Instrument,
  LiveEvent,
  MarksPage,
  PriceBasis,
  Resolution,
  SeriesPage,
  TimeResolution,
  TradingSession,
} from "../contracts/chart.ts";
import { CORRECTION_REASONS, DATA_STATES, DISPLAY_RIGHTS, GAP_REASONS, MARKET_STATES } from "../contracts/data.ts";
import type { DataStatus } from "../contracts/data.ts";

/** Who sees the chart: a customer's screen, or an internal one (monitoring, the team's own tools). */
export type ChartAudience = "customer" | "internal";

export interface ChartHarness {
  readonly source: ChartSource;
  readonly instrument: string;
  readonly audience: ChartAudience;
  /** Plays the recorded stream to whoever subscribed, and resolves when it is done; null where the fixture has no stream. */
  readonly replay: (() => Promise<void>) | null;
  /**
   * The smallest bars of a basis as they must be once the stream has played — built from every trade in the chain's
   * order, whatever order they arrived in; null where the harness cannot say.
   */
  readonly truth: ((basis: PriceBasis) => Promise<readonly Bar[]>) | null;
}

export type ChartHarnessFactory = () => Promise<ChartHarness>;

// ── Decimals, exactly ─────────────────────────────────────────────────────────────────────────────────────────────

const DECIMAL = /^-?\d+(\.\d+)?$/;
const UNSIGNED = /^\d+(\.\d+)?$/;

interface Fixed {
  readonly n: bigint;
  readonly scale: number;
}

function fixed(value: string): Fixed {
  const negative = value.startsWith("-");
  const [whole = "0", fraction = ""] = value.replace("-", "").split(".");
  const n = BigInt(whole + fraction);
  return { n: negative ? -n : n, scale: fraction.length };
}

function aligned(a: string, b: string): [bigint, bigint, number] {
  const x = fixed(a);
  const y = fixed(b);
  const scale = Math.max(x.scale, y.scale);
  return [x.n * 10n ** BigInt(scale - x.scale), y.n * 10n ** BigInt(scale - y.scale), scale];
}

/** -1, 0 or 1. */
export function compareDecimal(a: string, b: string): number {
  const [x, y] = aligned(a, b);
  return x < y ? -1 : x > y ? 1 : 0;
}

export function addDecimal(a: string, b: string): string {
  const [x, y, scale] = aligned(a, b);
  const sum = x + y;
  const negative = sum < 0n;
  const digits = (negative ? -sum : sum).toString().padStart(scale + 1, "0");
  const whole = digits.slice(0, digits.length - scale);
  const fraction = digits.slice(digits.length - scale).replace(/0+$/, "");
  return `${negative ? "-" : ""}${whole}${fraction ? `.${fraction}` : ""}`;
}

/** Whether `value` is a whole number of `step`s. */
export function onStep(value: string, step: string): boolean {
  const [x, y] = aligned(value, step);
  return y !== 0n && x % y === 0n;
}

// ── Time ──────────────────────────────────────────────────────────────────────────────────────────────────────────

const UNIT_MS: Readonly<Record<string, number>> = { second: 1_000, minute: 60_000, hour: 3_600_000 };

/** ms in a bar of a sub-day resolution; null for days, weeks and months, whose length depends on the calendar. */
export function spanMs(resolution: Resolution): number | null {
  if (resolution.kind !== "time") return null;
  const unit = UNIT_MS[resolution.unit];
  return unit === undefined ? null : unit * resolution.span;
}

function zoneParts(t: number, timezone: string) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: timezone,
    hourCycle: "h23",
    weekday: "short",
    day: "numeric",
    hour: "numeric",
    minute: "numeric",
    second: "numeric",
  }).formatToParts(new Date(t));
  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? "";
  return { weekday: get("weekday"), day: Number(get("day")), hour: Number(get("hour")), minute: Number(get("minute")), second: Number(get("second")) };
}

/** Whether a bar may open at `t`: on its boundary from the epoch, or at midnight in the session's zone for days and longer. */
export function onBoundary(t: number, resolution: TimeResolution, session: TradingSession): boolean {
  const span = spanMs(resolution);
  if (span !== null) return t % span === 0;
  if (t % 1_000 !== 0) return false;
  const p = zoneParts(t, session.timezone);
  const midnight = p.hour === 0 && p.minute === 0 && p.second === 0;
  if (resolution.unit === "day") return midnight;
  if (resolution.unit === "week") return midnight && p.weekday === "Mon";
  return midnight && p.day === 1;
}

const validZone = (timezone: string) => {
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: timezone });
    return true;
  } catch {
    return false;
  }
};

// ── Checks ────────────────────────────────────────────────────────────────────────────────────────────────────────

/** The reader's version against the writer's: the same major is compatible. */
export function compatibleContract(reader: string, writer: string): boolean {
  const major = (v: string) => /^ryntra\.chart\/(\d+)\.(\d+)$/.exec(v)?.[1] ?? null;
  return major(reader) !== null && major(reader) === major(writer);
}

const sameResolution = (a: Resolution, b: Resolution) => JSON.stringify(a) === JSON.stringify(b);

export const sameBasis = (a: PriceBasis, b: PriceBasis) => a.kind === b.kind && a.measure === b.measure && a.in === b.in && a.adjustment === b.adjustment && a.outcome === b.outcome;

export function checkResolution(resolution: Resolution): string[] {
  switch (resolution.kind) {
    case "time": {
      if (!(TIME_UNITS as readonly string[]).includes(resolution.unit)) return [`unknown time unit "${resolution.unit}"`];
      const spans: readonly string[] = TIME_SPANS[resolution.unit];
      return spans.includes(String(resolution.span)) ? [] : [`${resolution.span} ${resolution.unit} is not a span the contract takes (${spans.join(", ")})`];
    }
    case "tick":
      return Number.isInteger(resolution.trades) && resolution.trades > 0 ? [] : ["a tick bar counts a whole positive number of trades"];
    case "volume":
      return UNSIGNED.test(resolution.size) && compareDecimal(resolution.size, "0") > 0 ? [] : ["a volume bar has a positive decimal size"];
    case "range":
      return UNSIGNED.test(resolution.range) && compareDecimal(resolution.range, "0") > 0 ? [] : ["a range bar spans a positive price range"];
    default:
      return [`unknown bar kind ${JSON.stringify(resolution)}`];
  }
}

/** Time resolutions in order: by unit, then by span. */
function timeOrder(r: TimeResolution): number {
  return TIME_UNITS.indexOf(r.unit) * 1_000 + r.span;
}

function checkSession(session: TradingSession, where: string): string[] {
  const problems: string[] = [];
  if (!session.holidays.every((d) => /^\d{4}-\d{2}-\d{2}$/.test(d))) problems.push(`${where}: holidays are YYYY-MM-DD`);
  if (!validZone(session.timezone)) problems.push(`${where}: "${session.timezone}" is not an IANA time zone`);
  for (const w of session.windows) {
    if (w.days.length === 0 || !w.days.every((d) => (WEEKDAYS as readonly string[]).includes(d))) problems.push(`${where}: a window names its days`);
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(w.open) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(w.close)) problems.push(`${where}: open and close are HH:MM`);
  }
  return problems;
}

export function checkInstrument(i: Instrument): string[] {
  const problems: string[] = [];
  for (const key of ["id", "symbol", "network", "venue", "base", "quote"] as const) if (!i[key]) problems.push(`instrument.${key} is named`);
  if (!(INSTRUMENT_KINDS as readonly string[]).includes(i.kind)) problems.push(`unknown kind "${i.kind}"`);
  if (!(SCALES as readonly string[]).includes(i.scale)) problems.push(`unknown scale "${i.scale}"`);
  if ((i.kind === "prediction") !== (i.scale === "probability")) problems.push("a prediction, and only a prediction, is on the probability scale");
  if ((i.kind === "prediction") !== i.outcomes.length > 0) problems.push("a prediction, and only a prediction, names its outcomes");
  if (!i.outcomes.every((o) => (OUTCOMES as readonly string[]).includes(o))) problems.push("outcomes are yes and no");
  for (const key of ["tick", "lot", "multiplier"] as const) {
    if (!UNSIGNED.test(i[key]) || compareDecimal(i[key], "0") <= 0) problems.push(`instrument.${key} is a positive decimal string, not "${i[key]}"`);
  }
  if (i.min_notional !== null && !UNSIGNED.test(i.min_notional)) problems.push("min_notional is a decimal string or null");
  if (i.price_rule) {
    const { significant, max_decimals } = i.price_rule;
    if (!(Number.isInteger(significant) && significant > 0 && Number.isInteger(max_decimals) && max_decimals >= 0)) problems.push("a price rule counts whole figures and decimals");
    if (typeof i.price_rule.integers_always !== "boolean") problems.push("a price rule says whether a whole price is always valid");
  }
  if (i.price_band && (!(PRICE_KINDS as readonly string[]).includes(i.price_band.from) || !(i.price_band.max_deviation_bps > 0))) problems.push("a price band names its reference and a positive width");
  if (i.scale === "probability" && UNSIGNED.test(i.tick) && compareDecimal(i.tick, "100") > 0) problems.push("a probability step is under 100 %");
  problems.push(...checkSession(i.session, "session"));
  if (i.reference_session) problems.push(...checkSession(i.reference_session, "reference session"));

  problems.push(...checkResolution(i.min_resolution).map((p) => `min_resolution: ${p}`));
  if (i.resolutions.length === 0) problems.push("at least one resolution");
  i.resolutions.forEach((r) => problems.push(...checkResolution(r).map((p) => `resolution: ${p}`)));
  const times = i.resolutions.filter((r): r is TimeResolution => r.kind === "time");
  if (!times[0] || !sameResolution(times[0], i.min_resolution)) problems.push("the first time resolution is the smallest one");
  times.forEach((r, n) => {
    const prev = times[n - 1];
    if (prev && timeOrder(prev) >= timeOrder(r)) problems.push("time resolutions run from the smallest up, each once");
    if (timeOrder(r) < timeOrder(i.min_resolution)) problems.push("no resolution under the smallest the instrument honestly has");
  });

  if (i.bases.length === 0) problems.push("at least one price basis");
  for (const b of i.bases) {
    if (!(PRICE_KINDS as readonly string[]).includes(b.kind)) problems.push(`unknown price kind "${b.kind}"`);
    if (!(MEASURES as readonly string[]).includes(b.measure)) problems.push(`unknown measure "${b.measure}"`);
    if (!b.in) problems.push("a basis names its unit");
    if (!(ADJUSTMENTS as readonly string[]).includes(b.adjustment)) problems.push(`unknown adjustment "${b.adjustment}"`);
    if (b.adjustment === "adjusted" && i.kind !== "stock") problems.push("only a stock's history is adjusted");
    if (i.kind === "prediction" ? !b.outcome || !i.outcomes.includes(b.outcome) : b.outcome !== null) problems.push("a prediction's basis names one of its outcomes; nothing else names one");
    if (i.scale === "probability" && b.measure !== "price") problems.push("a probability has no market cap");
  }
  const t = i.trading_basis;
  if (!i.bases.some((b) => sameBasis(b, t))) problems.push("the trading basis is one the source serves");
  if (t.kind !== "last" || t.measure !== "price" || t.adjustment !== "raw" || t.in !== i.quote) problems.push("orders are placed in the last raw price in the quote currency");
  return problems;
}

/** Whether a view is in the trading basis' unit, so the trading layer may draft on it: any price kind, the same everything else. */
export const tradableView = (i: Instrument, view: PriceBasis) =>
  view.measure === i.trading_basis.measure && view.in === i.trading_basis.in && view.adjustment === i.trading_basis.adjustment && view.outcome === i.trading_basis.outcome;

export function checkStatus(status: DataStatus, audience: ChartAudience, where: string): string[] {
  const problems: string[] = [];
  if (!(DATA_STATES as readonly string[]).includes(status.state)) problems.push(`${where}: unknown data state "${status.state}"`);
  if (!(MARKET_STATES as readonly string[]).includes(status.market)) problems.push(`${where}: unknown market state "${status.market}"`);
  if (!status.source?.id || !status.source.label) problems.push(`${where}: the source is named`);
  if (!(DISPLAY_RIGHTS as readonly string[]).includes(status.source?.rights)) problems.push(`${where}: the source's rights are one of ${DISPLAY_RIGHTS.join(", ")}`);
  if (status.source && status.source.attribution !== null && !status.source.attribution) problems.push(`${where}: an attribution is words or null`);
  if (![status.at, status.gateway_at, status.age_ms].every(Number.isFinite)) problems.push(`${where}: times are numbers`);
  if (status.age_ms < 0) problems.push(`${where}: an age is never negative`);
  if (status.age_ms < status.gateway_at - status.at) problems.push(`${where}: the age is counted on the gateway's clock — at least gateway_at − at`);
  if (status.gateway_at < status.at) problems.push(`${where}: the gateway cannot have a number before the source's time of it`);
  if ((status.state === "delayed") !== (status.delay_ms !== null)) problems.push(`${where}: a delay is declared for "delayed" and only for it`);
  if (status.source?.rights === "derived_only" && !status.derived) problems.push(`${where}: a source that allows only derived numbers never has its own figures on a chart`);
  if (status.source?.rights === "internal_only" && audience !== "internal") problems.push(`${where}: a source kept inside the team never reaches a customer's screen`);
  return problems;
}

export function checkBar(i: Instrument, bar: Bar, where: string): string[] {
  const problems: string[] = [];
  if (!Number.isInteger(bar.t)) problems.push(`${where}: t is whole ms`);
  const prices = [bar.o, bar.h, bar.l, bar.c];
  if (!prices.every((p) => typeof p === "string" && UNSIGNED.test(p))) return [...problems, `${where}: o, h, l, c are unsigned decimal strings, not ${JSON.stringify(prices)}`];
  if (compareDecimal(bar.l, bar.o) > 0 || compareDecimal(bar.l, bar.c) > 0 || compareDecimal(bar.h, bar.o) < 0 || compareDecimal(bar.h, bar.c) < 0) problems.push(`${where}: low ≤ open, close ≤ high`);
  if (i.scale === "probability" && compareDecimal(bar.h, "100") > 0) problems.push(`${where}: a probability is at most 100 %`);
  if (bar.v !== null && !UNSIGNED.test(bar.v)) problems.push(`${where}: volume is an unsigned decimal or null`);
  if (bar.turnover !== null && !UNSIGNED.test(bar.turnover)) problems.push(`${where}: turnover is an unsigned decimal or null`);
  if (bar.trades !== null && !(Number.isInteger(bar.trades) && bar.trades >= 0)) problems.push(`${where}: trades are counted whole or null`);
  return problems;
}

export function checkPage(i: Instrument, request: HistoryRequest, page: HistoryPage, audience: ChartAudience): string[] {
  const where = `${request.load} page at ${JSON.stringify(request.resolution)}`;
  const problems: string[] = [];
  if (page.bars.length > request.limit) problems.push(`${where}: no more bars than the limit`);
  if (typeof page.more?.forward !== "boolean" || typeof page.more?.backward !== "boolean") problems.push(`${where}: more says forward and backward`);
  if (page.bars.length === 0 && ((request.load === "forward" && page.more.forward) || (request.load === "backward" && page.more.backward))) problems.push(`${where}: an empty page never says there is more in its direction`);
  if (!UNSIGNED.test(page.display_step) || compareDecimal(page.display_step, "0") <= 0) problems.push(`${where}: the display step is a positive decimal`);
  if (page.multiplier_version !== null && typeof page.multiplier_version !== "string") problems.push(`${where}: the multiplier version is words or null`);
  page.bars.forEach((bar, n) => {
    problems.push(...checkBar(i, bar, `${where}, bar ${n}`));
    const prev = page.bars[n - 1];
    if (prev && prev.t >= bar.t) problems.push(`${where}: bars run oldest first, each open once (${prev.t} then ${bar.t})`);
    if (request.resolution.kind === "time" && !onBoundary(bar.t, request.resolution, i.session)) problems.push(`${where}: bar ${n} opens off its boundary (${bar.t})`);
    if (request.load === "forward" && request.timestamp !== null && bar.t >= request.timestamp) problems.push(`${where}: an older page has only bars before ${request.timestamp}`);
    if (request.load === "backward" && request.timestamp !== null && bar.t <= request.timestamp) problems.push(`${where}: a newer page has only bars after ${request.timestamp}`);
  });
  for (const gap of page.gaps) {
    if (!(gap.from < gap.to)) problems.push(`${where}: a gap runs forward in time`);
    if (!(GAP_REASONS as readonly string[]).includes(gap.reason)) problems.push(`${where}: unknown gap reason "${gap.reason}"`);
    const inside = page.bars.filter((b) => b.t >= gap.from && b.t < gap.to);
    if (inside.length) problems.push(`${where}: no bar inside a gap — ${inside.length} invented in [${gap.from}, ${gap.to})`);
  }
  problems.push(...checkStatus(page.status, audience, where));
  return problems;
}

/**
 * Bars of a longer sub-day resolution against the smallest one: each is the exact roll-up of the smallest bars that
 * open inside it — open of the first, close of the last, the highest high, the lowest low, the sums — and no bar
 * stands where there are none. Only bars whose whole span lies inside the smallest bars' range are compared.
 */
export function checkRollup(resolution: Resolution, base: readonly Bar[], baseSpan: number, rolled: readonly Bar[]): string[] {
  const span = spanMs(resolution);
  const first = base[0];
  const last = base.at(-1);
  if (span === null || !first || !last) return [];
  const where = `roll-up to ${JSON.stringify(resolution)}`;
  const problems: string[] = [];
  const covered = (t: number) => t >= first.t && t + span <= last.t + baseSpan;
  const byOpen = new Map(rolled.map((b) => [b.t, b]));
  const expected = new Map<number, Bar[]>();
  for (const b of base) {
    const open = b.t - (b.t % span);
    if (covered(open)) expected.set(open, [...(expected.get(open) ?? []), b]);
  }
  for (const bar of rolled) if (covered(bar.t) && !expected.has(bar.t)) problems.push(`${where}: a bar at ${bar.t} with no smaller bars under it`);
  for (const [open, members] of expected) {
    const bar = byOpen.get(open);
    if (!bar) {
      problems.push(`${where}: no bar at ${open}, though smaller bars trade inside it`);
      continue;
    }
    const high = members.reduce((m, b) => (compareDecimal(b.h, m) > 0 ? b.h : m), members[0]!.h);
    const low = members.reduce((m, b) => (compareDecimal(b.l, m) < 0 ? b.l : m), members[0]!.l);
    const differs = (name: string, got: string | number | null, want: string | number | null) => {
      const same = typeof got === "string" && typeof want === "string" ? compareDecimal(got, want) === 0 : got === want;
      if (!same) problems.push(`${where} at ${open}: ${name} is ${String(got)}, the roll-up gives ${String(want)}`);
    };
    differs("open", bar.o, members[0]!.o);
    differs("close", bar.c, members.at(-1)!.c);
    differs("high", bar.h, high);
    differs("low", bar.l, low);
    if (members.every((b) => b.v !== null)) differs("volume", bar.v, members.reduce((s, b) => addDecimal(s, b.v!), "0"));
    if (members.every((b) => b.turnover !== null)) differs("turnover", bar.turnover, members.reduce((s, b) => addDecimal(s, b.turnover!), "0"));
    if (members.every((b) => b.trades !== null)) differs("trades", bar.trades, members.reduce((s, b) => s + b.trades!, 0));
  }
  return problems;
}

/**
 * The live stream against what the engine does with it: a later open adds a bar, the same open replaces the last,
 * an earlier one would be dropped by the engine without a word — so it never comes as a bar, only as a correction.
 * One bar is updated at most once a second by the gateway's clock.
 */
export function checkLive(i: Instrument, events: readonly LiveEvent[], newestShown: number | null, audience: ChartAudience): string[] {
  const problems: string[] = [];
  let lastOpen = newestShown;
  let lastUpdate: { t: number; at: number } | null = null;
  let clock = -Infinity;
  events.forEach((event, n) => {
    const where = `live event ${n}`;
    const at = "status" in event ? event.status.gateway_at : event.type === "corrected" ? event.correction.at : null;
    if (at !== null) {
      if (at < clock) problems.push(`${where}: the gateway's clock ran back (${at} after ${clock})`);
      clock = Math.max(clock, at);
    }
    switch (event.type) {
      case "bar": {
        problems.push(...checkBar(i, event.bar, where), ...checkStatus(event.status, audience, where));
        if (lastOpen !== null && event.bar.t < lastOpen) problems.push(`${where}: a bar older than the one shown (${event.bar.t} < ${lastOpen}) — the engine would drop it; it comes as a correction`);
        // The closing update of a bar — the one right before the next bar opens — is exempt from the limit.
        const next = events.slice(n + 1).find((e) => e.type === "bar");
        const closing = next?.type === "bar" && next.bar.t > event.bar.t;
        if (lastUpdate && lastUpdate.t === event.bar.t && event.status.gateway_at - lastUpdate.at < 1_000 && !closing) problems.push(`${where}: one bar updated twice within a second`);
        lastOpen = Math.max(lastOpen ?? event.bar.t, event.bar.t);
        lastUpdate = { t: event.bar.t, at: event.status.gateway_at };
        break;
      }
      case "corrected": {
        const c = event.correction;
        if (!(c.from < c.to) || c.from % 1_000 !== 0 || c.to % 1_000 !== 0) problems.push(`${where}: a correction covers whole seconds, forward in time`);
        if (!(CORRECTION_REASONS as readonly string[]).includes(c.reason)) problems.push(`${where}: unknown correction reason "${c.reason}"`);
        if (c.instrument !== i.id) problems.push(`${where}: a correction names its instrument`);
        break;
      }
      case "gap":
        if (!(event.gap.from < event.gap.to)) problems.push(`${where}: a gap runs forward in time`);
        if (event.status.state !== "gap") problems.push(`${where}: a gap event carries the "gap" state`);
        problems.push(...checkStatus(event.status, audience, where));
        break;
      case "status":
        problems.push(...checkStatus(event.status, audience, where));
        break;
      default:
        problems.push(`${where}: unknown event ${JSON.stringify(event)}`);
    }
  });
  return problems;
}

export function checkSeries(page: SeriesPage, audience: ChartAudience): string[] {
  const { spec } = page;
  const where = `series ${spec.id}`;
  const problems: string[] = [];
  if (!spec.label || !spec.kind) problems.push(`${where}: a series has a kind and a label`);
  if (!(SERIES_UNITS as readonly string[]).includes(spec.unit.kind)) problems.push(`${where}: unknown unit "${spec.unit.kind}"`);
  if ((spec.unit.kind === "asset") !== (spec.unit.asset !== null)) problems.push(`${where}: an asset unit names its asset, and only it`);
  if (spec.unit.per_ms !== null && !(spec.unit.per_ms > 0)) problems.push(`${where}: a rate is per a positive time`);
  if (spec.step_ms !== null && !(Number.isInteger(spec.step_ms) && spec.step_ms > 0)) problems.push(`${where}: points are a whole positive number of ms apart, or come on events`);
  page.points.forEach((p, n) => {
    if (!DECIMAL.test(p.v)) problems.push(`${where}: point ${n} is a decimal string, not ${JSON.stringify(p.v)}`);
    const prev = page.points[n - 1];
    if (prev && prev.t >= p.t) problems.push(`${where}: points run oldest first`);
  });
  problems.push(...checkStatus(page.status, audience, where));
  return problems;
}

export function checkMarks(page: MarksPage, from: number, to: number, audience: ChartAudience): string[] {
  const { marks } = page;
  const problems: string[] = [...checkStatus(page.status, audience, "marks")];
  const ids = new Set<string>();
  marks.forEach((m, n) => {
    const where = `mark ${n}`;
    if (!(MARK_KINDS as readonly string[]).includes(m.kind)) problems.push(`${where}: unknown kind "${m.kind}"`);
    if (!(m.t >= from && m.t < to)) problems.push(`${where}: inside the asked window`);
    if (m.price !== null && !UNSIGNED.test(m.price)) problems.push(`${where}: a price is a decimal string or null`);
    if (m.side !== null && m.side !== "buy" && m.side !== "sell") problems.push(`${where}: side is buy, sell or null`);
    if (!m.label) problems.push(`${where}: a mark has words`);
    if (ids.has(m.id)) problems.push(`${where}: ids are unique`);
    ids.add(m.id);
  });
  return problems;
}

export function checkBook(i: Instrument, book: DomBook, audience: ChartAudience): string[] {
  const problems: string[] = [];
  if (!UNSIGNED.test(book.step) || compareDecimal(book.step, "0") <= 0) return ["the ladder's step is a positive decimal"];
  if (i.price_rule === null && !onStep(book.step, i.tick)) problems.push(`the ladder's step ${book.step} is a whole multiple of the tick ${i.tick}`);
  const side = (levels: DomBook["bids"], name: string, down: boolean) =>
    levels.forEach(([price, size], n) => {
      if (!UNSIGNED.test(price) || !UNSIGNED.test(size) || compareDecimal(size, "0") <= 0) {
        problems.push(`${name} ${n}: price and a positive size as decimal strings`);
        return;
      }
      if (!onStep(price, book.step)) problems.push(`${name} ${n}: ${price} lies on the ladder's step ${book.step}`);
      const prev = levels[n - 1];
      if (prev && UNSIGNED.test(prev[0]) && compareDecimal(prev[0], price) !== (down ? 1 : -1)) problems.push(`${name}: best first, each price once`);
      if (i.scale === "probability" && compareDecimal(price, "100") > 0) problems.push(`${name} ${n}: a probability is at most 100 %`);
    });
  side(book.bids, "bid", true);
  side(book.asks, "ask", false);
  const bid = book.bids[0]?.[0];
  const ask = book.asks[0]?.[0];
  if (bid && ask && UNSIGNED.test(bid) && UNSIGNED.test(ask) && compareDecimal(bid, ask) >= 0) problems.push("the best bid is under the best ask");
  if (!Number.isInteger(book.seq)) problems.push("the book has a sequence number");
  problems.push(...checkStatus(book.status, audience, "book"));
  return problems;
}

// ── Paging the way the engine does ────────────────────────────────────────────────────────────────────────────────

const PAGE = 300;
const MAX_PAGES = 40;

/**
 * Loads history as the engine's store does: `init` replaces, `forward` (older) is put in front while the page says
 * there is more, `backward` (newer) goes after while the page says there is more. Every page is checked on the way.
 */
export async function loadLikeEngine(
  harness: ChartHarness,
  i: Instrument,
  resolution: Resolution,
  basis: PriceBasis,
  problems: string[],
  limit = PAGE,
): Promise<{ bars: Bar[]; pages: HistoryPage[] }> {
  const ask = async (load: HistoryRequest["load"], timestamp: number | null) => {
    const request: HistoryRequest = { instrument: i.id, resolution, basis, load, timestamp, limit };
    const page = await harness.source.history(request);
    problems.push(...checkPage(i, request, page, harness.audience));
    return page;
  };
  const pages: HistoryPage[] = [];
  const init = await ask("init", null);
  pages.push(init);
  if (init.bars.length === 0 && (init.more.forward || init.more.backward)) problems.push("an empty first page says there is more: the engine has no timestamp to ask from");
  let bars = [...init.bars];
  let more = init.more.forward && bars.length > 0;
  for (let n = 0; more && n < MAX_PAGES; n += 1) {
    const page = await ask("forward", bars[0]!.t);
    pages.push(page);
    bars = [...page.bars, ...bars];
    more = page.more.forward && page.bars.length > 0;
  }
  if (more) problems.push(`more than ${MAX_PAGES} older pages: a source ends its history with more.forward = false`);
  more = bars.length > 0;
  for (let n = 0; more && n < MAX_PAGES; n += 1) {
    const page = await ask("backward", bars.at(-1)!.t);
    pages.push(page);
    bars = [...bars, ...page.bars];
    more = page.more.backward && page.bars.length > 0;
  }
  bars.forEach((b, n) => {
    const prev = bars[n - 1];
    if (prev && prev.t >= b.t) problems.push(`pages overlap or leave the order: ${prev.t} then ${b.t}`);
  });
  return { bars, pages };
}

/** Longer than the once-a-second limit: a throttle timer that outlives its subscription has fired by then. */
const afterThrottle = () => new Promise((resolve) => setTimeout(resolve, 1_100));

// ── The suite ─────────────────────────────────────────────────────────────────────────────────────────────────────

/** Registers the chart contract for one source; `factory` gives a fresh harness for each test. */
export function chartContract(name: string, factory: ChartHarnessFactory): void {
  const start = async () => {
    const harness = await factory();
    const instrument = await harness.source.instrument(harness.instrument);
    return { harness, instrument, basis: instrument.bases[0]! };
  };

  describe(`chart contract: ${name}`, () => {
    it("speaks this contract's major version", async () => {
      const { harness } = await start();
      assert.ok(compatibleContract(CHART_CONTRACT, harness.source.contract), `${harness.source.contract} against ${CHART_CONTRACT}`);
    });

    it("describes the instrument whole: kind, steps, multiplier, session, scale, resolutions, bases, the trading basis", async () => {
      const { instrument } = await start();
      assert.deepEqual(checkInstrument(instrument), []);
    });

    it("gives a first page at every resolution it serves, each bar on its boundary, with state, source and age", async () => {
      const { harness, instrument, basis } = await start();
      const problems: string[] = [];
      for (const resolution of instrument.resolutions) {
        const request: HistoryRequest = { instrument: instrument.id, resolution, basis, load: "init", timestamp: null, limit: PAGE };
        const page = await harness.source.history(request);
        problems.push(...checkPage(instrument, request, page, harness.audience));
        if (page.bars.length === 0) problems.push(`no bars at ${JSON.stringify(resolution)}`);
      }
      assert.deepEqual(problems, []);
    });

    it("pages back and forth the way the engine loads them, with no overlap and no hole between pages", async () => {
      const { harness, instrument, basis } = await start();
      const problems: string[] = [];
      const small = await loadLikeEngine(harness, instrument, instrument.min_resolution, basis, problems, 50);
      const whole = await loadLikeEngine(harness, instrument, instrument.min_resolution, basis, problems, 1_500);
      assert.deepEqual(problems, []);
      assert.ok(whole.bars.length > 0, "the source has history");
      assert.deepEqual(small.bars, whole.bars, "small pages and one large page give the same bars");
    });

    it("rolls every longer bar up from the smallest one, exactly, in every basis", async () => {
      const { harness, instrument } = await start();
      const problems: string[] = [];
      const baseSpan = spanMs(instrument.min_resolution);
      assert.ok(baseSpan !== null, "the smallest resolution is under a day");
      let compared = 0;
      for (const basis of instrument.bases) {
        const base = (await loadLikeEngine(harness, instrument, instrument.min_resolution, basis, problems, 1_500)).bars;
        for (const resolution of instrument.resolutions.slice(1)) {
          if (spanMs(resolution) === null) continue;
          const rolled = (await loadLikeEngine(harness, instrument, resolution, basis, problems, 1_500)).bars;
          problems.push(...checkRollup(resolution, base, baseSpan, rolled));
          compared += 1;
        }
      }
      assert.deepEqual(problems, []);
      assert.ok(compared > 0 || instrument.resolutions.length === 1, "at least one longer resolution was compared");
    });

    it("serves every basis it names, and a prediction's two outcomes add up to 100 %", async () => {
      const { harness, instrument } = await start();
      const problems: string[] = [];
      const byOutcome = new Map<string, readonly Bar[]>();
      for (const basis of instrument.bases) {
        const request: HistoryRequest = { instrument: instrument.id, resolution: instrument.min_resolution, basis, load: "init", timestamp: null, limit: PAGE };
        const page = await harness.source.history(request);
        problems.push(...checkPage(instrument, request, page, harness.audience));
        if (basis.outcome) byOutcome.set(basis.outcome, page.bars);
      }
      const yes = byOutcome.get("yes");
      const no = byOutcome.get("no");
      if (yes && no) {
        if (yes.length !== no.length) problems.push("yes and no have the same bars");
        yes.forEach((b, n) => {
          const o = no[n];
          if (!o || o.t !== b.t) {
            problems.push(`yes and no open at the same times: yes at ${b.t}, no at ${o?.t}`);
            return;
          }
          for (const [a, z] of [
            [b.o, o.o],
            [b.c, o.c],
            [b.h, o.l],
            [b.l, o.h],
          ] as const) {
            if (compareDecimal(addDecimal(a, z), "100") !== 0) problems.push(`at ${b.t}: yes ${a} and no ${z} do not add up to 100`);
          }
        });
      }
      assert.deepEqual(problems, []);
    });

    it("keeps the live bar going forward: a later open adds, the same open replaces, an older one comes only as a correction", async (t) => {
      const { harness, instrument, basis } = await start();
      if (!harness.replay) return t.skip("the fixture has no live stream");
      const problems: string[] = [];
      const request = { instrument: instrument.id, resolution: instrument.min_resolution, basis };
      const shown = await harness.source.history({ ...request, load: "init", timestamp: null, limit: PAGE });
      const events: LiveEvent[] = [];
      const stop = harness.source.subscribe(request, (e) => events.push(e));
      await harness.replay();
      await afterThrottle();
      stop();
      const count = events.length;
      await harness.replay();
      await afterThrottle();
      problems.push(...checkLive(instrument, events, shown.bars.at(-1)?.t ?? null, harness.audience));
      assert.deepEqual(problems, []);
      assert.ok(events.some((e) => e.type === "bar"), "the stream brought bars");
      assert.equal(events.length, count, "nothing arrives after the unsubscribe");
      if (harness.truth) {
        // What the screen holds once the stream has played and every correction was reloaded: the bars as built from all trades.
        const after = await loadLikeEngine(harness, instrument, instrument.min_resolution, basis, problems, 1_500);
        assert.deepEqual(problems, []);
        assert.deepEqual(after.bars, await harness.truth(basis), "after the stream, history is the bars of every trade in the chain's order");
        const live = new Map<number, Bar>();
        for (const e of events) if (e.type === "bar") live.set(e.bar.t, e.bar);
        const corrected = events.flatMap((e) => (e.type === "corrected" ? [e.correction] : []));
        for (const bar of after.bars) {
          const sent = live.get(bar.t);
          if (sent && !corrected.some((c) => bar.t >= c.from && bar.t < c.to)) assert.deepEqual(sent, bar, `the last live state of the bar at ${bar.t} is the bar in history`);
        }
      }
    });

    it("gives every series with its unit, every mark in its window with its status, and a book on its step", async () => {
      const { harness, instrument, basis } = await start();
      const problems: string[] = [];
      for (const spec of await harness.source.series(instrument.id)) {
        if (spec.instrument !== instrument.id) problems.push(`series ${spec.id} belongs to the instrument`);
        problems.push(...checkSeries(await harness.source.seriesHistory({ series: spec.id, load: "init", timestamp: null, limit: PAGE }), harness.audience));
      }
      const page = await harness.source.history({ instrument: instrument.id, resolution: instrument.min_resolution, basis, load: "init", timestamp: null, limit: 1_500 });
      const from = page.bars[0]?.t ?? 0;
      const to = (page.bars.at(-1)?.t ?? 0) + 3_600_000;
      problems.push(...checkMarks(await harness.source.marks(instrument.id, from, to), from, to, harness.audience));
      const book = await harness.source.book(instrument.id, instrument.tick);
      if (book) problems.push(...checkBook(instrument, book, harness.audience));
      assert.deepEqual(problems, []);
    });
  });
}
