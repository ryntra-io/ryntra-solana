/**
 * The one contract suite every network adapter passes: intent → execute →
 * reconcile → receipt; a repeat — rebuilt, concurrent or after a silence — is idempotent, and a duplicate that really
 * went out is shown, never hidden; silence is `unknown`, not an error, and the reconciliation settles it; a refusal
 * keeps its words; an order is what the intent asked for. It knows no network: it reads only what the contracts give.
 */
import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { inspect } from "node:util";

import { CAPABILITIES, VENUE_CAPABILITIES } from "../contracts/capabilities.ts";
import type { CapabilityState, VenueCapability } from "../contracts/capabilities.ts";
import { PARAM_KEYS, PARAM_VALUES } from "../contracts/intent.ts";
import type { Amount, Intent } from "../contracts/intent.ts";
import type { NetworkAdapter, ParsedTx, SendResult } from "../contracts/network.ts";
import { RECEIPT_SCHEMA } from "../contracts/receipt.ts";
import type { Receipt } from "../contracts/receipt.ts";
import type { SentPayload, SignedPayload, SignerAdapter, UnsignedPayload } from "../contracts/signer.ts";
import type { OrderAck, VenueAdapter } from "../contracts/venue.ts";
import type { AdapterHarness, HarnessFactory, OrderHarness } from "./harness.ts";
import { UUID_V7 } from "./intents.ts";

const STATUSES = new Set(["on", "later", "off"]);
const KEY_WORDS = /private|secret|seed|mnemonic|keypair/i;
/** The caller's deadline in the silence tests: short, so an adapter that ignores it and waits its own is caught. */
const SILENCE_MS = 60;
/** How long the suite waits for something that should come on a later tick (an event, a reconciliation). */
const SETTLE_MS = 3_000;

function isState(value: unknown): value is CapabilityState {
  if (typeof value !== "object" || value === null) return false;
  const { status, until } = value as { status?: unknown; until?: unknown };
  if (typeof status !== "string" || !STATUSES.has(status)) return false;
  return status !== "later" || (typeof until === "string" && until.trim().length > 0);
}

function assertAmount(amount: Amount | undefined, where: string): asserts amount is Amount {
  assert.ok(amount, `${where}: an amount`);
  assert.match(amount.units, /^\d+$/, `${where}: base units are a decimal string of digits`);
  assert.ok(Number.isInteger(amount.decimals) && amount.decimals >= 0, `${where}: decimals`);
  assert.ok(amount.asset.length > 0, `${where}: asset`);
}

/** Base units as the person reads them: 731937 with 6 decimals is "0.731937". */
function decimal(amount: Amount): string {
  const digits = amount.units.padStart(amount.decimals + 1, "0");
  const whole = digits.slice(0, digits.length - amount.decimals);
  const fraction = digits.slice(digits.length - amount.decimals).replace(/0+$/, "");
  return fraction ? `${whole}.${fraction}` : whole;
}

const sameNumber = (a: string, b: string) => Number(a) === Number(b);

/** A decimal string in base units of `decimals`, exactly: "0.3" with 6 decimals is 300000n; finer than that fails. */
function toUnits(value: string, decimals: number): bigint {
  assert.match(value, /^\d+(\.\d+)?$/, `"${value}" is an unsigned decimal`);
  const [whole = "0", fraction = ""] = value.split(".");
  assert.ok(/^0*$/.test(fraction.slice(decimals)), `"${value}" is finer than ${decimals} decimals`);
  return BigInt(whole + fraction.padEnd(decimals, "0").slice(0, decimals));
}

/** Data fields, one level into nested objects and arrays: where a key would sit if an adapter held one. */
function dataNames(value: object, depth = 0): string[] {
  const names: string[] = [];
  for (const name of Object.getOwnPropertyNames(value)) {
    const child = (value as Record<string, unknown>)[name];
    if (typeof child === "function") continue;
    names.push(name);
    if (depth === 0 && typeof child === "object" && child !== null) names.push(...dataNames(child, 1));
  }
  return names;
}

function venueWith(network: NetworkAdapter, flag: VenueCapability): VenueAdapter | undefined {
  return network.venues().find((venue) => venue.capabilities()[flag].status === "on");
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function waitFor(check: () => boolean | Promise<boolean>, ms = SETTLE_MS): Promise<boolean> {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    if (await check()) return true;
    await sleep(15);
  }
  return check();
}

async function settled(network: NetworkAdapter, txId: string, state: "filled" | "rejected"): Promise<boolean> {
  return waitFor(async () => (await network.status(txId, { signal: AbortSignal.timeout(SETTLE_MS) })).state === state);
}

/** One payload out, as the engine does it, with what went out kept so a repeat can be made of the very same thing. */
interface Out {
  readonly payload: UnsignedPayload;
  readonly result: SendResult;
  readonly signed?: SignedPayload;
  readonly sent?: SentPayload;
}

/**
 * A `sign` signer signs and the adapter sends; a `sign-and-send` wallet sends and the adapter follows. A wallet that
 * says no, or a network that refuses before it goes out, answers as a refusal.
 */
async function putOnChain(network: NetworkAdapter, signer: SignerAdapter, payload: UnsignedPayload, signal?: AbortSignal): Promise<Out> {
  const options = signal ? { signal } : {};
  if (signer.txMode === "sign") {
    const signed = await signer.sign(payload);
    return { payload, result: await network.send(signed, options), signed };
  }
  const wallet = await signer.signAndSend(payload, options);
  if (wallet.state === "declined" || wallet.state === "rejected") return { payload, result: { state: "rejected", reason: wallet.reason } };
  assert.equal(wallet.state, "sent", "the wallet answered (wallet silence has its own test)");
  if (wallet.state !== "sent") throw new Error("unreachable");
  return { payload, result: await network.track(wallet.sent, options), sent: wallet.sent };
}

function txIdOf(result: SendResult): string {
  assert.ok(result.state !== "rejected", `sent, not refused${result.state === "rejected" ? `: ${result.reason.original}` : ""}`);
  return result.tx_id as string;
}

/** Every step of an intent, built as it becomes buildable: a step that needs an earlier one waits for it to be final. */
async function runAllSteps(h: AdapterHarness, intent: Intent, signer: SignerAdapter): Promise<{ outs: Out[]; parsed: ParsedTx[] }> {
  const outs: Out[] = [];
  const parsed: ParsedTx[] = [];
  for (let guard = 0; guard < 16; guard++) {
    const payloads = await h.network.build(intent, { from: parsed.length, previous: parsed });
    if (payloads.length === 0) return { outs, parsed };
    for (const payload of payloads) {
      assert.equal(payload.intent_id, intent.intent_id, "every payload carries its intent");
      assert.equal(payload.step_id, parsed.length, "payloads are numbered 0, 1, … in order");
      assert.equal(payload.network, h.network.id, "every payload names this network");
      assert.equal((await h.network.simulate(payload)).ok, true, "the harness intent simulates clean");
      const out = await putOnChain(h.network, signer, payload);
      outs.push(out);
      const txId = txIdOf(out.result);
      assert.ok(await settled(h.network, txId, "filled"), `step ${payload.step_id} fills`);
      const p = await h.network.parse(txId);
      assert.ok(p, "a final transaction parses");
      parsed.push(p);
    }
  }
  throw new Error("build never said the intent has no more steps");
}

/** What the engine will do with an adapter's answers: one receipt of schema `ryntra.flight-log/1`. */
async function runToReceipt(h: AdapterHarness, intent: Intent): Promise<{ receipt: Receipt; outs: Out[]; signer: SignerAdapter }> {
  const { signer } = await h.network.connect(h.walletId);
  assert.deepEqual(signer.canSign(intent), { ok: true }, "the wallet can sign the harness intent");
  const { outs, parsed } = await runAllSteps(h, intent, signer);
  assert.ok(parsed.length > 0, "at least one transaction");
  const last = parsed.at(-1) as ParsedTx;
  const receipt: Receipt = {
    schema: RECEIPT_SCHEMA,
    intent_id: intent.intent_id,
    operation_id: intent.intent_id,
    action: intent.action,
    venue: intent.venue,
    network: intent.network,
    params: intent.params,
    amounts: { expected: intent.amounts, actual: last.amounts_actual },
    fees: last.fees,
    tx: last.tx,
    fx: { usd: "1", source: "test", at: Date.now() },
    anchor: null,
    signer: signer.id,
    signature: last.tx.id,
    state: last.state,
  };
  return { receipt, outs, signer };
}

/** A signer that counts its signatures: the suite checks one action is one signature. */
function counting(signer: SignerAdapter): { signer: SignerAdapter; count: () => number } {
  let n = 0;
  const common = {
    id: signer.id,
    kind: signer.kind,
    label: signer.label,
    expiresAt: signer.expiresAt,
    limits: signer.limits,
    authorizedBy: signer.authorizedBy,
    canSign: (intent: Intent) => signer.canSign(intent),
    sign: (payload: UnsignedPayload) => (n++, signer.sign(payload)),
  };
  const wrapped: SignerAdapter =
    signer.txMode === "sign" ? { ...common, txMode: "sign" } : { ...common, txMode: "sign-and-send", signAndSend: (p, o) => (n++, signer.signAndSend(p, o)) };
  return { signer: wrapped, count: () => n };
}

function intentsOf(h: AdapterHarness): Intent[] {
  const list = [h.chainIntent(), h.foreignSignerIntent()];
  if (h.multiTxIntent) list.push(h.multiTxIntent());
  if (h.swapIntent) list.push(h.swapIntent());
  if (h.orders) {
    const o = h.orders;
    const resting = o.resting();
    list.push(resting, o.market(), o.market("sell"), o.bracket(), o.partial(), o.modify(resting, "1"), o.modify(resting, "1", 2), o.cancel(resting), o.cancel(resting, 1));
  }
  return list;
}

/** Everything the adapter could have written — its log and the console, objects in full — for `run` and a moment after. */
async function capturing(h: AdapterHarness, run: () => Promise<void>): Promise<string> {
  const lines: string[] = [];
  const show = (arg: unknown) => (typeof arg === "string" ? arg : inspect(arg, { depth: 8, breakLength: Infinity }));
  const methods = ["log", "info", "warn", "error", "debug", "dir", "trace", "table"] as const;
  const target = console as unknown as Record<string, unknown>;
  const saved = methods.map((m) => target[m]);
  for (const m of methods) target[m] = (...args: unknown[]) => void lines.push(args.map(show).join(" "));
  const restore = () => methods.forEach((m, i) => (target[m] = saved[i]));
  try {
    await run();
    await sleep(250);
  } catch (error) {
    restore();
    for (const line of lines) console.error(line);
    throw error;
  } finally {
    restore();
  }
  return [...h.logs, ...lines].join("\n");
}

/**
 * Whether the log shows this sum: its digits not glued to other digits — `7317317n`, `amount_7317317`, `7,317,317`
 * count; `#1` and a longer number do not — or its decimal form with any trailing zeros (`7.317317`, `7.31731700`).
 */
function showsSum(log: string, amount: Amount): boolean {
  const flat = log.replace(/(?<=\d)[,_'\u00a0\u202f\u2009](?=\d)/g, "");
  const units = amount.units.replace(/^0+(?=\d)/, "");
  if (new RegExp(`(?<![\\d.,])${units}(?!\\d)`).test(flat)) return true;
  const shown = decimal(amount);
  const tail = shown.includes(".") ? "0*" : "(?:[.,]0*)?";
  const point = shown.replace(".", "[.,]");
  return new RegExp(`(?<![\\d.,])${point}${tail}(?!\\d)`).test(flat) || new RegExp(`(?<![\\d.,])${point}${tail}(?!\\d)`).test(log);
}

/** Whether a line shows the address, whole or cut to its ends (`StubA…1111`); `0x` addresses in any case. */
function showsAddress(log: string, address: string): boolean {
  const evm = address.startsWith("0x");
  const norm = (text: string) => (evm ? text.toLowerCase() : text);
  const whole = norm(address);
  const core = evm ? whole.slice(2) : whole;
  return log.split("\n").some((line) => {
    const l = norm(line);
    return l.includes(whole) || (l.includes(core.slice(0, 4)) && l.includes(core.slice(-4)));
  });
}

export function adapterContract(name: string, makeHarness: HarnessFactory): void {
  describe(`${name}: the adapter contract`, () => {
    it("names itself and its venues for the screen and declares their deadlines", async () => {
      const { network } = await makeHarness();
      assert.ok(network.id.trim().length > 0, "id");
      assert.ok(network.label.trim().length > 0, "label: the screen prints it, never a literal of its own");
      assert.ok(network.timing.unknown_after_ms >= 10 * SILENCE_MS, "unknown_after_ms, long enough for the deadline tests to mean something");
      for (const venue of network.venues()) {
        assert.ok(venue.timing.unknown_after_ms >= 10 * SILENCE_MS, `${venue.id}: its own deadline`);
        assert.ok(Number.isInteger(venue.maxLegs) && venue.maxLegs >= 1, `${venue.id}: maxLegs ≥ 1`);
      }
    });

    it("the harness intents are what the engine makes: UUID v7 ids, the shared parameter names and words", async () => {
      const h = await makeHarness();
      for (const intent of intentsOf(h)) {
        assert.match(intent.intent_id, UUID_V7, "intent_id is a UUID v7");
        for (const params of [intent.params, ...(intent.legs ?? []).map((l) => l.params)]) {
          for (const [key, value] of Object.entries(params)) {
            assert.ok((PARAM_KEYS as readonly string[]).includes(key), `params.${key} is one of PARAM_KEYS`);
            if (key in PARAM_VALUES) assert.ok((PARAM_VALUES[key as keyof typeof PARAM_VALUES] as readonly unknown[]).includes(value), `params.${key} = ${String(value)} is one of PARAM_VALUES`);
          }
        }
      }
    });

    it("capabilities(): every flag, each in a known state, the same on every call", async () => {
      const { network } = await makeHarness();
      const caps = network.capabilities();
      assert.deepEqual(Object.keys(caps).sort(), [...CAPABILITIES].sort(), "complete and nothing extra");
      for (const flag of CAPABILITIES) assert.ok(isState(caps[flag]), `${flag}: on, off, or later with its release caption`);
      assert.deepEqual(network.capabilities(), caps, "stable between calls");
    });

    it("venues belong to this network, and the network's trading flags are exactly its venues' flags", async () => {
      const { network } = await makeHarness();
      const venues = network.venues();
      assert.equal(new Set(venues.map((v) => v.id)).size, venues.length, "venue ids are unique");
      for (const venue of venues) {
        assert.equal(venue.network, network.id, `${venue.id} belongs to ${network.id}`);
        assert.ok(venue.label.trim().length > 0, `${venue.id}: label`);
        const caps = venue.capabilities();
        assert.deepEqual(Object.keys(caps).sort(), [...VENUE_CAPABILITIES].sort(), `${venue.id}: complete venue flags`);
        for (const flag of VENUE_CAPABILITIES) assert.ok(isState(caps[flag]), `${venue.id}.${flag}: a known state`);
      }
      for (const flag of VENUE_CAPABILITIES) {
        const onNetwork = network.capabilities()[flag].status === "on";
        assert.equal(onNetwork, venueWith(network, flag) !== undefined, `${flag}: "on" on the network ⇔ "on" on one of its venues`);
      }
    });

    it("perps, where on, is a venue of this network with perp markets, limits, fees and health", async () => {
      const { network } = await makeHarness();
      if (network.capabilities().perps.status !== "on") return;
      const venue = venueWith(network, "perps");
      assert.ok(venue, "a perps venue");
      const markets = await venue.markets();
      assert.ok(markets.some((m) => m.kind === "perp"), "it lists perp markets");
      for (const market of markets) {
        const limits = await venue.limits(market.id);
        assert.equal(limits.tick, market.tick, `${market.id}: limits agree with the market`);
        assert.equal(limits.lot, market.lot, `${market.id}: limits agree with the market`);
      }
      const schedule = await venue.feeSchedule();
      assert.ok(schedule.length > 0, "a fee schedule");
      for (const row of schedule) assert.ok(Number.isFinite(row.bps), "fee rows in bps (a rebate is negative)");
      assert.ok(["ok", "degraded", "down"].includes((await venue.health()).state), "health state");
    });

    it("wallet: lists wallets, connects one as a signer, reads balances", async () => {
      const h = await makeHarness();
      assert.ok((await h.network.wallets()).some((w) => w.id === h.walletId), "the harness wallet is listed");
      const connection = await h.network.connect(h.walletId);
      assert.ok(connection.address.length > 0, "an address");
      assert.equal(connection.signer.kind, "wallet", "a connected wallet signs as a wallet");
      assert.equal(connection.signer.authorizedBy, null, "the main wallet answers to no one");
      if (connection.signer.txMode === "sign-and-send") assert.equal(typeof connection.signer.signAndSend, "function");
      const balances = await h.network.balances(connection.address);
      assert.ok(balances.length > 0, "the harness wallet has a balance to show");
      for (const balance of balances) assertAmount(balance.amount, `balance ${balance.asset}`);
    });

    it("deposit routes name source, asset, venue, margin account and bridge; a network with perps says how money reaches them", async () => {
      const { network } = await makeHarness();
      const venueIds = new Set(network.venues().map((v) => v.id));
      const routes = await network.depositRoutes();
      for (const route of routes) {
        assert.ok(venueIds.has(route.venue), `${route.id} arrives on a venue of ${network.id}`);
        assert.ok(route.source.network.length > 0 && route.source.asset.length > 0, `${route.id}: where the collateral leaves from`);
        assert.ok(route.asset.length > 0 && route.account.trim().length > 0, `${route.id}: what arrives and in which margin account`);
        assert.equal(route.bridge === null, route.source.network === network.id, `${route.id}: a bridge exactly when it leaves another network — no bridge is still a deposit`);
        assertAmount(route.minimum, `${route.id} minimum`);
        assert.ok(route.label.trim().length > 0, `${route.id}: label`);
      }
      const perps = venueWith(network, "perps");
      if (perps) assert.ok(routes.some((r) => r.venue === perps.id), "a route to the perps venue");
    });

    it("intent → build → sign → put on chain → status → parse → one receipt with the actual amounts", async () => {
      const h = await makeHarness();
      const intent = h.chainIntent();
      const { receipt, outs } = await runToReceipt(h, intent);
      const txId = txIdOf((outs.at(-1) as Out).result);
      assert.equal(receipt.state, "filled");
      assert.equal(receipt.tx.id, txId);
      assertAmount(receipt.amounts.actual.in, "actual in");
      assert.equal(receipt.amounts.actual.in.asset, intent.amounts.in?.asset, "actual and expected are the same asset");
      assert.equal(receipt.amounts.actual.in.units, intent.amounts.in?.units, "what left the wallet is what the intent fixed");
      assert.ok(Object.values(receipt.fees).some(Boolean), "at least one fee line, never «included»");
      const url = new URL(h.network.explorerUrl(txId));
      assert.equal(url.protocol, "https:", "the explorer link is https");
      assert.ok(url.href.includes(encodeURIComponent(txId)), "the explorer link names the transaction");
    });

    it("an intent of several steps: each built when it can be, its own transaction, each idempotent", async () => {
      const h = await makeHarness();
      if (!h.multiTxIntent) return;
      const intent = h.multiTxIntent();
      const { signer } = await h.network.connect(h.walletId);
      const before = h.control.effects();
      const { outs, parsed } = await runAllSteps(h, intent, signer);
      assert.ok(parsed.length >= 2, "more than one step");
      const ids = outs.map((o) => txIdOf(o.result));
      assert.equal(new Set(ids).size, ids.length, "one transaction per step, none dropped");
      assert.equal(h.control.effects() - before, ids.length);
      const second = outs[1] as Out;
      const again = second.signed ? await h.network.send(second.signed) : await h.network.track(second.sent as SentPayload);
      assert.equal(txIdOf(again), ids[1], "a repeat of step 1 is step 1");
      assert.equal(h.control.effects() - before, ids.length, "and makes nothing new");
      for (const [i, out] of outs.entries()) assert.equal(await h.network.find(out.payload, { signal: AbortSignal.timeout(SETTLE_MS) }), ids[i], `find gives step ${i} its own transaction`);
      const beyond = { ...(outs.at(-1) as Out).payload, step_id: outs.length };
      assert.equal(await h.network.find(beyond, { signal: AbortSignal.timeout(500) }), null, "nothing for a step that never went out");
    });

    it("put on chain is idempotent; a duplicate a wallet really sent is shown with its own id, never hidden", async () => {
      const h = await makeHarness();
      const intent = h.chainIntent();
      const { signer } = await h.network.connect(h.walletId);
      const [payload] = await h.network.build(intent);
      assert.ok(payload);
      const before = h.control.effects();
      const first = await putOnChain(h.network, signer, payload);
      const firstId = txIdOf(first.result);
      if (first.signed) {
        assert.equal(txIdOf(await h.network.send(first.signed)), firstId, "the same signed payload: the same transaction");
        const [rebuilt] = await h.network.build(intent);
        assert.ok(rebuilt);
        assert.equal(txIdOf((await putOnChain(h.network, signer, rebuilt)).result), firstId, "rebuilt and re-signed: still the first transaction");
        assert.equal(h.control.effects() - before, 1, "one transaction exists");
      } else {
        assert.equal(txIdOf(await h.network.track(first.sent as SentPayload)), firstId, "followed twice: the same transaction");
        const [rebuilt] = await h.network.build(intent);
        assert.ok(rebuilt);
        const duplicate = await putOnChain(h.network, signer, rebuilt);
        if (duplicate.result.state === "rejected") {
          assert.equal(h.control.effects() - before, 1, "a second send the network refused (a reused nonce) made nothing");
        } else {
          assert.equal(h.control.effects() - before, 2, "the wallet really sent two");
          assert.equal(duplicate.result.state, "sent");
          if (duplicate.result.state === "sent") {
            assert.notEqual(duplicate.result.tx_id, firstId, "the second transaction keeps its own id");
            assert.equal(duplicate.result.duplicate_of, firstId, "and is marked a duplicate of the first");
          }
        }
      }
      const [other] = await h.network.build(h.chainIntent());
      assert.ok(other);
      assert.notEqual(txIdOf((await putOnChain(h.network, signer, other)).result), firstId, "a new intent is a new transaction");
    });

    it("find: the transaction of an intent and step is found on chain; one never sent is not", async () => {
      const h = await makeHarness();
      const { signer } = await h.network.connect(h.walletId);
      const [payload] = await h.network.build(h.chainIntent());
      const [never] = await h.network.build(h.chainIntent());
      assert.ok(payload && never);
      const txId = txIdOf((await putOnChain(h.network, signer, payload)).result);
      assert.ok(await waitFor(async () => (await h.network.find(payload, { signal: AbortSignal.timeout(SETTLE_MS) })) === txId), "found after a reload");
      assert.equal(await h.network.find(never, { signal: AbortSignal.timeout(500) }), null, "nothing for a payload that never went out");
    });

    it("network silence is unknown by the caller's deadline, never an error; when it lifts, the reconciliation settles it", async () => {
      const h = await makeHarness();
      const { signer } = await h.network.connect(h.walletId);
      const [payload] = await h.network.build(h.chainIntent());
      assert.ok(payload);
      h.control.silence(true);
      let started = Date.now();
      const { result } = await putOnChain(h.network, signer, payload, AbortSignal.timeout(SILENCE_MS));
      assert.ok(result.state === "sent" || result.state === "unknown", `sent or unknown, not ${result.state}`);
      assert.ok(Date.now() - started < SILENCE_MS + 500, "answered by the caller's deadline");
      const txId = txIdOf(result);
      const broadcast = h.control.effects();
      if (signer.txMode === "sign") {
        const again = await putOnChain(h.network, signer, payload, AbortSignal.timeout(SILENCE_MS));
        assert.equal(txIdOf(again.result), txId, "a resend while the result is unknown answers with the same id");
        assert.equal(h.control.effects(), broadcast, "and sends nothing again");
      }
      started = Date.now();
      assert.equal((await h.network.status(txId, { signal: AbortSignal.timeout(SILENCE_MS) })).state, "unknown");
      assert.ok(Date.now() - started < SILENCE_MS + 500, "status answered by the caller's deadline, not the network's own");
      started = Date.now();
      assert.equal((await h.network.status(txId)).state, "unknown", "with no signal, by the adapter's own deadline");
      assert.ok(Date.now() - started < h.network.timing.unknown_after_ms + 1_000, "within timing.unknown_after_ms");
      assert.equal(await h.network.parse(txId, { signal: AbortSignal.timeout(SILENCE_MS) }), null, "nothing to parse while it is not final");
      started = Date.now();
      await h.network.find(payload, { signal: AbortSignal.timeout(SILENCE_MS) });
      assert.ok(Date.now() - started < SILENCE_MS + 500, "find answers by the caller's deadline too");
      h.control.silence(false);
      assert.ok(await settled(h.network, txId, "filled"), "the broadcast before the timeout is reconciled to filled");
      assert.equal((await h.network.parse(txId))?.state, "filled", "and it parses");
      assert.equal(h.control.effects(), broadcast, "one transaction in all");
    });

    it("sign-and-send: a sent answer goes straight to submitted; a «no» in the wallet keeps its words and sends nothing", async () => {
      const h = await makeHarness();
      const { signer } = await h.network.connect(h.walletId);
      if (signer.txMode !== "sign-and-send") return;
      const [payload] = await h.network.build(h.chainIntent());
      assert.ok(payload);
      const answer = await signer.signAndSend(payload);
      assert.equal(answer.state, "sent", "the wallet gives the id of what it sent");
      if (answer.state !== "sent") return;
      const followed = await h.network.track(answer.sent);
      assert.equal(followed.state, "sent", "submitted, with no separate signed step");
      const [other] = await h.network.build(h.chainIntent());
      assert.ok(other);
      const before = h.control.effects();
      h.control.decline("User rejected the request.");
      const no = await signer.signAndSend(other);
      h.control.decline(null);
      assert.equal(no.state, "declined");
      if (no.state === "declined") assert.equal(no.reason.original, "User rejected the request.", "the wallet's words");
      assert.equal(h.control.effects(), before, "nothing went out");
    });

    it("after a dropped connection the subscription comes back by itself and reports what happened meanwhile", async () => {
      const h = await makeHarness();
      const { address, signer } = await h.network.connect(h.walletId);
      const seen: string[] = [];
      const subscription = h.network.subscribe(address, (event) => {
        if (event.kind === "tx") seen.push(event.tx_id);
      });
      await subscription.ready;
      h.control.dropConnection();
      const [payload] = await h.network.build(h.chainIntent());
      assert.ok(payload);
      const txId = txIdOf((await putOnChain(h.network, signer, payload)).result);
      assert.ok(await waitFor(() => seen.includes(txId)), "the transaction made while the connection was down is reported");
      const [next] = await h.network.build(h.chainIntent());
      assert.ok(next);
      const nextId = txIdOf((await putOnChain(h.network, signer, next)).result);
      assert.ok(await waitFor(() => seen.includes(nextId)), "and the subscription keeps working");
      subscription.stop();
    });

    it("wallet silence: unknown by the caller's deadline; what went out is found, followed and settled", async () => {
      const h = await makeHarness();
      const { signer } = await h.network.connect(h.walletId);
      if (signer.txMode !== "sign-and-send") return;
      const [payload] = await h.network.build(h.chainIntent());
      assert.ok(payload);
      const before = h.control.effects();
      h.control.silenceWallet(true);
      const started = Date.now();
      const answer = await signer.signAndSend(payload, { signal: AbortSignal.timeout(SILENCE_MS) });
      assert.equal(answer.state, "unknown", "no answer is unknown, not an error");
      assert.ok(Date.now() - started < SILENCE_MS + 500, "by the caller's deadline");
      h.control.silenceWallet(false);
      let found: string | null = null;
      assert.ok(await waitFor(async () => (found = await h.network.find(payload, { signal: AbortSignal.timeout(SETTLE_MS) })) !== null), "the transaction is found by its intent");
      const txId = txIdOf(await h.network.track({ payload, signer_id: signer.id, tx_id: found as unknown as string }));
      assert.ok(await settled(h.network, txId, "filled"), "and settles");
      assert.equal(h.control.effects() - before, 1, "one transaction in all: a lost answer is found and reconciled, never sent again");
    });

    it("a preflight refusal keeps the network's words verbatim, sends nothing, and the intent stays refused", async () => {
      const h = await makeHarness();
      const words = "Transaction simulation failed: insufficient funds for fee";
      const { signer } = await h.network.connect(h.walletId);
      const [payload] = await h.network.build(h.chainIntent());
      assert.ok(payload);
      h.control.refuse(words);
      const simulation = await h.network.simulate(payload);
      assert.equal(simulation.ok, false, "simulate refuses");
      if (!simulation.ok) assert.equal(simulation.reason.original, words, "simulate: the original words");
      const before = h.control.effects();
      const out = await putOnChain(h.network, signer, payload);
      assert.equal(out.result.state, "rejected");
      if (out.result.state === "rejected") assert.equal(out.result.reason.original, words, "the original words");
      assert.equal(h.control.effects(), before, "nothing went out");
      h.control.refuse(null);
      if (out.signed) {
        const again = await h.network.send(out.signed);
        assert.equal(again.state, "rejected", "a refused intent stays refused: a retry is a new intent");
      }
    });

    it("a failure on chain keeps the network's words verbatim in status and parse", async () => {
      const h = await makeHarness();
      const words = "Program failed to complete: custom program error: 0x1771";
      const { signer } = await h.network.connect(h.walletId);
      const [payload] = await h.network.build(h.chainIntent());
      assert.ok(payload);
      h.control.failOnChain(words);
      const txId = txIdOf((await putOnChain(h.network, signer, payload)).result);
      assert.ok(await settled(h.network, txId, "rejected"), "rejected");
      assert.equal((await h.network.status(txId)).reason?.original, words, "status: the original words");
      const parsed = await h.network.parse(txId);
      assert.equal(parsed?.state, "rejected");
      assert.equal(parsed?.reason?.original, words, "parse: the original words");
    });

    it("a signer refuses a foreign intent with text for Review", async () => {
      const h = await makeHarness();
      const { signer } = await h.network.connect(h.walletId);
      const decision = signer.canSign(h.foreignSignerIntent());
      assert.equal(decision.ok, false);
      if (!decision.ok) assert.ok(decision.reason.original.trim().length > 0, "the refusal has words");
    });

    it("identity: a sign-in verifies only for its own message, signature and address", async () => {
      const h = await makeHarness();
      const { address, signer } = await h.network.connect(h.walletId);
      const request = { address, nonce: "n-0001", domain: "ryntra.io", issued_at: 1_760_270_000_000 };
      const message = h.network.identity.message(request);
      assert.equal(message.kind, "message");
      const signed = await signer.sign(message);
      assert.equal(await h.network.identity.verify(signed, address), true, "verifies for the signer's address");
      assert.equal(await h.network.identity.verify(signed, `${address}x`), false, "not for another address");
      const mid = Math.floor(signed.signature.length / 2);
      const swap = [...new Set(signed.signature)].find((c) => c !== signed.signature[mid]) ?? "";
      const flipped = signed.signature.slice(0, mid) + swap + signed.signature.slice(mid + 1);
      assert.equal(await h.network.identity.verify({ ...signed, signature: flipped }, address), false, "not with a changed signature");
      const otherNonce = h.network.identity.message({ ...request, nonce: "n-0002" });
      assert.equal(await h.network.identity.verify({ ...signed, payload: otherNonce }, address), false, "not for another nonce");
      const otherDomain = h.network.identity.message({ ...request, domain: "example.invalid" });
      assert.equal(await h.network.identity.verify({ ...signed, payload: otherDomain }, address), false, "not for another domain");
    });

    it("subscribe reports the transaction on a later tick once ready; stop ends the reports", async () => {
      const h = await makeHarness();
      const { address, signer } = await h.network.connect(h.walletId);
      const seen: string[] = [];
      const subscription = h.network.subscribe(address, (event) => {
        if (event.kind === "tx") seen.push(event.tx_id);
      });
      await subscription.ready;
      const [first] = await h.network.build(h.chainIntent());
      assert.ok(first);
      const syncSeen = seen.length;
      let pending: Promise<SendResult>;
      if (signer.txMode === "sign") {
        const signed = await signer.sign(first);
        pending = h.network.send(signed);
        assert.equal(seen.length, syncSeen, "no event inside the send call itself");
      } else {
        const going = signer.signAndSend(first);
        assert.equal(seen.length, syncSeen, "no event inside the wallet call itself");
        const wallet = await going;
        assert.equal(wallet.state, "sent");
        if (wallet.state !== "sent") throw new Error("unreachable");
        pending = h.network.track(wallet.sent);
      }
      const txId = txIdOf(await pending);
      assert.ok(await waitFor(() => seen.includes(txId)), "the transaction was reported");
      subscription.stop();
      const count = seen.length;
      const [second] = await h.network.build(h.chainIntent());
      assert.ok(second);
      const secondId = txIdOf((await putOnChain(h.network, signer, second)).result);
      await settled(h.network, secondId, "filled");
      await sleep(250);
      assert.equal(seen.length, count, "nothing after stop");
    });

    it("holds no keys, and writes neither addresses nor sums — on success, refusal, silence and failure", async () => {
      const h = await makeHarness();
      const used: Intent[] = [];
      const take = (intent: Intent) => (used.push(intent), intent);
      const { address, signer } = await h.network.connect(h.walletId);
      const log = await capturing(h, async () => {
        await runToReceipt(h, take(h.chainIntent()));
        for (const control of ["refuse", "failOnChain"] as const) {
          h.control[control]("no");
          const [p] = await h.network.build(take(h.chainIntent()));
          if (p) await putOnChain(h.network, signer, p);
          h.control[control](null);
        }
        h.control.silence(true);
        const [quiet] = await h.network.build(take(h.chainIntent()));
        if (quiet) await putOnChain(h.network, signer, quiet, AbortSignal.timeout(SILENCE_MS));
        h.control.silence(false);
        if (signer.txMode === "sign-and-send") {
          h.control.silenceWallet(true);
          const [lost] = await h.network.build(take(h.chainIntent()));
          if (lost) await signer.signAndSend(lost, { signal: AbortSignal.timeout(SILENCE_MS) });
          h.control.silenceWallet(false);
        }
        if (h.orders) {
          const o = h.orders;
          const venue = h.network.venues().find((v) => v.id === o.venue);
          const orderSigner = await o.signer();
          if (venue) {
            await venue.place(take(o.market()), orderSigner);
            await venue.place(take(o.bracket()), orderSigner);
            await venue.place(take(o.partial()), orderSigner);
            const resting = take(o.resting());
            await venue.place(resting, orderSigner);
            await venue.modify(take(o.modify(resting, "89")), orderSigner);
            await venue.cancel(take(o.cancel(resting)), orderSigner);
            h.control.silence(true);
            await venue.place(take(o.resting()), orderSigner, { signal: AbortSignal.timeout(SILENCE_MS) });
            h.control.silence(false);
            h.control.refuse("no");
            await venue.place(take(o.resting()), orderSigner);
            h.control.refuse(null);
          }
        }
      });
      for (const holder of [h.network, h.network.identity, signer, ...h.network.venues()] as object[]) {
        assert.deepEqual(dataNames(holder).filter((n) => KEY_WORDS.test(n)), [], "no field that would hold a key");
      }
      assert.equal(showsAddress(log, address), false, "no address, whole or cut, in the logs");
      const sums = used.flatMap((i) => [i.amounts, ...(i.legs ?? []).map((l) => l.amounts ?? {})]).flatMap((a) => Object.values(a)).filter((a): a is Amount => Boolean(a));
      for (const amount of sums) {
        assertAmount(amount, "a harness sum");
        assert.ok(amount.units.replace(/^0+/, "").replace(/0+$/, "").length >= 5, `harness sums need five or more significant digits to be found in a log (${amount.units})`);
      }
      for (const amount of sums) assert.equal(showsSum(log, amount), false, `no sum in the logs, in units or as the person reads it (${amount.units})`);
    });

    it("a swap venue quotes a minimum no better than the expectation, and the quote has a life", async () => {
      const h = await makeHarness();
      const venue = venueWith(h.network, "swap");
      if (!venue) return;
      assert.ok(h.swapIntent, "a network with swap on gives the suite a swap intent");
      const intent = h.swapIntent();
      const quote = await venue.quote(intent);
      assert.equal(quote.intent_id, intent.intent_id);
      assertAmount(quote.out_expected, "out_expected");
      assertAmount(quote.out_min, "out_min");
      assert.ok(BigInt(quote.out_min.units) <= BigInt(quote.out_expected.units), "out_min ≤ out_expected");
      assert.ok(quote.at < quote.expires_at, "a quote lives a while and then ends");
      assert.ok(quote.route.trim().length > 0, "a route the person can read");
    });

    describe("orders on the clob or perps venue", () => {
      const setup = async () => {
        const h = await makeHarness();
        if (!h.orders) {
          assert.equal(venueWith(h.network, "clob"), undefined, "clob on, but no order harness");
          assert.equal(venueWith(h.network, "perps"), undefined, "perps on, but no order harness");
          return null;
        }
        const venue = h.network.venues().find((v) => v.id === h.orders?.venue);
        assert.ok(venue, "the order venue is one of the network's venues");
        return { h, o: h.orders as OrderHarness, venue, signer: await h.orders.signer() };
      };
      const openFor = async (venue: VenueAdapter, account: string, intent: Intent) =>
        (await venue.openOrders(account)).filter((x) => x.intent_id === intent.intent_id).sort((a, b) => a.leg - b.leg);

      it("a limit order rests as asked — side, price, size — once and under one signature, even asked twice at once", async () => {
        const s = await setup();
        if (!s) return;
        const { signer, count } = counting(s.signer);
        const order = s.o.resting();
        assert.deepEqual(signer.canSign(order), { ok: true }, "the order signer can sign the order");
        const before = s.h.control.effects();
        const [a, b] = await Promise.all([s.venue.place(order, signer), s.venue.place(order, signer)]);
        assert.equal(a.state, "resting");
        assert.ok(a.legs[0]?.order_id && a.legs[0]?.client_id, "the venue's ids");
        assert.deepEqual(b.legs, a.legs, "the same intent is the same order");
        assert.equal(s.h.control.effects() - before, 1, "one order exists");
        assert.equal(count(), 1, "one signature");
        const [open, ...more] = await openFor(s.venue, s.o.account, order);
        assert.equal(more.length, 0, "one open order for the intent");
        assert.ok(open);
        assert.equal(open.side, order.params.side, "the side asked");
        assert.ok(sameNumber(open.price, String(order.params.price)), "the price asked");
        assert.ok(order.amounts.in && sameNumber(open.size, decimal(order.amounts.in)), "the size asked");
        assert.equal(open.role, "order");
        const cancel = s.o.cancel(order);
        const cancelled = await s.venue.cancel(cancel, signer);
        assert.equal(cancelled.state, "cancelled");
        assert.deepEqual(await s.venue.cancel(cancel, signer), cancelled, "the same cancel twice is one cancel");
        assert.equal((await openFor(s.venue, s.o.account, order)).length, 0);
      });

      it("after an unknown, placing the same intent again finds the order instead of making a second", async () => {
        const s = await setup();
        if (!s) return;
        const order = s.o.resting();
        const before = s.h.control.effects();
        s.h.control.silence(true);
        const started = Date.now();
        const lost = await s.venue.place(order, s.signer, { signal: AbortSignal.timeout(SILENCE_MS) });
        assert.equal(lost.state, "unknown", "silence is unknown, never a rejection");
        assert.ok(Date.now() - started < SILENCE_MS + 500, "by the caller's deadline");
        const noSignal = Date.now();
        assert.equal((await s.venue.place(order, s.signer)).state, "unknown", "with no signal, unknown by the venue's own deadline");
        assert.ok(Date.now() - noSignal < s.venue.timing.unknown_after_ms + 1_000);
        s.h.control.silence(false);
        assert.equal((await s.venue.place(order, s.signer)).state, "resting");
        assert.ok(s.h.control.effects() - before <= 1, "at most one order exists");
        assert.equal((await openFor(s.venue, s.o.account, order)).length, 1, "exactly one open order for the intent");
      });

      for (const side of ["buy", "sell"] as const) {
        it(`a market ${side} fills on that side; the fill names its intent and leg; a perps position points the right way`, async () => {
          const s = await setup();
          if (!s) return;
          const order = s.o.market(side);
          const ack = await s.venue.place(order, s.signer);
          assert.equal(ack.state, "filled");
          const fills = (await s.venue.fills(s.o.account, 0)).filter((f) => f.intent_id === order.intent_id);
          assert.ok(fills.length > 0, "the fill points back to the intent");
          for (const fill of fills) {
            assert.equal(fill.leg, 0);
            assert.equal(fill.side, side, "the side asked");
            assert.equal(fill.client_id, ack.legs[0]?.client_id, "the fill carries the leg's client id");
            assert.ok(fill.tx.id.length > 0, "a reference for the receipt");
            assert.ok(["maker", "taker"].includes(fill.role), "the role decides the fee line");
          }
          const asked = order.amounts.in;
          assert.ok(asked);
          assert.equal(fills.reduce((sum, f) => sum + toUnits(f.size, asked.decimals), 0n), BigInt(asked.units), "the size asked, to the base unit");
          if (s.venue.capabilities().perps.status === "on") {
            const position = (await s.venue.positions(s.o.account)).find((p) => p.market === order.params.market);
            assert.ok(position, "a perps fill opens a position");
            assert.equal(Number(position.size) > 0, side === "buy", "long on a buy, short on a sell");
          }
        });
      }

      it("modify moves the order its target names, and only it, once, keeping the leg's client id", async () => {
        const s = await setup();
        if (!s) return;
        const keep = s.o.resting();
        const order = s.o.resting();
        const placed = await s.venue.place(order, s.signer);
        await s.venue.place(keep, s.signer);
        const before = s.h.control.effects();
        const move = s.o.modify(order, "91");
        const moved = await s.venue.modify(move, s.signer);
        assert.equal(moved.state, "resting");
        assert.equal(moved.legs[0]?.client_id, placed.legs[0]?.client_id, "the same leg (an order id may change on a cancel-and-replace venue)");
        assert.deepEqual(await s.venue.modify(move, s.signer), moved, "the same modify twice is one modify");
        assert.ok(s.h.control.effects() - before <= 1, "at most a replacement, never a second order");
        assert.equal((await openFor(s.venue, s.o.account, order)).length, 1, "still one open order for the intent");
        assert.ok(sameNumber((await openFor(s.venue, s.o.account, order))[0]?.price ?? "", "91"), "the target has the new price");
        assert.ok(sameNumber((await openFor(s.venue, s.o.account, keep))[0]?.price ?? "", String(keep.params.price)), "the other order did not move");
      });

      it("a partial fill is accounted now: the ack says partial, the fills add up to what the open order says is filled", async () => {
        const s = await setup();
        if (!s) return;
        const order = s.o.partial();
        const ack = await s.venue.place(order, s.signer);
        assert.equal(ack.state, "partial");
        assert.equal(ack.legs[0]?.state, "partial");
        const [open] = await openFor(s.venue, s.o.account, order);
        assert.ok(open, "the rest of the order is still open");
        assert.equal(open.state, "partial");
        const asked = order.amounts.in;
        assert.ok(asked);
        const filled = toUnits(open.filled, asked.decimals);
        assert.ok(filled > 0n && filled < BigInt(asked.units), "filled in part");
        assert.equal(toUnits(open.size, asked.decimals), BigInt(asked.units), "the order keeps the size asked");
        const fills = (await s.venue.fills(s.o.account, 0)).filter((f) => f.intent_id === order.intent_id);
        assert.equal(fills.reduce((sum, f) => sum + toUnits(f.size, asked.decimals), 0n), filled, "the fills add up to what is filled");
      });

      it("a trading key is authorized by the main wallet and expires; an expired one signs nothing", async () => {
        const s = await setup();
        if (!s) return;
        if (s.signer.kind === "wallet") return;
        const { signer: wallet } = await s.h.network.connect(s.h.walletId);
        assert.equal(s.signer.authorizedBy, wallet.id, "the main wallet authorized it");
        const grant: Intent = { ...s.o.resting(), action: "approve_agent", params: {}, amounts: {}, signer: "wallet" };
        assert.deepEqual(wallet.canSign({ ...grant, venue: s.o.venue }), { ok: true }, "granting and revoking a key is the main wallet's to sign");
        assert.equal(s.signer.canSign(grant).ok, false, "never the key's own");
        assert.ok(s.signer.expiresAt !== null && s.signer.expiresAt > Date.now(), "it has a term");
        assert.ok(s.o.expiredSigner, "a venue whose orders a trading key signs shows an expired key to the suite");
        const { signer: expired, count } = counting(await s.o.expiredSigner());
        const order = s.o.resting();
        const decision = expired.canSign(order);
        assert.equal(decision.ok, false, "an expired key refuses");
        if (!decision.ok) assert.ok(decision.reason.original.trim(), "with words for Review");
        const before = s.h.control.effects();
        await assert.rejects(s.venue.place(order, expired));
        assert.equal(count(), 0, "not signed");
        assert.equal(s.h.control.effects(), before, "not sent");
      });

      it("a venue refusal keeps the venue's words verbatim and makes no order", async () => {
        const s = await setup();
        if (!s) return;
        const words = "Order must have minimum value of $10.";
        const before = s.h.control.effects();
        s.h.control.refuse(words);
        const ack = await s.venue.place(s.o.resting(), s.signer);
        assert.equal(ack.state, "rejected");
        assert.equal(ack.reason?.original, words);
        assert.equal(s.h.control.effects(), before);
      });

      it("the caller's faults — a refused signer, a word outside PARAM_VALUES — sign nothing and send nothing", async () => {
        const s = await setup();
        if (!s) return;
        const { signer, count } = counting(s.signer);
        const order = s.o.resting();
        const before = s.h.control.effects();
        await assert.rejects(s.venue.place({ ...order, signer: signer.kind === "executor" ? "wallet" : "executor" }, signer), "a refused signer");
        await assert.rejects(s.venue.place({ ...s.o.resting(), params: { ...order.params, side: "short" } }, signer), "side: short");
        await assert.rejects(s.venue.place({ ...s.o.resting(), params: { ...order.params, type: "Limit" } }, signer), "type: Limit");
        assert.equal(count(), 0, "not signed");
        assert.equal(s.h.control.effects(), before, "not sent");
      });

      it("legs: one action, one signature, an id and the asked shape for each, one leg moved or cancelled alone — or refused whole", async () => {
        const s = await setup();
        if (!s) return;
        const { signer, count } = counting(s.signer);
        const order = s.o.bracket();
        const legs = order.legs ?? [];
        assert.ok(legs.length >= 2, "the bracket has a take profit and a stop loss");
        const before = s.h.control.effects();
        const ack: OrderAck = await s.venue.place(order, signer);
        if (s.venue.maxLegs < 1 + legs.length) {
          assert.equal(ack.state, "rejected", "a venue that cannot take the legs in one action refuses the intent");
          assert.ok(ack.reason?.original.trim(), "with words");
          assert.equal(count(), 0, "nothing signed");
          assert.equal(s.h.control.effects(), before, "nothing made");
          return;
        }
        assert.notEqual(ack.state, "rejected", ack.reason?.original);
        assert.equal(count(), 1, "one signature for the whole action");
        assert.deepEqual(ack.legs.map((l) => l.leg).sort((a, b) => a - b), [0, ...legs.map((l) => l.leg)], "an ack for every leg");
        assert.equal(new Set(ack.legs.map((l) => l.client_id)).size, ack.legs.length, "an id of its own for every leg");
        assert.equal(s.h.control.effects() - before, ack.legs.length, "every leg is an order");
        assert.deepEqual(await s.venue.place(order, signer), ack, "the same intent again is the same legs");
        assert.equal(count(), 1, "and no new signature");
        const open = await openFor(s.venue, s.o.account, order);
        assert.ok(sameNumber(open.find((x) => x.leg === 0)?.price ?? "", String(order.params.price)), "the entry rests at the price asked");
        for (const leg of legs) {
          const o = open.find((x) => x.leg === leg.leg);
          assert.ok(o, `leg ${leg.leg} is open`);
          assert.equal(o.role, leg.role, `leg ${leg.leg} is a ${leg.role}`);
          assert.equal(o.side, leg.params.side, `leg ${leg.leg}: the side asked`);
          assert.ok(sameNumber(o.trigger ?? "", String(leg.params.trigger)), `leg ${leg.leg}: the trigger asked`);
          assert.equal(o.reduce_only, leg.params.reduce_only, `leg ${leg.leg}: reduce-only as asked`);
        }
        const receipt: Pick<Receipt, "intent_id" | "legs"> = { intent_id: order.intent_id, legs: ack.legs.map(({ leg, client_id, order_id }) => ({ leg, client_id, order_id })) };
        for (const ref of receipt.legs ?? []) assert.equal(open.find((x) => x.leg === ref.leg)?.client_id, ref.client_id, `the receipt's id for leg ${ref.leg} is the venue's`);
        const [tp, sl] = legs;
        assert.ok(tp && sl);
        const moved = await s.venue.modify(s.o.modify(order, "86", sl.leg), signer);
        assert.deepEqual(moved.legs.map((l) => l.leg), [sl.leg], "only the stop loss moved");
        const afterMove = await openFor(s.venue, s.o.account, order);
        assert.ok(sameNumber(afterMove.find((x) => x.leg === sl.leg)?.trigger ?? "", "86"), "the stop loss has the new trigger");
        assert.ok(sameNumber(afterMove.find((x) => x.leg === tp.leg)?.trigger ?? "", String(tp.params.trigger)), "the take profit did not move");
        const removed = await s.venue.cancel(s.o.cancel(order, tp.leg), signer);
        assert.deepEqual(removed.legs.map((l) => l.leg), [tp.leg], "only the take profit was cancelled");
        assert.deepEqual((await openFor(s.venue, s.o.account, order)).map((x) => x.leg), [0, sl.leg], "the entry and the stop loss stay");
      });
    });
  });
}
