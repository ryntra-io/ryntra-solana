/**
 * What an adapter hands the contract suite. A real adapter builds its harness on recorded mainnet fixtures for CI
 * without a network; the stubs build it on memory.
 */
import type { Intent, VenueId } from "../contracts/intent.ts";
import type { NetworkAdapter } from "../contracts/network.ts";
import type { SignerAdapter } from "../contracts/signer.ts";

export interface HarnessControl {
  /** On: the network and its venues stop answering (a timeout). What was submitted still lands; off, it shows. */
  silence(on: boolean): void;
  /** Text: the next submissions are refused before they go out (a preflight), with exactly these words. */
  refuse(text: string | null): void;
  /** Text: the next transactions land and fail on chain with exactly these words. */
  failOnChain(text: string | null): void;
  /** On: a sign-and-send wallet stops answering — what it was given still goes out, the answer never comes. */
  silenceWallet(on: boolean): void;
  /** Text: the person says no in a sign-and-send wallet, with these words. */
  decline(text: string | null): void;
  /** The connection drops for a moment; the adapter reconnects by itself. */
  dropConnection(): void;
  /**
   * How many transactions and orders came into existence on the network and its venues — never counted down. A resend
   * the venue itself drops as a duplicate (by client order id) is not one: the suite counts what happened, not how
   * often the adapter asked.
   */
  effects(): number;
}

/** For the venue with `clob` or `perps` on, if the network has one. */
export interface OrderHarness {
  readonly venue: VenueId;
  /** The signer orders on this venue expect. */
  signer(): Promise<SignerAdapter>;
  /** The account the venue reports orders, fills and positions for. */
  readonly account: string;
  /** A fresh limit order that rests. */
  resting(): Intent;
  /** A fresh market order that fills, on `side` (buy by default). */
  market(side?: "buy" | "sell"): Intent;
  /** A fresh entry with a take profit and a stop loss as legs 1 and 2. */
  bracket(): Intent;
  /** A fresh limit order that crosses the book and fills only in part, the rest resting. */
  partial(): Intent;
  /** A trading key past its expiry, if this venue's orders are signed by one. */
  expiredSigner?(): Promise<SignerAdapter>;
  /** A fresh modify of `order` to `price` — or, when `leg` is a take profit or a stop loss, of that leg's `trigger`. */
  modify(order: Intent, price: string, leg?: number): Intent;
  /** A fresh cancel of `order`, or of its one `leg`. */
  cancel(order: Intent, leg?: number): Intent;
}

/**
 * The harness intents carry sums no clock or counter produces by chance (five or more significant digits): the suite
 * looks for them in the logs.
 */
export interface AdapterHarness {
  readonly network: NetworkAdapter;
  readonly walletId: string;
  /** A fresh on-chain intent (a new `intent_id` every call) the network carries end to end. */
  chainIntent(): Intent;
  /** A fresh intent the network carries in more than one transaction, if it has such (a withdrawal in two steps). */
  multiTxIntent?(): Intent;
  /** A fresh intent that expects a signer kind the wallet is not. */
  foreignSignerIntent(): Intent;
  /** A fresh swap intent, if a venue has `swap` on. */
  swapIntent?(): Intent;
  readonly orders?: OrderHarness;
  readonly control: HarnessControl;
  /** Every line the adapter logged. */
  readonly logs: readonly string[];
}

export type HarnessFactory = () => Promise<AdapterHarness>;
