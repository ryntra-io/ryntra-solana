/**
 * Ryntra tokens — the one authored source.
 *
 * Every colour below is the brand palette letter for letter, with two
 * additions made for legibility:
 *   - a separate shade for text: where a brand colour does not hold
 *     4.5:1 as small text, a `*-text` shade of the same hue carries the
 *     words; the brand colour stays for fills, borders, candles and icons;
 *   - light plus a 2 px outline: focus is the brand glow plus a solid 2 px
 *     brand outline, 2 px off the element.
 * The text on the orange button is dark, never white: white on this orange
 * does not hold 4.5:1.
 *
 * `npm run tokens` projects this file into tokens.json (for the phone and
 * anyone reading values), tokens.css, legacy.css and the tables in DESIGN.md;
 * `npm test` fails when any of them drifts from it. Edit here, nowhere else.
 */

export const THEMES = Object.freeze(["graphite", "porcelain"]);
export const DEFAULT_THEME = "graphite";

/** The brand colours, per theme. Keys are the token names: CSS `--ryntra-<key>`. */
export const color = {
  graphite: {
    bg: "#080D13",
    surface: "#0E1620",
    elevated: "#142030",
    border: "#1C2A3A",
    text: "#F5F7FA",
    muted: "#8A97A8",
    brand: "#FF681C",
    "on-brand": "#080D13", // dark text on orange: 6.7:1
    up: "#22C55E",
    down: "#EF4444",
    warn: "#F5B544",
    info: "#4FB8FF",
  },
  porcelain: {
    bg: "#F5F7FA",
    surface: "#FFFFFF",
    elevated: "#FFFFFF",
    border: "#E3E7ED",
    text: "#0B1118",
    muted: "#5B6676",
    brand: "#E85A12",
    "on-brand": "#0B1118", // dark text on orange: 5.3:1
    up: "#16A34A",
    down: "#DC2626",
    warn: "#C98A12",
    info: "#0A7FCF",
  },
};

/**
 * The reading shade for small text. Where the
 * brand colour already holds 4.5:1 on bg, surface and elevated, the text shade
 * is the brand colour itself; otherwise the nearest shade of the same hue
 * (HSL lightness only) that holds 4.6:1 on all three.
 */
export const textShade = {
  graphite: {
    "brand-text": "#FF681C",
    "up-text": "#22C55E",
    "down-text": "#F04E4E", // #EF4444 is 4.36:1 on elevated
    "warn-text": "#F5B544",
    "info-text": "#4FB8FF",
  },
  porcelain: {
    "brand-text": "#C04A0F", // #E85A12 is 3.55:1 on white
    "up-text": "#11813B", // #16A34A — 3.29:1
    "down-text": "#DA2323", // #DC2626 — 4.4999:1 on bg
    "warn-text": "#96670D", // #C98A12 — 2.94:1
    "info-text": "#0974BD", // #0A7FCF — 4.24:1
  },
};

/** Light and depth, per theme. */
export const effect = {
  graphite: {
    "brand-glow": "0 0 0 1px #FF681C40, 0 0 24px #FF681C33",
    "shadow-elevated": "none",
  },
  porcelain: {
    "brand-glow": "0 0 0 1px #E85A1233, 0 0 16px #E85A1226",
    "shadow-elevated": "0 8px 24px rgba(8, 13, 19, 0.08)",
  },
};

/**
 * The states the palette names but does not give a value for, derived from
 * its colours by one formula for both themes (our reading; the build resolves
 * each to a literal so the phone gets plain values).
 */
export const derived = {
  // Pressed: the brand darkened by 8 %.
  "brand-pressed": { mix: ["brand", "#000000", 0.92] },
  // A block's border lightens under the pointer — and darkens on Porcelain.
  "border-hover": { mix: ["border", "muted", 0.6] },
  // Under the pointer: the neighbouring ground on which every text shade already holds 4.5:1 —
  // no new colour, so nothing written on it can fall below the contract. The text shades have
  // almost no headroom (down-text is 4.61:1 on Graphite elevated), so a hover beyond these
  // grounds would break them. A row on surface takes the next ground up in Graphite, the page in
  // Porcelain; an item of a menu or sheet on elevated takes surface in Graphite, the page in Porcelain.
  "surface-hover": { ground: { graphite: "elevated", porcelain: "bg" } },
  "elevated-hover": { ground: { graphite: "surface", porcelain: "bg" } },
};

/** What each colour is for, shown in DESIGN.md and on the Storybook page. */
export const colorUse = {
  bg: "Фон сторінки",
  surface: "Блоки, панелі",
  elevated: "Модалки, нижні листи, меню",
  border: "Рамки блоків, лінії таблиць",
  text: "Основний текст і числа",
  muted: "Підписи, дрібний рядок",
  brand: "Одна головна кнопка на екран, активний пункт, фокус",
  "on-brand": "Текст на помаранчевому — темний",
  up: "Зростання: свічки, рамки, значки",
  down: "Падіння: свічки, рамки, значки",
  warn: "Pending, Overnight: значки, рамки",
  info: "Підказки: значки, рамки",
  "brand-text": "Помаранчеве слово дрібним текстом",
  "up-text": "Число зростання дрібним текстом",
  "down-text": "Число падіння, помилка дрібним текстом",
  "warn-text": "Слово «Pending», «Overnight»",
  "info-text": "Текст підказки",
  "brand-pressed": "Натиснута головна кнопка (−8 %)",
  "border-hover": "Рамка блока під курсором",
  "surface-hover": "Рядок на surface під курсором",
  "elevated-hover": "Пункт меню чи листа під курсором",
};

/** The dimming under a bottom sheet or a modal (our reading; the palette gives none). */
export const scrim = {
  graphite: "rgba(8, 13, 19, 0.64)",
  porcelain: "rgba(8, 13, 19, 0.32)",
};

/** Focus: glow + a solid 2 px brand outline, 2 px off, so it reads on any ground. */
export const focus = { width: 2, offset: 2 };

/** Type: Geist with tabular figures; Geist Mono for addresses and hashes. */
export const font = {
  sans: { family: "Geist", stack: 'var(--font-geist, "Geist"), system-ui, -apple-system, "Segoe UI", Roboto, sans-serif' },
  mono: { family: "Geist Mono", stack: 'var(--font-geist-mono, "Geist Mono"), ui-monospace, "SFMono-Regular", Menlo, monospace' },
};
export const numeric = "tabular-nums";

/** Sizes, px: size/line; the number in a block is 28/32 at 600. */
export const type = {
  h1: { size: 32, line: 38 },
  h2: { size: 22, line: 28 },
  body: { size: 16, line: 24 },
  ui: { size: 14, line: 20 },
  caption: { size: 12, line: 16 },
  number: { size: 28, line: 32, weight: 600 },
};

/** Weights: 500 for a block's title, 600 for the hero number, 400 for the running text. */
export const weight = { regular: 400, medium: 500, semibold: 600 };

/** Radii, px. */
export const radius = { field: 8, button: 10, block: 12, card: 16, pill: 999 };

/** Spacing: step 4, rhythm 8, paddings 8/12/16/24/32. Key × 4 = px. */
export const space = { 1: 4, 2: 8, 3: 12, 4: 16, 6: 24, 8: 32 };

/** Fixed sizes, px (the icon stroke is unitless). */
export const size = {
  header: 56,
  button: 40,
  "button-touch": 48,
  row: 40,
  chip: 24,
  icon: 20,
  rail: 240,
  "rail-collapsed": 64,
};
export const iconStroke = 1.5;

/** Motion: 150–220 ms; prefers-reduced-motion turns all of it off. The curve is our reading. */
export const motion = { fast: 150, base: 220, ease: "cubic-bezier(0.2, 0, 0, 1)" };

/** The workspace: twelve columns 16 apart; a block takes 3, 4, 6, 8 or 12 of them. */
export const grid = { columns: 12, gap: 16, spans: [3, 4, 6, 8, 12] };

/**
 * The three kinds of page, and nothing between them. An overview (Home, Portfolio, lists) has a main column and,
 * from `wide` px, a side column beside it; a terminal takes the whole width; an action (a form, settings, a review
 * out of a sheet) is one column. The page's own margin grows with the window. Px; a share is of the window's width.
 */
export const page = {
  max: 1760,
  wide: 1280,
  gap: 32,
  aside: { min: 340, share: 26, max: 420 },
  pad: { min: 16, share: 1.6, max: 28 },
  action: 640,
};

/** Layers (our reading; the palette gives none). */
export const z = { base: 0, sticky: 10, menu: 100, sheet: 200, modal: 300, toast: 400, tooltip: 500 };

/**
 * The contrast contract, checked in both themes by `npm test` and drawn on the
 * Storybook page «Tokens». Text: 4.5:1 (WCAG 2.x, 1.4.3) on every
 * ground text stands on, the row under the pointer included. The focus outline
 * is not text: 3:1 (WCAG 2.x, 1.4.11).
 */
const GROUNDS = ["bg", "surface", "elevated", "surface-hover", "elevated-hover"];
export const contrast = [
  { fg: "text", on: GROUNDS, min: 4.5, use: "Текст і числа" },
  { fg: "muted", on: GROUNDS, min: 4.5, use: "Підписи; текст вимкненої кнопки" },
  { fg: "brand-text", on: GROUNDS, min: 4.5, use: "Помаранчеве слово: активний пункт, посилання" },
  { fg: "up-text", on: GROUNDS, min: 4.5, use: "Зростання, прибуток" },
  { fg: "down-text", on: GROUNDS, min: 4.5, use: "Падіння, збиток, помилка" },
  { fg: "warn-text", on: GROUNDS, min: 4.5, use: "Pending, Overnight" },
  { fg: "info-text", on: GROUNDS, min: 4.5, use: "Підказки" },
  { fg: "on-brand", on: ["brand", "brand-pressed"], min: 4.5, use: "Текст на помаранчевій кнопці" },
  { fg: "brand", on: ["bg", "surface", "elevated"], min: 3, use: "Контур фокусу" },
];

/**
 * The old names the product repositories still read (app/design/tokens.css,
 * DESIGN.md there). They become aliases of the new tokens and are not
 * deleted, so nothing in the product breaks. A name whose role has no token
 * is not listed here and keeps its old value until the product screens move
 * to the new names; DESIGN.md names them.
 * A target is a token name, `<theme>:<token>` for a name the product pins to
 * one theme (its value is that theme's literal), or a CSS expression over tokens.
 * The names the product writes as text (`color:`) lead to the `*-text` shades. The tinted grounds
 * (`*-soft`) go transparent: the palette has no coloured ground under up/down and puts colour
 * on the border and the text; in Porcelain any tint above 2 % takes the text below 4.5:1.
 */
export const legacy = {
  // surfaces
  "--ry-bg": "bg",
  "--ry-card": "surface",
  "--ry-elevated": "elevated",
  "--ry-hover": "surface-hover",
  "--ry-border": "border",
  "--ry-text": "text",
  "--ry-muted": "muted",
  "--ry-text-muted": "muted",
  // brand: one fill, no gradient, hover adds light only
  "--ry-iris": "brand",
  "--ry-accent": "brand",
  "--ry-iris-hover": "brand",
  "--ry-iris-deep": "brand-pressed",
  "--ry-iris-pressed": "brand-pressed",
  "--ry-on-iris": "on-brand",
  "--ry-iris-lift": "graphite:brand-text",
  "--ry-iris-sink": "porcelain:brand-text",
  "--ry-accent-fg": "brand-text",
  "--ry-gradient": "linear-gradient(var(--ryntra-brand), var(--ryntra-brand))",
  "--ry-gradient-hover": "linear-gradient(var(--ryntra-brand), var(--ryntra-brand))",
  "--ry-brand-soft": "transparent",
  "--ry-brand-line": "color-mix(in srgb, var(--ryntra-brand) 32%, transparent)",
  "--ry-brand-glow": "brand-glow",
  "--ry-brand-glow-strong": "brand-glow",
  "--ry-glow-cta": "brand-glow",
  "--ry-focus": "focus-shadow",
  // market and status
  "--ry-verified": "up-text",
  "--ry-pnl-pos": "up-text",
  "--ry-pnl-pos-dark": "graphite:up-text",
  "--ry-pnl-pos-light": "porcelain:up-text",
  "--ry-verified-soft": "transparent",
  "--ry-risk": "down-text",
  "--ry-high-risk": "down-text",
  "--ry-pnl-neg": "down-text",
  "--ry-pnl-neg-light": "porcelain:down-text",
  "--ry-risk-soft": "transparent",
  "--ry-caution": "warn-text",
  "--ry-caution-soft": "transparent",
  "--ry-info": "info-text",
  "--ry-unknown": "muted",
  // shadows
  "--ry-shadow-elevated": "shadow-elevated",
  // type
  "--ry-font-sans": "font-sans",
  "--ry-font-mono": "font-mono",
  // radii
  "--ry-r-card": "radius-block",
  "--ry-r-btn": "radius-button",
  "--ry-r-btn-sm": "radius-field",
  "--ry-r-chip": "radius-field",
  "--ry-r-pill": "radius-pill",
  // spacing
  "--ry-s1": "space-1",
  "--ry-s2": "space-2",
  "--ry-s3": "space-3",
  "--ry-s4": "space-4",
  "--ry-s5": "space-6",
  "--ry-s6": "space-8",
  // the compatibility names that hold literals or theme overrides of their own
  "--rt-action-blue-fg": "brand-text",
  "--rt-authorization-violet-fg": "brand-text",
  "--rt-reconciled-green-fg": "up-text",
  "--rt-blocked-red-fg": "down-text",
  "--rt-review-amber-fg": "warn-text",
  "--rt-chart-up": "up",
  "--rt-chart-down": "down",
  "--rt-radius-xs": "radius-field",
  "--rt-radius-sm": "radius-block",
  "--rt-radius-md": "radius-card",
  "--rt-radius-pill": "radius-pill",
  "--rt-space-2xs": "space-1",
  "--rt-space-xs": "space-2",
  "--rt-space-sm": "space-3",
  "--rt-space-md": "space-4",
  "--rt-space-lg": "space-6",
  "--rt-space-xl": "space-8",
  "--rt-duration-fast": "motion-fast",
  "--rt-duration-base": "motion-base",
  "--rt-duration-slow": "motion-base",
  "--rt-ease": "motion-ease",
};

/**
 * The theme selectors the product uses today (app/design/tokens.css), its light
 * «paper» bands included, written exactly as there so they weigh the same and
 * legacy.css, loaded later, wins; legacy.css teaches them the new values.
 */
export const legacyThemeSelectors = {
  graphite: ['[data-ry-theme="dark"]', '[data-theme="dark"]'],
  porcelain: ['[data-ry-theme="light"]', '[data-theme="light"]', ".rt-light", ".rx-paper", '.rx [class*="boundaries"]'],
};
