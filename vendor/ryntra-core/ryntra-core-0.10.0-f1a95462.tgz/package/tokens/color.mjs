/**
 * Colour arithmetic for the tokens: hex parsing, sRGB mixing and the WCAG 2.x
 * contrast ratio. Shared by the build, the tests and the Storybook page, so the
 * number a reader sees on the page is the number the test checked.
 */

const HEX = /^#([0-9a-f]{6})([0-9a-f]{2})?$/i;

/** `#RRGGBB` or `#RRGGBBAA` → [r, g, b] in 0–1 (alpha ignored). */
export function rgb(hex) {
  const match = HEX.exec(hex);
  if (!match) throw new Error(`not a #RRGGBB colour: ${hex}`);
  const value = match[1];
  return [0, 2, 4].map((i) => parseInt(value.slice(i, i + 2), 16) / 255);
}

export function isHex(value) {
  return typeof value === "string" && HEX.test(value);
}

function toHex(channels) {
  return `#${channels
    .map((c) => Math.round(Math.min(1, Math.max(0, c)) * 255).toString(16).padStart(2, "0"))
    .join("")
    .toUpperCase()}`;
}

/** `color-mix(in srgb, a <share>, b)`: share of `a`, the rest of `b`. */
export function mix(a, b, share) {
  const x = rgb(a);
  const y = rgb(b);
  return toHex(x.map((c, i) => c * share + y[i] * (1 - share)));
}

function luminance(hex) {
  const [r, g, b] = rgb(hex).map((c) => (c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4));
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/** WCAG 2.x contrast ratio, 1–21. */
export function contrast(a, b) {
  const x = luminance(a);
  const y = luminance(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
}

/** Rounded down to two places, so a ratio is never shown passing when it does not. */
export function ratio(value) {
  return Math.floor(value * 100) / 100;
}
