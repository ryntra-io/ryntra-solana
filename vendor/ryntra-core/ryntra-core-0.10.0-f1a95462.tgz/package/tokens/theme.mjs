/**
 * The theme switch: Graphite by default, Porcelain on choice, «як у системі»
 * follows `prefers-color-scheme`. The attribute lives on <html>; without it
 * the page is Graphite (tokens.css puts Graphite on :root).
 */

import { DEFAULT_THEME } from "./source.mjs";

export { DEFAULT_THEME, THEMES } from "./source.mjs";
export const PREFERENCES = Object.freeze(["graphite", "porcelain", "system"]);

const LIGHT_QUERY = "(prefers-color-scheme: light)";

/** The values the product stores today («dark», «light») mean the same two themes. */
const SYNONYMS = { graphite: "graphite", dark: "graphite", porcelain: "porcelain", light: "porcelain" };
/** The product's old attribute, kept in step while its shell still reads it. */
const LEGACY_ATTRIBUTE = { graphite: "dark", porcelain: "light" };

/** A stored or chosen preference → the theme to draw. Anything unknown is Graphite. */
export function resolveTheme(preference, prefersLight = false) {
  if (preference === "system") return prefersLight ? "porcelain" : "graphite";
  return SYNONYMS[preference] ?? DEFAULT_THEME;
}

/**
 * Sets `data-theme` on the root (and `data-ry-theme`, where the product's shell
 * still set it) and, for «system», follows the OS while the preference holds.
 * Returns a function that stops following.
 */
export function applyTheme(preference, root = globalThis.document?.documentElement, media = globalThis.matchMedia?.(LIGHT_QUERY)) {
  if (!root) return () => {};
  const draw = () => {
    const theme = resolveTheme(preference, Boolean(media?.matches));
    root.setAttribute("data-theme", theme);
    if (root.hasAttribute?.("data-ry-theme")) root.setAttribute("data-ry-theme", LEGACY_ATTRIBUTE[theme]);
  };
  draw();
  if (preference !== "system" || !media?.addEventListener) return () => {};
  media.addEventListener("change", draw);
  return () => media.removeEventListener("change", draw);
}
