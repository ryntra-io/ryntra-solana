/**
 * The chart contract, version 2. Types only: no engine and no network code lives here. The same contract carries a
 * perpetual, a pool, a spot pair, a tokenized stock, a prediction market and an index; bars come from the data
 * channel, never straight from an exchange; the chart draws, and the only thing it gives back is a person's intent —
 * the product checks it, shows Review, and the person signs.
 *
 * Prices and sizes are decimal strings everywhere (a memecoin trades at 0.0000000123); numbers appear only at the
 * engine's edge (`EngineBar`). Times are ms, UTC.
 */
import type { BookLevel, Candle } from "./venue.ts";
import type { Amount, AssetId, IntentAction, IntentLeg, IntentParams, IntentSource, NetworkId, Refusal, VenueId } from "./intent.ts";
import type { BarCorrection, DataGap, DataStatus, MarketTrade } from "./data.ts";

// ── Version ───────────────────────────────────────────────────────────────────────────────────────────────────────

/**
 * `ryntra.chart/<major>.<minor>`. A reader accepts a writer with the same major. Within a major a minor only adds:
 * optional fields, optional methods, and new words in the lists of this contract. Removing or changing anything is a
 * new major.
 *
 * A reader that meets a word it does not know takes the safe reading, never a guess:
 * - a data state → `stale`; a market state → `closed`; a display right → `internal_only`;
 * - an order line state → `unknown` (not draggable, no retry); an order line role → a plain line that cannot be
 *   dragged; a time in force or a P/L base → shown as unknown; a ghost reason → the ghost is invalid; a new order
 *   kind → not offered; a draft's purpose or kind → the draft is refused;
 * - a capability, a resolution kind or span, a price kind, a measure, an adjustment, an instrument kind, an outcome,
 *   a series unit → not offered; a mark or level kind → hidden;
 * - a gap reason → a gap with no reason named; a correction reason → a correction all the same;
 * - a live event type → ignored, and the screen reloads its page;
 * - a perpetual's reference source → `book` (the price is not an outside one); a position's liquidation price kind →
 *   the line names no price, and its distance is counted from the price now;
 * - a paper margin mode or limit fill → the rules are not taken; a paper trade cause → a trade with no cause named; a
 *   paper refusal → a refusal all the same;
 * - a book step the reader cannot read → not offered; a cut of levels that is not a whole positive number → no cut named;
 *   a trade's side that is neither buy nor sell → a trade with no side, counted on neither side; a trade's
 *   confirmation → `pending`; a trade's flag → kept as a flag not known.
 * In TypeScript the lists are closed unions, so a new word shows up as a compile error in an exhaustive `switch`:
 * that is the place to add its safe reading.
 */
export const CHART_CONTRACT = "ryntra.chart/2.6";

// ── Instrument ────────────────────────────────────────────────────────────────────────────────────────────────────

/** What is traded: a pair on a book, a pool, a perpetual, a tokenized stock, an outcome of a prediction, an index. */
export const INSTRUMENT_KINDS = ["spot", "pool", "perp", "stock", "prediction", "index"] as const;

export type InstrumentKind = (typeof INSTRUMENT_KINDS)[number];

/** A price axis, or a probability axis from 0 to 100 %. */
export const SCALES = ["price", "probability"] as const;

export type Scale = (typeof SCALES)[number];

export const WEEKDAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"] as const;

export type Weekday = (typeof WEEKDAYS)[number];

/** One stretch of trading on the given days, in the session's time zone; `close` before `open` runs past midnight. */
export interface SessionWindow {
  readonly days: readonly Weekday[];
  /** "HH:MM" */
  readonly open: string;
  /** "HH:MM" */
  readonly close: string;
}

export interface TradingSession {
  /** An IANA zone ("UTC", "America/New_York"). Day, week and month bars open at midnight in it. */
  readonly timezone: string;
  /** Empty: always open. */
  readonly windows: readonly SessionWindow[];
  /** Days with no trading, "YYYY-MM-DD" in the session's zone. */
  readonly holidays: readonly string[];
}

/** Which price a bar is made of. `external` is a price from outside the venue (another exchange, a reference feed). */
export const PRICE_KINDS = ["last", "mid", "mark", "oracle", "index", "external"] as const;

export type PriceKind = (typeof PRICE_KINDS)[number];

/** A price, or the price times the supply. */
export const MEASURES = ["price", "market_cap"] as const;

export type Measure = (typeof MEASURES)[number];

/** A stock's history as it traded (`raw`) or with splits and dividends taken back (`adjusted`); everything else is `raw`. */
export const ADJUSTMENTS = ["raw", "adjusted"] as const;

export type Adjustment = (typeof ADJUSTMENTS)[number];

export const OUTCOMES = ["yes", "no"] as const;

export type Outcome = (typeof OUTCOMES)[number];

/**
 * What the numbers of a bar are: which price, price or market cap, in which unit (USD, a chain's coin, the quote
 * asset), raw or adjusted, and for a prediction which outcome. On a probability scale the numbers are the outcome's
 * price as a percent of its payout, 0–100, and `in` names the payout asset; the `no` outcome is derived from `yes`
 * (100 − yes), so the two always add up to 100.
 */
export interface PriceBasis {
  readonly kind: PriceKind;
  readonly measure: Measure;
  readonly in: AssetId;
  readonly adjustment: Adjustment;
  readonly outcome: Outcome | null;
}

/**
 * A venue whose price step follows the price: at most `significant` significant figures and at most `max_decimals`
 * decimals; where `integers_always`, a whole price is valid whatever its figures. The trading layer snaps by this
 * rule, and a pip is the step at the entry price.
 */
export interface PriceRule {
  readonly significant: number;
  readonly max_decimals: number;
  readonly integers_always: boolean;
}

/** How far from a reference price a venue takes an order. */
export interface PriceBand {
  readonly from: PriceKind;
  readonly max_deviation_bps: number;
}

/**
 * One name for whatever is charted: a ticker, a mint, a pool address, a market on a venue, an outcome of a
 * prediction. Steps, multiplier and session come from the instrument registry, never from a literal on a screen.
 */
export interface Instrument {
  readonly id: string;
  /** As the person reads it: "ETH-PERP", "STREAM/SOL", "TSLAx", "Team A wins". */
  readonly symbol: string;
  readonly network: NetworkId;
  readonly venue: VenueId;
  readonly kind: InstrumentKind;
  readonly base: AssetId;
  /** The quote currency. */
  readonly quote: AssetId;
  /**
   * The price step in the trading basis, a decimal string (percent on a probability scale). Where `price_rule` is
   * set, the step at the current price. A pool has no step: there it is the step its price is shown to.
   */
  readonly tick: string;
  /** Null where the step is fixed. */
  readonly price_rule: PriceRule | null;
  /** The size step in the base asset. */
  readonly lot: string;
  /** The smallest order in the quote currency; null where the venue has none. */
  readonly min_notional: string | null;
  readonly price_band: PriceBand | null;
  /** Units of the underlying per unit of the instrument (a contract size, shares per token); "1" when there is none. */
  readonly multiplier: string;
  /** The multiplier's current version; it changes on a split or a dividend. Null when it never changes. */
  readonly multiplier_version: string | null;
  readonly session: TradingSession;
  /** The hours of the underlying market where it differs from the instrument's own (a stock token trading round the clock); null otherwise. */
  readonly reference_session: TradingSession | null;
  readonly scale: Scale;
  /** The outcomes a prediction offers; empty for everything else. */
  readonly outcomes: readonly Outcome[];
  /** The smallest bar this instrument has honestly: a chain whose blocks share one time per several seconds has no one-second bar. */
  readonly min_resolution: TimeResolution;
  /** Every resolution the source serves; time resolutions from the smallest up. */
  readonly resolutions: readonly Resolution[];
  /** Every basis the source serves; the first is the default. */
  readonly bases: readonly PriceBasis[];
  /**
   * The basis orders are placed in: the last price in the quote currency, raw, and for a prediction the outcome
   * traded. Order lines, the ghost, levels, marks with a price and the book are all in it. The trading layer drafts on
   * a view in the same unit — the same measure, unit, adjustment and outcome, whatever the price kind (a mark or an
   * index chart of a perpetual) — and on no other.
   *
   * On a view in another unit (USD for a pool in a coin, market cap, the other outcome) a priced layer is never drawn
   * at its trading-basis number: the other outcome is mapped exactly (100 − price, so a "yes" order at 30 sits at 70 on
   * the "no" chart, labelled with its own outcome and side, so it never reads as an order on "no"); anything else is
   * hidden, with a note that the lines are on the trading chart.
   */
  readonly trading_basis: PriceBasis;
}

// ── Resolutions ───────────────────────────────────────────────────────────────────────────────────────────────────

/** The engine's own period words. */
export const TIME_UNITS = ["second", "minute", "hour", "day", "week", "month"] as const;

export type TimeUnit = (typeof TIME_UNITS)[number];

/**
 * The spans each unit takes, as text. Each divides the next unit whole (60 s, 60 min, 24 h), so every bar starts on a
 * boundary and is an exact roll-up of one-second bars: open of the first, close of the last, the highest high, the
 * lowest low, the sums.
 */
export const TIME_SPANS = {
  second: ["1", "5", "10", "15", "30"],
  minute: ["1", "3", "5", "15", "30"],
  hour: ["1", "2", "4", "6", "8", "12"],
  day: ["1"],
  week: ["1"],
  month: ["1"],
} as const;

/** Bars by time, by a count of trades, by volume, by price range. Bars that are not by time are built from the same trades. */
export const BAR_KINDS = ["time", "tick", "volume", "range"] as const;

export type BarKind = (typeof BAR_KINDS)[number];

/**
 * Seconds, minutes and hours open on their boundary from the Unix epoch; days at midnight in the session's zone;
 * weeks on Monday; months on the 1st. Where the zone is not a whole number of hours from UTC, or moves for summer,
 * hour bars do not nest in day bars — both are still exact roll-ups of one-second bars.
 */
export interface TimeResolution {
  readonly kind: "time";
  readonly unit: TimeUnit;
  readonly span: number;
}

export interface TickResolution {
  readonly kind: "tick";
  /** Trades per bar. */
  readonly trades: number;
}

export interface VolumeResolution {
  readonly kind: "volume";
  /** Base asset per bar, decimal. */
  readonly size: string;
}

export interface RangeResolution {
  readonly kind: "range";
  /** The bar closes once its high and low are this far apart, in the trading basis: a price, not a count of steps. */
  readonly range: string;
}

export type Resolution = TimeResolution | TickResolution | VolumeResolution | RangeResolution;

// ── Bars, history pages and the live bar ──────────────────────────────────────────────────────────────────────────

/** A bar in the units of its basis. Prices are unsigned: a spread or a basis that can go negative is a series. */
export interface Bar {
  /**
   * ms, the bar's open; strictly increasing along a page. A bar not by time opens at its first trade's ms, or at the
   * next free ms when the bar before it took that one — so pages by timestamp and the engine's "same timestamp
   * replaces" hold for every kind of bar. Such bars depend on where they start, so the gateway builds them once, from
   * the start of each UTC day — the last bar of a day closes at 00:00 UTC, short if need be — and history and the live
   * bar read that one series.
   */
  readonly t: number;
  readonly o: string;
  readonly h: string;
  readonly l: string;
  readonly c: string;
  /** In the base asset; null where the source gives no size (a price feed) — not zero. */
  readonly v: string | null;
  /** In the basis' unit; null where unknown. */
  readonly turnover: string | null;
  /** Trades in the bar; null where the source does not count them. */
  readonly trades: number | null;
}

/**
 * The engine's own words for a page: `init` replaces what is shown, `forward` brings older bars (before `timestamp`,
 * the open of the oldest bar on screen), `backward` brings newer ones (after `timestamp`, the newest).
 */
export const HISTORY_LOADS = ["init", "forward", "backward"] as const;

export type HistoryLoad = (typeof HISTORY_LOADS)[number];

export interface HistoryRequest {
  readonly instrument: string;
  readonly resolution: Resolution;
  readonly basis: PriceBasis;
  readonly load: HistoryLoad;
  /** ms; null for `init`. */
  readonly timestamp: number | null;
  /** Bars at most; a page of 1500 one-second bars is 25 minutes. */
  readonly limit: number;
}

export interface HistoryPage {
  /** Oldest first. */
  readonly bars: readonly Bar[];
  /** Whether older (`forward`) and newer (`backward`) pages exist — the engine's own `more`. An empty page never says there is more in its direction. */
  readonly more: { readonly forward: boolean; readonly backward: boolean };
  /** Gaps inside the page's span: drawn hatched with their reason, and no bar lies inside one. */
  readonly gaps: readonly DataGap[];
  /**
   * The step this basis is shown to; the engine's price precision is its number of decimals, never a guess from the
   * size of the price. When it changes from one page to the next, the engine adapter sets the symbol again.
   */
  readonly display_step: string;
  /**
   * The multiplier version the bars are in: for `adjusted`, the one every bar is adjusted to; for `raw`, the newest
   * bar's, with an `event` mark at each change inside the page. Null where the instrument has none.
   */
  readonly multiplier_version: string | null;
  readonly status: DataStatus;
}

export interface LiveRequest {
  readonly instrument: string;
  readonly resolution: Resolution;
  readonly basis: PriceBasis;
}

/**
 * What a subscription brings. `bar` — the bar being built, at most once a second for one open; the same `t` replaces
 * the bar on screen, a later `t` opens a new one, an earlier `t` never comes this way. The last state of a bar is
 * always sent, right before the next bar opens: that closing update is the one exempt from the once-a-second limit.
 * The gateway's clock in the statuses never runs back. `corrected` — older bars changed: the screen reloads them (the engine has no
 * reload of a range: it resets and loads `init` again, which jumps to the newest bar — the screen brings the person
 * back to where they were). `gap` and `status` — the
 * stream's state changed.
 */
export type LiveEvent =
  | { readonly type: "bar"; readonly bar: Bar; readonly status: DataStatus }
  | { readonly type: "corrected"; readonly correction: BarCorrection }
  | { readonly type: "gap"; readonly gap: DataGap; readonly status: DataStatus }
  | { readonly type: "status"; readonly status: DataStatus };

export interface ChartRequestOptions {
  readonly signal?: AbortSignal;
}

// ── Series: funding, open interest, depth, basis — anything over time with a unit ─────────────────────────────────

/** Well-known kinds; any other word is allowed and shown by its label. */
export const SERIES_KINDS = ["funding", "open_interest", "depth", "basis", "price"] as const;

export const SERIES_UNITS = ["percent", "fraction", "bps", "asset", "count"] as const;

export type SeriesUnitKind = (typeof SERIES_UNITS)[number];

export interface SeriesUnit {
  readonly kind: SeriesUnitKind;
  /** For `asset`: which one. */
  readonly asset: AssetId | null;
  /** A rate per this many ms (funding per hour is a fraction per 3 600 000); null for a level. */
  readonly per_ms: number | null;
}

/**
 * A series over time. Since 2.4 two well-known kinds have a meaning a reader may count on (a source that names an
 * older contract may use them otherwise, and a reader does not read its series this way): a point of `funding` is one
 * payment — its time is the payment's, its value the rate paid, signed (positive: longs paid shorts), in the series'
 * unit (`fraction`, `percent` or `bps`) per `unit.per_ms`, whatever period that payment was for (a venue that moves
 * from eight-hour to four-hour payments writes each as its rate per the series' span); `open_interest` is the size of one side of every open
 * position at the point's time, in the instrument's base asset (`unit.asset` is `Instrument.base`), as many base units
 * as the venue counts — not times `Instrument.multiplier`.
 */
export interface SeriesSpec {
  readonly id: string;
  readonly instrument: string;
  readonly kind: string;
  readonly label: string;
  readonly unit: SeriesUnit;
  /** ms between points (funding every 8 h is 28 800 000); null where points come on events. */
  readonly step_ms: number | null;
}

export interface SeriesPoint {
  /** ms */
  readonly t: number;
  /** Decimal, signed. */
  readonly v: string;
}

export interface SeriesRequest {
  readonly series: string;
  readonly load: HistoryLoad;
  readonly timestamp: number | null;
  readonly limit: number;
}

export interface SeriesPage {
  readonly spec: SeriesSpec;
  readonly points: readonly SeriesPoint[];
  readonly more: { readonly forward: boolean; readonly backward: boolean };
  readonly gaps: readonly DataGap[];
  readonly status: DataStatus;
}

// ── A perpetual now: the venue's prices, its funding, its open interest ───────────────────────────────────────────

/**
 * Where a perpetual's reference price — the oracle or the index the venue counts funding from, which the mark leans
 * on — comes from now: `external`, prices read outside the venue (spot exchanges, the underlying's own market); `book`,
 * the venue moves it from its own order book instead — a stock's perpetual while the stock's exchange is closed (the
 * perpetual goes on trading round the clock, so its own `DataStatus.market` stays `open`), or a market with no outside
 * price at all. The gateway says which, from the venue's word or from the underlying's hours
 * (`Instrument.reference_session`). Since 2.4.
 */
export const REFERENCE_SOURCES = ["external", "book"] as const;

export type ReferenceSource = (typeof REFERENCE_SOURCES)[number];

/** The funding as the venue counts it now. Since 2.4. */
export interface FundingNow {
  /**
   * The rate of the next payment as the venue counts it now — until it is paid, an estimate that moves: a decimal
   * fraction of the position's value as the venue values it for funding, per `per_ms`, signed; positive, longs pay
   * shorts. Always a fraction here, whatever unit the funding series uses.
   */
  readonly rate: string;
  /** The rate is per this many ms (per hour: 3 600 000). */
  readonly per_ms: number;
  /**
   * ms between payments now: an hour on some venues, eight hours on many. Null where funding accrues continuously
   * and has no payments, or the venue does not say. A venue that changes its period changes this; the series keeps
   * the payments as they happened.
   */
  readonly interval_ms: number | null;
  /**
   * ms, the first payment after the context's time (`status.at`): as the venue states it, or as the venue's published
   * rule of payments gives it (every hour on the hour) — then the context's `status.derived` is true. A time already
   * past is never sent: a venue that still names the payment just made gives null until it names the next. Null where
   * neither says, or the venue pays none.
   */
  readonly next_at: number | null;
}

/**
 * A perpetual as the venue states it now: the prices it reads, where its reference comes from, its funding and its
 * open interest. The chart shows it; it never drafts from it. Each context is whole: a field the source reads less
 * often than another (open interest polled beside a streamed mark) keeps its latest value, never null for «not in this
 * update»; `status` is of the newest field. Since 2.4.
 */
export interface PerpContext {
  readonly instrument: string;
  /**
   * The venue's prices now, in the trading basis — the mark, the oracle, the middle of the book, the last trade, an
   * index: those the source gives, decimal strings.
   */
  readonly prices: Readonly<Partial<Record<PriceKind, string>>>;
  /** Null where the source cannot say. */
  readonly reference: ReferenceSource | null;
  /** Null where the venue charges none or the source does not give it: the chart then says nothing of funding. */
  readonly funding: FundingNow | null;
  /**
   * Unsigned, in the instrument's base asset as the venue counts it (not times `Instrument.multiplier`): one side of
   * every open position. Null where the source does not give it.
   */
  readonly open_interest: string | null;
  readonly status: DataStatus;
}

// ── Marks and levels ──────────────────────────────────────────────────────────────────────────────────────────────

/** Trades (the person's own or the market's), events (a listing, a split, a resolution), alerts that fired. */
export const MARK_KINDS = ["trade", "event", "alert"] as const;

export type MarkKind = (typeof MARK_KINDS)[number];

/** A point in time, with a price in the trading basis or none. */
export interface ChartMark {
  readonly id: string;
  readonly kind: MarkKind;
  /** ms */
  readonly t: number;
  /** In the trading basis; null for a mark on time alone. */
  readonly price: string | null;
  readonly side: "buy" | "sell" | null;
  readonly label: string;
  /** The person's own trade or alert; false for the market's. Someone else's trades are marks and nothing more. */
  readonly own: boolean;
}

/**
 * Marks come with their status: a market's trades are a source's figures, and its rights decide whether they are
 * shown. The person's own trades and alerts are theirs, not the source's: no source's rights hide them.
 */
export interface MarksPage {
  readonly marks: readonly ChartMark[];
  readonly status: DataStatus;
}

/** A horizontal line across time: an alert the person set, a level they keep. Neither one ever drafts an order. */
export const LEVEL_KINDS = ["alert", "level"] as const;

export type LevelKind = (typeof LEVEL_KINDS)[number];

export interface ChartLevel {
  readonly id: string;
  readonly kind: LevelKind;
  /** In `basis`. */
  readonly price: string;
  /** Usually the trading basis; an alert on market cap or on a USD price names its own, and shows on a view of it. */
  readonly basis: PriceBasis;
  readonly label: string;
}

// ── The order book for a price ladder ─────────────────────────────────────────────────────────────────────────────

export interface DomBook {
  readonly instrument: string;
  /** The ladder's step in the trading basis: a whole multiple of the instrument's tick where the step is fixed. */
  readonly step: string;
  /** Best first, [price, size] decimal strings, price in the trading basis, size in the base asset. */
  readonly bids: readonly BookLevel[];
  readonly asks: readonly BookLevel[];
  /** The book's sequence number: a ladder drops a book older than the one it shows. */
  readonly seq: number;
  readonly status: DataStatus;
  /**
   * The steps the source can give this book at now, finest first, decimal strings in the trading basis; `step` is one of
   * them (by value). The first is the venue's own levels where the source has them. A venue that aggregates its book by
   * significant figures has steps that follow the price — counted from the middle of the book — so they come with each
   * book; a book whose levels lie on more than one step (such a venue near a power of ten) names the finest of them. A
   * subscription keeps the step asked: the source serves it from whichever of the venue's aggregations gives it now, or
   * sums a finer one onto it; where it can do neither, it serves the nearest finer step it has (else its finest) and
   * names that in `step` — a reader sums a finer one onto the step it asked and shows a coarser one as it came — never
   * null, which is «no book». A coarser step shows the same book
   * farther from the price, never more of it than the venue publishes. Absent: the source names none, and a reader asks
   * for no step but this one. Since 2.6.
   */
  readonly steps?: readonly string[];
  /**
   * The most levels a side of this book carries — the source's cut, whoever made it (the venue, or the gateway cutting
   * it further; a source that sums levels onto a step itself names none — its rows are not the levels a venue cut): a side with this many
   * goes on past what is shown, and the book is visible only as far as its last level (Bitcoin's twenty levels a side at
   * its finest step on one venue were ±0.03 % of the price on 31.10.2026); a side with fewer is the end of the book as
   * published. Null or absent: the source names no cut. Since 2.6.
   */
  readonly max_levels?: number | null;
}

// ── The market's trades as they come ──────────────────────────────────────────────────────────────────────────────

/**
 * Trades as a source passes them on. Since 2.6.
 *
 * - **Order.** In the venue's order (`MarketTrade.order`), oldest first, through the whole subscription: a trade never
 *   comes after one that stands later in that order. A trade that comes late (it would land before one already passed)
 *   is not passed — the bars it changes come as `corrected` on the bar stream. Each trade comes once; after a reconnect
 *   nothing already passed comes again.
 * - **The recent past.** The first update may bring the trades the source already held when the subscription began —
 *   the newest stretch of the past, whole from its oldest trade — and says so (`recent: true`); a source with no past to
 *   give sends its first update with `recent: false`. What a reader counts starts at the oldest trade it was given.
 * - **What is passed.** Only trades the source holds as settled for its own tape: a venue's trades; on a chain,
 *   `confirmed` or `final` ones — a `pending` trade is not passed, so nothing passed is ever taken back.
 * - **Gaps and silence.** Trades the source could not pass (a broken connection, an outage) are said by an update with no
 *   trades and the state `gap`: what a reader counted across it is incomplete, and it counts afresh after it. A source
 *   with no new trade still passes an update with no trades and its state at least every five seconds, so a reader
 *   tells a quiet market from a stream that stopped: in such an update `status.at` is still the newest trade's time and
 *   `gateway_at` the moment the source vouched for the stream. The gateway's clock in the statuses never runs back.
 * - **Side.** A trade's `side` is the taker's: a tape and every count of buying against selling read it so, and a trade
 *   without one is counted on neither side.
 * - **Rights.** `status.derived` is false: these are the source's own figures. A tape lists them only where the source's
 *   rights let its own figures be shown (`display`; `internal_only` on the team's own screens); a reader may count them
 *   under `derived_only` — a bar of trades, a sum of buying and selling at a price or on a bar is derived — and never
 *   lists them there; what it counts follows the trades' rights, not those of the book or the bars it is drawn beside.
 */
export interface TradesUpdate {
  readonly instrument: string;
  readonly trades: readonly MarketTrade[];
  readonly status: DataStatus;
  /** The first update only, where it brings what the source already held: these trades are the recent past. */
  readonly recent: boolean;
}

// ── The source a chart reads ──────────────────────────────────────────────────────────────────────────────────────

/**
 * The data side of a chart: the shared feed in the browser, the gateway's client, a demo. Pages and the live bar
 * here are what the engine's data loader takes, decimal strings still; the engine adapter turns them into numbers.
 */
export interface ChartSource {
  /** The contract version it implements. */
  readonly contract: string;
  instrument(id: string, options?: ChartRequestOptions): Promise<Instrument>;
  history(request: HistoryRequest, options?: ChartRequestOptions): Promise<HistoryPage>;
  /** Returns the unsubscribe; after it, nothing more arrives. */
  subscribe(request: LiveRequest, listener: (event: LiveEvent) => void): () => void;
  series(instrument: string, options?: ChartRequestOptions): Promise<readonly SeriesSpec[]>;
  seriesHistory(request: SeriesRequest, options?: ChartRequestOptions): Promise<SeriesPage>;
  /** Live points of a series; absent where the source has none. */
  subscribeSeries?(series: string, listener: (point: SeriesPoint, status: DataStatus) => void): () => void;
  /** Marks with `from` ≤ t < `to`. */
  marks(instrument: string, from: number, to: number, options?: ChartRequestOptions): Promise<MarksPage>;
  /** Null where the instrument has no book (a pool). */
  book(instrument: string, step: string, options?: ChartRequestOptions): Promise<DomBook | null>;
  /** The live book; absent where the source has none. A ladder runs on this, not on snapshots. */
  subscribeBook?(instrument: string, step: string, listener: (book: DomBook) => void): () => void;
  /** A perpetual now; null for an instrument that is not one, or that the source has no context for. Since 2.4; absent before. */
  perp?(instrument: string, options?: ChartRequestOptions): Promise<PerpContext | null>;
  /**
   * The live context of a perpetual each time it changes, at most once a second, in order: a context's `status.at`
   * never runs back (a reader drops one that does). Absent where the source has none. Since 2.4.
   */
  subscribePerp?(instrument: string, listener: (context: PerpContext) => void): () => void;
  /**
   * The market's trades as they come, in the venue's order: what a tape lists, and what bars of trades, the buying and
   * the selling on a bar and the trades at a price are counted from. The first update may bring the recent past
   * (`TradesUpdate.recent`). Absent where the source passes on no trades. Since 2.6.
   */
  subscribeTrades?(instrument: string, listener: (update: TradesUpdate) => void): () => void;
}

// ── The engine's edge ─────────────────────────────────────────────────────────────────────────────────────────────

/** A bar as the engine takes it: the one place a price becomes a number. */
export interface EngineBar {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
  turnover?: number;
  [key: string]: unknown;
}

export interface EngineSymbol {
  ticker: string;
  /** Decimals of the page's `display_step`. */
  pricePrecision: number;
  /** Decimals of `Instrument.lot`. */
  volumePrecision: number;
  [key: string]: unknown;
}

export interface EnginePeriod {
  type: TimeUnit | "year";
  span: number;
}

/**
 * The data loader the engine takes (`setDataLoader`). A page answers `callback(bars, more)`; the live bar arrives
 * through `subscribeBar`. The engine also passes `update` as a load type for its own live merges; a loader answers
 * only `init`, `forward` and `backward`.
 */
export interface EngineLoader {
  getBars: (params: {
    type: HistoryLoad | "update";
    timestamp: number | null;
    symbol: EngineSymbol;
    period: EnginePeriod;
    callback: (data: EngineBar[], more?: boolean | { backward?: boolean; forward?: boolean }) => void;
  }) => void | Promise<void>;
  subscribeBar?: (params: { symbol: EngineSymbol; period: EnginePeriod; callback: (data: EngineBar) => void }) => void;
  unsubscribeBar?: (params: { symbol: EngineSymbol; period: EnginePeriod }) => void;
}

// ── What each engine draws ────────────────────────────────────────────────────────────────────────────────────────

/** A screen asks for one of these, never for an engine by name. */
export const CHART_CAPABILITIES = [
  "candles",
  "second_bars",
  "tick_bars",
  "volume_bars",
  "range_bars",
  "log_scale",
  "percent_scale",
  "probability_scale",
  "crosshair",
  "history_pages",
  "live_bar",
  "drawings",
  "indicators",
  "marks",
  "levels",
  "order_lines",
  "series_pane",
  "sparkline",
  "area",
  "mini_bars",
  "rings",
  "funding_strip",
  "probability_line",
  "heatmap",
  "histogram",
  "distribution",
  "sankey",
] as const;

export type ChartCapability = (typeof CHART_CAPABILITIES)[number];

/**
 * Which engine is to serve each capability — exactly one each: the candle engine for the trading chart and everything
 * on it, our own SVG for compact charts with no library, a modular analytics library for analytics alone. It says who
 * owns a capability, not that it works today: bars not by time, the probability axis, marks, levels and order lines
 * are ours over the candle engine (its price-to-pixel mapping and a fixed axis), so a change of engine keeps them.
 * The chart answers `capabilities()` with what works.
 */
export const CHART_ENGINES = {
  klinecharts: [
    "candles",
    "second_bars",
    "tick_bars",
    "volume_bars",
    "range_bars",
    "log_scale",
    "percent_scale",
    "probability_scale",
    "crosshair",
    "history_pages",
    "live_bar",
    "drawings",
    "indicators",
    "marks",
    "levels",
    "order_lines",
    "series_pane",
  ],
  svg: ["sparkline", "area", "mini_bars", "rings", "funding_strip", "probability_line"],
  echarts: ["heatmap", "histogram", "distribution", "sankey"],
} as const satisfies Readonly<Record<string, readonly ChartCapability[]>>;

export type ChartEngine = keyof typeof CHART_ENGINES;

// ── The trading layer: lines in, intents out ──────────────────────────────────────────────────────────────────────

export const ORDER_LINE_ROLES = ["limit", "stop", "take_profit", "stop_loss"] as const;

export type OrderLineRole = (typeof ORDER_LINE_ROLES)[number];

/**
 * A line's state follows its order: `draft` is a dashed ghost; `sent` spins and cannot be dragged; `resting` and
 * `partial` are solid and can be; `cancelling` waits for the venue and cannot be dragged; `unknown` is yellow
 * "checking", cannot be dragged and has no retry; `rejected` shows the venue's words and goes; `filled` becomes a
 * trade mark.
 */
export const ORDER_LINE_STATES = ["draft", "sent", "resting", "partial", "cancelling", "unknown", "rejected", "filled"] as const;

export type OrderLineState = (typeof ORDER_LINE_STATES)[number];

/** An order as the product knows it, drawn on the chart; prices in the trading basis. */
export interface OrderLine {
  readonly id: string;
  readonly role: OrderLineRole;
  readonly state: OrderLineState;
  readonly side: "buy" | "sell";
  readonly price: string;
  /** The trigger of a stop, a take profit or a stop loss; null for a plain limit. */
  readonly trigger: string | null;
  /** Which price wakes the trigger, from the instrument registry. */
  readonly trigger_kind: PriceKind | null;
  /** Unsigned, base asset. */
  readonly size: string;
  /** What is still open: equals `size` until a partial fill. */
  readonly remaining: string;
  readonly reduce_only: boolean;
  /** Time in force; post-only is where a venue charges a maker its own fee. Null where the venue does not say. */
  readonly tif: "gtc" | "ioc" | "post_only" | null;
  /** The intent that placed it — its client order id; null for an order placed outside Ryntra, shown with that label. */
  readonly intent_id: string | null;
  readonly leg: number;
  /** The venue's own words for a `rejected` line; null otherwise. */
  readonly refusal: Refusal | null;
}

/**
 * Profit or loss three ways: in the quote currency, in percent of `percent_of` (the margin where there is leverage,
 * the notional otherwise), and in pips — one pip is one price step of the instrument, at the entry price where the
 * step follows a rule.
 */
export interface PnL {
  readonly quote: string;
  readonly percent: string;
  readonly percent_of: "margin" | "notional";
  readonly pips: string;
  /** Whether entry and exit fees are taken off. */
  readonly after_fees: boolean;
  /** Always an estimate on a chart, and labelled so. */
  readonly estimate: true;
}

export interface PositionLines {
  /** Signed decimal: positive is long. */
  readonly size: string;
  readonly entry: string;
  /** Shown with every leveraged position. */
  readonly liquidation: string | null;
  readonly break_even: string | null;
  readonly leverage: number | null;
  readonly pnl: PnL;
  /**
   * The price the venue liquidates on, from the instrument registry — a mark on most perpetual venues; the line is
   * labelled with it and its distance counted from it where that price is known, else from the price now. Without it,
   * a mark. Since 2.4.
   */
  readonly liquidation_kind?: PriceKind;
  /**
   * The price the venue counts the position's P/L on (a mark on most perpetual venues). With it, the chart counts the
   * P/L on the entry line itself each time that price moves — from `TradingLayerState.prices`, else from the source's
   * live `PerpContext` (a context that is not live, or has fallen silent, gives no price), else from the chart's own
   * newest bar while the chart is drawn in that price and its data is live — and `pnl` stands only while no such price
   * is known. The chart's own count is an estimate: the price move times the size, after `fee_rate` in
   * and out, in percent of the margin by `leverage`, with no funding — so it may differ from a venue's figure that
   * counts the fees paid or the funding. Without it, `pnl` as given. Since 2.4.
   */
  readonly pnl_kind?: PriceKind;
}

/** Why a ghost cannot become an intent; it is drawn red with the reason. */
export const GHOST_REASONS = [
  "off_tick",
  "below_lot",
  "below_min_notional",
  "wrong_side",
  "beyond_liquidation",
  "outside_price_band",
  "data_not_live",
  "view_not_tradable",
] as const;

export type GhostReason = (typeof GHOST_REASONS)[number];

/** What a drag, a click on the price axis or a key gives first: a dashed line snapped to the step; the old line stays until the venue confirms. */
export interface ChartGhost {
  /** The line it moves; null for a new order. */
  readonly line_id: string | null;
  /** In the trading basis, snapped to the step before it is shown. */
  readonly price: string;
  /** Rounded down to the lot; null where the gesture names no size. */
  readonly size: string | null;
  readonly valid: boolean;
  readonly reasons: readonly GhostReason[];
  readonly pnl: PnL | null;
}

/**
 * What a person may place from the chart, since 2.3: a limit; a stop — a trigger that fills at the market; a
 * stop-limit — a trigger that places a limit; a bracket — a limit with a take profit and a stop loss that wait for it
 * to fill, one cancelling the other; a take profit or a stop loss on the open position; both of them on it, one
 * cancelling the other (`oco`); and a close of part or all of the position at the market. Since 2.6, an order at the
 * market (`market`) — a buy or a sell that fills now at the price the book gives and may open, add to, reduce or
 * reverse a position; it comes from a key or a button, never from a price on the chart, so it has no price and no
 * ghost. A kind with a trigger, a leg, a position or the market is offered on a perpetual only; on a spot pair, a pool,
 * a stock and a prediction a chart places limits; on an index, and on an instrument kind it does not know, nothing.
 */
export const NEW_ORDER_KINDS = ["limit", "stop", "stop_limit", "bracket", "take_profit", "stop_loss", "oco", "close", "market"] as const;

export type NewOrderKind = (typeof NEW_ORDER_KINDS)[number];

/** What a new order from the chart takes. The chart offers no new order without it. Since 2.3. */
export interface NewOrderTerms {
  /**
   * The size of a new order, as the person set it in the product's ticket: base asset, a decimal string, rounded down
   * to the lot. A take profit, a stop loss and both on the position take the position's size; a close, its part.
   * The chart never proposes a size of its own.
   */
  readonly size: string;
  /** The price a trigger placed from the chart wakes on, as the venue reads it (a mark on most perpetual venues). */
  readonly trigger_kind: PriceKind;
  /**
   * The kinds the product's venue takes from a chart; nothing else is offered. A product lists a kind only where its
   * venue adapter takes the intent it maps the draft to. The intent contract today has a limit, a limit with legs (a
   * bracket) and a market order that only reduces (a close); a stop's trigger on the order itself, a stop-limit and
   * the position's exits without an order of their own are not in it yet — a product lists `stop`, `stop_limit`,
   * `take_profit`, `stop_loss` and `oco` only with an adapter that says it takes them, `close` only with one that
   * keeps `reduce_only` (the contract's tests do not check it yet), and `market` only with one that takes a market
   * order that is not only reducing, immediate-or-cancel under the product's own bound on slippage (the contract's tests
   * do not check it yet). A kind with a trigger is not offered while `trigger_kind` is a price kind the reader does not
   * know. A product lists the kinds it takes one by one, never `NEW_ORDER_KINDS` whole: a minor adds words to that list.
   */
  readonly kinds: readonly NewOrderKind[];
}

/**
 * What a new order drafted on the chart is for, since 2.3: `entry` is a new order that is not only reducing — it may
 * open, add to, reduce or reverse a position (its legs, if any, wait for it to fill); `close` only reduces the
 * position, at the market, and has no price; `position_tpsl` has no order of its own — its legs are a take profit
 * and/or a stop loss on the open position, one cancelling the other. A product that does not know a purpose refuses
 * the draft.
 */
export const CHART_DRAFT_PURPOSES = ["entry", "close", "position_tpsl"] as const;

export type ChartDraftPurpose = (typeof CHART_DRAFT_PURPOSES)[number];

/** The actions a chart can draft; anything else is not a chart's to start. */
export const CHART_INTENT_ACTIONS = ["perp_order", "perp_modify", "perp_cancel", "limit", "cancel"] as const satisfies readonly IntentAction[];

export type ChartIntentAction = (typeof CHART_INTENT_ACTIONS)[number];

/** A chart drafts only from a person's hand: a gesture or a key. Never from an alert, a level or an assistant. */
export const CHART_INTENT_SOURCES = ["ui", "hotkey"] as const satisfies readonly IntentSource[];

export type ChartIntentSource = (typeof CHART_INTENT_SOURCES)[number];

/**
 * An intent as the chart drafts it. The product gives it an id, a profile and a signer, runs preflight and Review,
 * and the person signs; the chart sends nothing. A modify or a cancel names its order in `params.target` (and one leg
 * in `params.target_leg`).
 *
 * `params.price` and `params.trigger` are in the intent's unit: the ghost's price as it is, and on a probability scale
 * the percent divided by 100 — a fraction of the payout, exactly (69.4 → "0.694"); the venue's adapter turns that into
 * the venue's own quote (cents, ticks) without rounding. The number on the ghost, in the intent and in Review is one
 * price; nothing is rounded after the ghost.
 *
 * A new order (since 2.3) says its `purpose`; a product that sets `new_orders` reads a draft by its `action` and
 * `purpose`, never by `ghost === null` alone (a close and an order at the market have no ghost either, and are read like
 * any other draft: Review unless ARMED). On a
 * perpetual it is `perp_order`:
 * - a limit carries `type: "limit"` and `price`;
 * - a stop carries `type: "market"` and `trigger`; a stop-limit `type: "limit"`, `trigger` and `price`. A top-level
 *   `trigger` is a stop's: a buy wakes when the price reaches it from below (at or above it), a sell from above (at or
 *   below it), on the price the draft's `trigger_kind` names — the product uses it, and refuses the draft where it is
 *   no longer the venue's (`new_orders.trigger_kind` changed since);
 * - a bracket is a limit with a take profit and a stop loss in `legs`, which wait for it to fill;
 * - `position_tpsl` has no order of its own: `side` (the side that closes) and `reduce_only: true`, no `type`, `price`
 *   or `trigger`, and `size` null — so there is nothing to place as leg 0. Its legs are the position's exits: each
 *   closes the position as it is when it fires (a venue's position-linked take profit and stop loss), and its
 *   `amounts.in` is the position's size when drafted, for Review and for a venue that can only fix a size. The
 *   intent contract has no order without leg 0: the product maps this draft to its venue's position exits, or refuses
 *   it; it never passes these params to an adapter as an order;
 * - a close carries `type: "market"`, `reduce_only: true` and the side that closes;
 * - an order at the market (since 2.6) is an `entry` of kind `market`: `type: "market"` and its side, no `price`, no
 *   `trigger`, no `reduce_only`, no legs and no ghost; its `size` is the ticket's (`new_orders.size`). With no price to
 *   check, the chart drafts it only when the layer may draft at all (live data, the product's word), the price now is
 *   known, the size is at least a lot and the order at the price now at least the venue's smallest. Like any draft,
 *   Review unless ARMED; the product's preflight checks the age of its book or price before Review and before it sends
 *   in ARMED.
 * A close and an order at the market never rest in the book: the product sends them immediate-or-cancel (`tif: "ioc"`,
 * or the venue's own market order) within its `slippage_bps` of the price now (`prices`: the middle of the book, else
 * the last); whatever does not fill within that bound is cancelled, and Review names the bound as the worst price.
 * A leg carries `role`, `side`, `trigger`, `type: "market"` and `reduce_only: true`; the role says which way its
 * trigger wakes. Elsewhere a new order is `limit` with `type: "limit"` and `price`. A leg without `amounts` takes the
 * draft's `size`.
 *
 * The chart never sets `tif`, `leverage`, `slippage_bps` or `route`: the product adds them — a close at the market
 * needs the product's slippage bound, and a limit that no longer rests when it is sent is the product's to refuse or
 * to send as it decides.
 */
export interface ChartIntentDraft {
  readonly action: ChartIntentAction;
  readonly source: ChartIntentSource;
  readonly instrument: string;
  readonly params: IntentParams;
  /**
   * The size in the instrument's base asset; null for a cancel, a modify of price alone and `position_tpsl`. Its value
   * is `units / 10^decimals`, and `decimals` are those of the size and the lot, not the asset's on-chain decimals,
   * which the chart does not know: an adapter rescales it to its asset's atomic units and never reads `units` as them.
   * The same holds for every amount in a chart draft, the legs' `amounts.in` too.
   */
  readonly size: Amount | null;
  /** A take profit and a stop loss drafted with the order, in one action. */
  readonly legs: readonly IntentLeg[];
  /**
   * Null for a cancel — no ghost, no check and no lock ever stands between a person and a cancel — and for a close and
   * an order at the market, which have no price to draw. A new order's ghost is its first priced line (the entry, else its take
   * profit, else its stop loss), valid only when every line of the order is.
   */
  readonly ghost: ChartGhost | null;
  /** A new order's purpose; absent on a modify and a cancel, and from a chart before 2.3. */
  readonly purpose?: ChartDraftPurpose;
  /** A new order's kind, as the person chose it — what Review names it; set with every `purpose`. Since 2.3. */
  readonly kind?: NewOrderKind;
  /** The price the draft's triggers wake on (`new_orders.trigger_kind` when it was drafted); absent without a trigger. Since 2.3. */
  readonly trigger_kind?: PriceKind;
  /**
   * Drafted in practice (`TradingLayerState.practice`), since 2.5: for a paper executor only. A product's path to a
   * venue refuses a draft that carries it, whatever else the draft says.
   */
  readonly practice?: true;
}

export interface TradingLayerState {
  readonly instrument: Instrument;
  /** The basis on screen: the layer drafts only when it is in the trading basis' unit (see `Instrument.trading_basis`). */
  readonly view: PriceBasis;
  readonly lines: readonly OrderLine[];
  readonly position: PositionLines | null;
  /**
   * False while the data is not `live` (demo, delayed, stale, a gap) or the product says no: new orders and modifies
   * are off and the lines are grey with `not_tradable_reason`; cancelling stays on, always.
   */
  readonly tradable: boolean;
  readonly not_tradable_reason: string | null;
  /** The person's own fast mode for perpetual orders only; without it every draft goes through Review. */
  readonly armed: boolean;
  /**
   * The prices a ghost is checked against, as the product reads them, in the trading basis (percent of the payout on
   * a probability scale): the price a trigger wakes on (`OrderLine.trigger_kind`), the reference of the venue's price
   * band, and the price now — the middle of the book, else the last price — that a limit must not cross. A check whose
   * price is missing, or whose kind the reader does not know, cannot be made, and the ghost is not valid
   * (`data_not_live`). A kind not given here is read from the chart only when the chart is drawn in it: the newest
   * bar's close of a last-price chart is the last price. Optional in type, needed in fact wherever a trigger or a band
   * names another price (a mark, an oracle). Since 2.1.
   */
  readonly prices?: Readonly<Partial<Record<PriceKind, string>>>;
  /**
   * One side's fee as a fraction of the notional, a decimal from 0 up to but not including 1 (the venue's rate for a
   * taker plus whatever else is charged on the order — a builder's fee once, Ryntra's if it is not that builder):
   * the P/L in the currency and in percent that the layer counts for a ghost and for a take profit or a stop loss is
   * after this rate on the way in and on the way out (a resting entry may have paid less: the estimate errs high on
   * fees). Pips count the price move alone. Without it, or out of range, the P/L is before fees and `PnL.after_fees`
   * says so. Since 2.1.
   */
  readonly fee_rate?: string;
  /** What a new order from the chart takes; without it the chart places no new order. Since 2.3. */
  readonly new_orders?: NewOrderTerms | null;
  /**
   * Practice, since 2.5: the lines and the position are a paper account's (`ChartPaperExecutor`) and no money moves.
   * The chart wears the practice sign for as long as it is set and stamps every draft `practice: true`. On live data a
   * practice chart drafts as a chart with money does; on a replay — the past — a chart drafts in practice only, and a
   * replay's own data is then its market. Absent or false: the lines are money.
   */
  readonly practice?: boolean;
}

export interface ChartTradingLayer {
  /** The product's lines; the chart never moves a line on its own. */
  set(state: TradingLayerState): void;
  /** Returns the unsubscribe. */
  onIntent(listener: (draft: ChartIntentDraft) => void): () => void;
}

/** Marks and levels for the basis on screen (`view`); a priced one in another unit follows `Instrument.trading_basis`. */
export interface ChartMarksLayer {
  set(view: PriceBasis, marks: readonly ChartMark[], levels: readonly ChartLevel[]): void;
}

// ── Practice: a paper account behind the trading layer (since 2.5) ───────────────────────────────────────────────

/**
 * A paper executor takes the trading layer's drafts as a venue would take the intents, keeps one paper account on one
 * instrument, and gives the layer back its lines and position (`TradingLayerState.lines`, `position`, with
 * `practice: true`). No money moves and nothing leaves it. It knows no venue: the venue's numbers — fees, leverage,
 * margin, how a position is liquidated — are the product's, in `PaperRules`. It fills on the prices it is fed
 * (`PaperTick`): live prices, or a replay's.
 *
 * What it does with a draft, in the trading layer's own words: a limit rests and fills when the price trades through
 * it (or touches it, by the rules) at its own price as a maker; a stop, a take profit and a stop loss wake on their
 * `trigger_kind` and fill at the market as a taker, with the rules' slippage; a stop-limit wakes and rests as a limit;
 * a bracket's legs wait for its entry to fill, then guard the position it opened; a position's exits close the position
 * as it is when they fire, one cancelling the other; a close takes a share at the market; an order at the market (since
 * 2.6) fills at the market as a taker, with the rules' slippage, and may open, add to, reduce or reverse the position —
 * until it fills it holds margin for the part it would open at the last price with the rules' slippage, and at its fill what it opens then is
 * checked again against the account (an exit may have closed the position meanwhile); what cannot be backed is
 * rejected. A modify moves a price or a
 * trigger, a cancel removes an order (a leg alone with `target_leg`). Every order waits `latency_ms` before it rests
 * or fills (its line says «sent» meanwhile; a close and an order at the market have no line — what they hold shows in
 * `PaperAccount.margin`) and fills only on prices that came after that. It fills whole, never in
 * part.
 *
 * A tick is a stretch of prices whose order inside is not known, so where the order matters the worse one is counted,
 * and the trade says so (`worst_case`): the core's executor walks the stretch up first and down first (and a fresh
 * mark's own walk before and after it), everything along a walk in the order the price reaches it, and keeps the walk
 * that leaves the account worth less.
 *
 * A trigger on a kind of price the account has not been fed (a mark on a replay of last prices) wakes on the last
 * price, and the trade names the price it woke on (`triggered_on`).
 */
export interface PaperRules {
  /** The account the practice starts with, in the instrument's quote currency; `reset()` comes back to it. */
  readonly start: string;
  /** One side's fee as a fraction of the value for what takes at the market: a stop, a trigger, a close, an order at the market, a liquidation. */
  readonly fee_taker: string;
  /** One side's fee as a fraction of the value for a resting limit that is filled. */
  readonly fee_maker: string;
  /**
   * The leverage the person chose, for the next order; a position keeps the one it opened with. Off a perpetual, 1:
   * an order there holds its whole value.
   */
  readonly leverage: string;
  /** The most the venue gives: an order at a higher leverage is refused. */
  readonly max_leverage: string;
  /**
   * `isolated`: the position holds its own margin and loses no more than it; `cross`: the whole account stands behind
   * it. Either way the position is liquidated when what stands behind it falls to the maintenance margin.
   */
  readonly margin: PaperMarginMode;
  /** The maintenance margin as a fraction of the position's value at the mark (else the last price). */
  readonly maintenance_rate: string;
  /**
   * Taken at a liquidation as a fraction of the value, beside the taker fee: on a venue that keeps the maintenance
   * margin of a liquidated position it equals `maintenance_rate`. The two never take more than is left behind the
   * position: an isolated position loses no more than its margin, a cross account no more than its balance.
   */
  readonly liquidation_fee_rate: string;
  /**
   * An order at the market fills this far past the price, in basis points, on the nearest price step and never better
   * than the price it slipped from: an estimate, for a price is not a book.
   */
  readonly slippage_bps: number;
  /**
   * ms from a draft to its order resting or filling, on the market's clock: the order fills only on a tick whose stretch
   * began after that — the tick after next on bars longer than the latency.
   */
  readonly latency_ms: number;
  /**
   * Funding as a fraction of the value per hour, paid on each whole hour of the market's clock while a position is
   * open — by the position as it stands at the end of the tick that passed the hour: positive — longs pay shorts. Null:
   * none is counted, and the account says so.
   */
  readonly funding_per_hour: string | null;
  /** Whether a resting limit fills on a touch of its price, or only once the price trades through it by a step. */
  readonly limit_fill: PaperLimitFill;
}

export const PAPER_MARGIN_MODES = ["isolated", "cross"] as const;

export type PaperMarginMode = (typeof PAPER_MARGIN_MODES)[number];

/** A touch says nothing of the queue in the book, so `through` is the safe reading. */
export const PAPER_LIMIT_FILLS = ["through", "touch"] as const;

export type PaperLimitFill = (typeof PAPER_LIMIT_FILLS)[number];

/**
 * What a paper executor is fed: the last price's path since the tick before — it opened at `o`, reached `h` and `l`
 * in an order not known, and stands at `c` at `at` — and the prices of other kinds as they stand at `at`. A price of
 * another kind counts for a short while after the tick that brought it (ten seconds in the core's executor), then the
 * last price stands in for it: a feeder that has a mark passes it with every bar, however long it has not changed — a
 * mark that only repeats the fresh one keeps it fresh and decides nothing. A tick older than the one before it, or a
 * bar that contradicts itself, is ignored whole.
 */
export interface PaperTick {
  /** ms on the market's clock: a replay's moment, or the source's time of its newest number. */
  readonly at: number;
  readonly bar?: { readonly o: string; readonly h: string; readonly l: string; readonly c: string } | null;
  readonly prices?: Readonly<Partial<Record<PriceKind, string>>>;
}

/** The paper account, in the instrument's quote currency; money to 8 decimals. */
export interface PaperAccount {
  readonly currency: AssetId;
  readonly start: string;
  /** Cash: the start with realised P/L, fees and funding. */
  readonly balance: string;
  /** The balance with the open position's P/L at the price now. */
  readonly equity: string;
  readonly unrealised: string;
  /** P/L of the positions' closed parts, before fees. */
  readonly realised: string;
  /** Fees paid, a liquidation's included. */
  readonly fees: string;
  /** Funding paid; negative — received. */
  readonly funding: string;
  /** False while the rules count no funding. */
  readonly funding_counted: boolean;
  /** What the position and the resting orders that may open one hold. */
  readonly margin: string;
  /**
   * What a new order may take, never below zero: on a perpetual with cross margin the equity less the margin held; with
   * isolated margin, and off a perpetual, the balance less what the positions, holdings and resting orders hold — a gain
   * not taken is not cash.
   */
  readonly available: string;
  readonly liquidations: number;
  /** ms of the newest price the account has seen, on the market's clock; null before the first. */
  readonly at: number | null;
}

/**
 * Why a paper trade happened: the order that filled (since 2.6 an order at the market too: `market`), a liquidation, or
 * an hour's funding. `rejected`: an order that reached its price and was turned away there — on isolated margin, the
 * cash nothing else holds could not back the margin at the fill's price; on cross, an order at the market whose part that
 * opens the account could not back at its fill; or an order at the market that would open a position on an account worth
 * nothing. Nothing changed hands (no fee, no P/L).
 */
export const PAPER_TRADE_CAUSES = ["limit", "stop", "stop_limit", "take_profit", "stop_loss", "close", "liquidation", "funding", "rejected", "market"] as const;

export type PaperTradeCause = (typeof PAPER_TRADE_CAUSES)[number];

/** One line of the account's journal, oldest first. */
export interface PaperTrade {
  readonly id: string;
  /** ms on the market's clock. */
  readonly t: number;
  readonly cause: PaperTradeCause;
  /** Null for funding. */
  readonly side: "buy" | "sell" | null;
  /** The fill's price, slippage in it; for a rejected order, where it was turned away; null for funding. */
  readonly price: string | null;
  /** Unsigned, base asset; for a rejected order, what it asked — nothing filled; null for funding. */
  readonly size: string | null;
  /** The fee paid, a liquidation's included; "0" for funding. */
  readonly fee: string;
  /** The slippage counted, in the quote currency; "0" where none. */
  readonly slippage: string;
  /** P/L the trade realised before its fee; "0" where it only opened or added; for funding, minus what was paid. */
  readonly realised: string;
  /** The price a trigger woke on; null for a limit, a close, an order at the market and funding. */
  readonly triggered_on: PriceKind | null;
  /** Counted the worse way: what it fired with could have come first or second in its tick. */
  readonly worst_case: boolean;
  /** The line it filled (`OrderLine.id`: a bracket's take profit is its own line), or the order's id for a close or an order at the market; null for a liquidation and funding. */
  readonly order: string | null;
  /** The position after it, signed. */
  readonly position_after: string;
  readonly balance_after: string;
}

/**
 * Why a draft is refused: not drafted in practice; another instrument; not something paper takes (an action, a
 * purpose or a kind it does not know, an order off a perpetual that is not a limit); no price yet; not enough of the
 * account; a leverage above the venue's; nothing to close or guard; no such order.
 */
export const PAPER_REFUSALS = ["not_practice", "other_instrument", "not_offered", "no_price", "insufficient_margin", "leverage_above_max", "no_position", "no_order"] as const;

export type PaperRefusal = (typeof PAPER_REFUSALS)[number];

export type PaperAnswer = { readonly ok: true } | { readonly ok: false; readonly reason: PaperRefusal };

/** What the trading layer and a page read: the lines and the position in the layer's own form, the account, the journal. */
export interface PaperState {
  readonly instrument: string;
  readonly lines: readonly OrderLine[];
  readonly position: PositionLines | null;
  readonly account: PaperAccount;
  readonly trades: readonly PaperTrade[];
  /** No position and no order: a jump in time (a replay, another date, back to live) may start. */
  readonly flat: boolean;
  /** The stream of prices the account is on (`session`): a chart on another stream draws none of its lines. */
  readonly session: string;
}

export interface ChartPaperExecutor {
  /** The contract version it implements. */
  readonly contract: string;
  readonly instrument: Instrument;
  /** A draft from the chart in practice: taken as its order, or refused, and the reason. */
  take(draft: ChartIntentDraft): PaperAnswer;
  feed(tick: PaperTick): void;
  state(): PaperState;
  /** Called after every change; returns the unsubscribe. */
  subscribe(listener: (state: PaperState) => void): () => void;
  /** New rules for what comes next; a position keeps its leverage. */
  rules(rules: PaperRules): void;
  /** Back to the start: no position, no order, an empty journal. */
  reset(): void;
  /**
   * A new stream of prices starts (a replay, another date, back to live): the clock may start anywhere again. Refused
   * (false) unless the account is flat — a position never jumps in time.
   */
  session(key: string): boolean;
  /**
   * The way out of a stream of prices that ended (a replay left behind with a position on it): the position closes at
   * the last price that stream gave, as a taker, and every order goes. The account is flat after it.
   */
  settle(): void;
}

/** «Go live»: the person leaves practice for money. An event for the product: the chart switches nothing itself. */
export interface PracticeGoLive {
  readonly instrument: string;
  readonly account: PaperAccount;
  /** Paper orders and a paper position stay paper: the product says so before it switches. */
  readonly flat: boolean;
}

// ── The chart adapter ─────────────────────────────────────────────────────────────────────────────────────────────

/** Drawings belong to a person and an instrument: a pool's chart and its token's chart keep their own. */
export interface ChartDrawings {
  load(): Promise<string | null>;
  save(state: string): Promise<void>;
}

export interface ChartView {
  readonly instrument: Instrument;
  readonly resolution: Resolution;
  readonly basis: PriceBasis;
}

/** One engine behind one interface, on the web and in the phone's WebView. A screen asks `capabilities()`; which engine it is stays inside. */
export interface ChartAdapter {
  readonly contract: string;
  capabilities(): readonly ChartCapability[];
  show(view: ChartView, source: ChartSource): void;
  readonly marks: ChartMarksLayer;
  readonly trading: ChartTradingLayer;
  drawings(profileId: string, instrument: string): ChartDrawings;
  /** Chart colours from the design tokens: token name → value. */
  theme(tokens: Readonly<Record<string, string>>): void;
  dispose(): void;
}

// ── Version 1, and where each of its parts went ───────────────────────────────────────────────────────────────────

/** @deprecated Version 1; read through `CHART_V1_MAP`. */
export interface ChartSymbolV1 {
  readonly market: string;
  readonly symbol: string;
  /** 10^decimals of the price step, as the chart library wants it. */
  readonly pricescale: number;
  readonly session: string;
  readonly resolutions: readonly string[];
}

/** @deprecated Version 1: our own fills. */
export interface ChartMarkV1 {
  readonly id: string;
  /** ms */
  readonly t: number;
  readonly side: "buy" | "sell";
  readonly price: string;
  readonly label: string;
}

/** @deprecated Version 1. */
export interface ChartDatafeedV1 {
  onReady(): Promise<{ readonly resolutions: readonly string[] }>;
  resolveSymbol(market: string): Promise<ChartSymbolV1>;
  getBars(market: string, resolution: string, from: number, to: number): Promise<readonly Candle[]>;
  subscribeBars(market: string, resolution: string, onBar: (bar: Candle) => void): () => void;
  getMarks(market: string, from: number, to: number): Promise<readonly ChartMarkV1[]>;
}

/** @deprecated Version 1: dragging an order line was a modify on the venue; now it is a ghost and a draft. */
export interface ChartLineV1 {
  readonly id: string;
  readonly kind: "order" | "position" | "level";
  readonly price: string;
  readonly label: string;
  readonly draggable: boolean;
}

/** @deprecated Version 1. */
export interface ChartOverlayV1 {
  set(lines: readonly ChartLineV1[]): void;
  onDrag(listener: (id: string, price: string) => void): () => void;
}

/** @deprecated Version 1. */
export interface ChartAdapterV1 {
  datafeed(market: string): ChartDatafeedV1;
  readonly overlay: ChartOverlayV1;
  drawings(profileId: string): ChartDrawings;
  theme(tokens: Readonly<Record<string, string>>): void;
  fallback(): ChartAdapterV1;
}

/**
 * Every member of version 1 → where it lives in version 2. An empty list: gone, with the reason in the contract's
 * documentation (the fallback chart: a screen asks a capability instead).
 */
export const CHART_V1_MAP = {
  "datafeed.onReady": ["Instrument.resolutions"],
  "datafeed.resolveSymbol": ["ChartSource.instrument"],
  "datafeed.getBars": ["ChartSource.history"],
  "datafeed.subscribeBars": ["ChartSource.subscribe"],
  "datafeed.getMarks": ["ChartSource.marks"],
  "overlay.set": ["ChartTradingLayer.set", "ChartMarksLayer.set"],
  "overlay.onDrag": ["ChartTradingLayer.onIntent"],
  drawings: ["ChartAdapter.drawings"],
  theme: ["ChartAdapter.theme"],
  fallback: [],
} as const;
